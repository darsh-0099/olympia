import XCTest
@testable import SolarH9

final class OlympiaWidgetSnapshotTests: XCTestCase {
    func testWeekSelectionMovesAcrossRolloverWithoutRepublishing() throws {
        var calendar = Calendar(identifier: .gregorian)
        calendar.timeZone = try XCTUnwrap(TimeZone(secondsFromGMT: 0))
        calendar.firstWeekday = 2
        let start = try XCTUnwrap(calendar.date(from: DateComponents(year: 2026, month: 9, day: 28)))
        let days = (0..<14).map { offset in
            OlympiaWidgetSnapshot.Day(date: calendar.date(byAdding: .day, value: offset, to: start)!,
                                      plannedNames: ["Day \(offset)"], completedCount: 0, colorHex: nil)
        }
        let snapshot = OlympiaWidgetSnapshot(generatedAt: start, weekStart: start, days: days, active: nil)
        let nextWeek = try XCTUnwrap(calendar.date(byAdding: .day, value: 7, to: start))
        XCTAssertEqual(snapshot.daysForWeek(containing: start, calendar: calendar).compactMap { $0.plannedNames.first },
                       (0..<7).map { "Day \($0)" })
        XCTAssertEqual(snapshot.daysForWeek(containing: nextWeek, calendar: calendar).compactMap { $0.plannedNames.first },
                       (7..<14).map { "Day \($0)" })
    }

    func testHeartRateExpiresAfterThirtySeconds() {
        let now = Date(timeIntervalSince1970: 1_000)
        let active = OlympiaWidgetSnapshot.Active(id: UUID(), name: "Lift", phase: "working",
            exercise: nil, setNumber: 1, exerciseTotalSets: 3, totalSets: 3, completedSets: 0, deadline: nil,
            pausedRemaining: 0, heartRate: 120, heartRateZone: 2, heartRateUpdatedAt: now)
        XCTAssertEqual(active.currentHeartRate(at: now.addingTimeInterval(29)), 120)
        XCTAssertNil(active.currentHeartRate(at: now.addingTimeInterval(30)))
        XCTAssertNil(active.currentHeartRate(at: now.addingTimeInterval(-1)))
    }
}

@MainActor
final class OlympiaScheduleRolloverTests: XCTestCase {
    private func fixture(restAfterPush: Bool = false) throws -> (OlympiaTrainingStore, Date, Calendar) {
        let store = try OlympiaTrainingStore(inMemory: true)
        for name in ["Pull", "Push", "Legs"] {
            XCTAssertTrue(store.upsertWorkout(name: name, colorHex: "#63C7FF", exercises: [
                OlympiaExercise(name: "Lift", sets: 3, restSeconds: 90)
            ]))
        }
        let slots = try ["Pull", "Push", "Legs"].map { name in
            let workout = try XCTUnwrap(store.workouts.first { $0.name == name })
            return OlympiaProgramSlot(workoutID: workout.id, weekdays: [], colorHex: workout.colorHex)
        }
        let pattern = restAfterPush
            ? [slots[0], slots[1], .rest(), slots[2], .rest()]
            : [slots[0], slots[1], slots[2], .rest(), .rest()]
        let calendar = Calendar.current
        let today = calendar.startOfDay(for: .now)
        XCTAssertTrue(store.upsertProgram(name: "Cycle", scheduleType: "rotation",
                                        rotationRestDays: 0, rotationStartDate: today, slots: pattern))
        return (store, today, calendar)
    }

    func testBothRestPatternsRepeatWithoutSchedulingRestAsWorkout() throws {
        for interleaved in [false, true] {
            let (store, today, calendar) = try fixture(restAfterPush: interleaved)
            let expected = interleaved
                ? ["Pull", "Push", "", "Legs", "", "Pull"]
                : ["Pull", "Push", "Legs", "", "", "Pull"]
            let actual = (0..<6).map { offset in
                store.scheduledWorkouts(on: calendar.date(byAdding: .day, value: offset, to: today)!,
                                        calendar: calendar).first?.name ?? ""
            }
            XCTAssertEqual(actual, expected)
        }
    }

    func testMissedDayMovesWholeFutureCycleOnceAcrossRefreshes() throws {
        let (store, today, calendar) = try fixture(restAfterPush: true)
        let tomorrow = calendar.date(byAdding: .day, value: 1, to: today)!
        store.refresh(now: tomorrow, calendar: calendar)
        XCTAssertEqual(store.activeProgram?.schedulePayload.missedDates.count, 1)
        XCTAssertEqual(store.scheduledWorkouts(on: today, calendar: calendar).map(\.name), ["Pull"])
        XCTAssertEqual(store.scheduledWorkouts(on: tomorrow, calendar: calendar).map(\.name), ["Pull"])
        store.refresh(now: tomorrow, calendar: calendar)
        XCTAssertEqual(store.activeProgram?.schedulePayload.missedDates.count, 1)

        let logged = try XCTUnwrap(store.workouts.first { $0.name == "Pull" })
        let session = try XCTUnwrap(store.createSession(for: logged))
        session.startedAt = tomorrow
        session.endedAt = tomorrow
        session.status = "partial"
        store.persistSession(session)
        let following = calendar.date(byAdding: .day, value: 2, to: today)!
        store.refresh(now: following, calendar: calendar)
        XCTAssertEqual(store.activeProgram?.schedulePayload.missedDates.count, 1)
        XCTAssertEqual(store.scheduledWorkouts(on: following, calendar: calendar).map(\.name), ["Push"])
    }

    func testMultipleClosedMissedDaysDoNotSkipOrOverlapWorkout() throws {
        let (store, today, calendar) = try fixture(restAfterPush: true)
        let fourthDay = calendar.date(byAdding: .day, value: 3, to: today)!
        store.refresh(now: fourthDay, calendar: calendar)
        XCTAssertEqual(store.activeProgram?.schedulePayload.missedDates.count, 3)
        XCTAssertEqual(store.scheduledWorkouts(on: fourthDay, calendar: calendar).map(\.name), ["Pull"])
        store.refresh(now: fourthDay, calendar: calendar)
        XCTAssertEqual(store.activeProgram?.schedulePayload.missedDates.count, 3)

        let active = try XCTUnwrap(store.createSession(for: store.workouts[0]))
        active.startedAt = fourthDay
        active.endedAt = fourthDay
        active.status = "completed"
        store.persistSession(active)
        let fifthDay = calendar.date(byAdding: .day, value: 4, to: today)!
        store.refresh(now: fifthDay, calendar: calendar)
        XCTAssertEqual(store.scheduledWorkouts(on: fifthDay, calendar: calendar).map(\.name), ["Push"])
    }

    func testImportedWorkoutCountsAndActiveSessionDefersMissedDay() throws {
        let (store, today, calendar) = try fixture()
        let tomorrow = calendar.date(byAdding: .day, value: 1, to: today)!
        let active = try XCTUnwrap(store.createSession(for: store.workouts[0]))
        let originalCursor = store.activeProgram?.schedulePayload.checkedThrough
        store.refresh(now: tomorrow, calendar: calendar)
        XCTAssertEqual(store.activeProgram?.schedulePayload.checkedThrough, originalCursor)
        XCTAssertTrue(store.activeProgram?.schedulePayload.missedDates.isEmpty == true)
        active.status = "completed"
        active.endedAt = tomorrow
        store.persistSession(active)
        store.refresh(now: tomorrow, calendar: calendar)
        XCTAssertTrue(store.activeProgram?.schedulePayload.missedDates.isEmpty == true)

        store.addImportedSession(name: "Other", date: tomorrow, sets: [
            OlympiaCompletedSet(exerciseName: "Lift", exercisePosition: 0, setNumber: 1,
                                weightPounds: 100, reps: 5, restSeconds: 90, completedAt: tomorrow)
        ])
        let following = calendar.date(byAdding: .day, value: 2, to: today)!
        store.refresh(now: following, calendar: calendar)
        XCTAssertTrue(store.activeProgram?.schedulePayload.missedDates.isEmpty == true)
    }

    func testLegacySlotsAndBackupKeepRolloverMetadata() throws {
        let (store, today, calendar) = try fixture(restAfterPush: true)
        let program = try XCTUnwrap(store.activeProgram)
        let slots = program.slots
        program.slotsData = try JSONEncoder().encode(slots)
        XCTAssertEqual(program.slots.count, 5)
        XCTAssertTrue(program.slots[2].isRest)
        XCTAssertNil(program.schedulePayload.checkedThrough)

        store.refresh(now: today, calendar: calendar)
        let tomorrow = calendar.date(byAdding: .day, value: 1, to: today)!
        store.refresh(now: tomorrow, calendar: calendar)
        let originalEvents = try XCTUnwrap(store.activeProgram?.schedulePayload.missedDates)
        XCTAssertEqual(originalEvents.count, 1)
        let backup = OlympiaBackup(store: store)
        XCTAssertEqual(backup.programs.first?.missedDates, originalEvents)

        let restored = try OlympiaTrainingStore(inMemory: true)
        try restored.applyBackup(backup)
        XCTAssertEqual(restored.activeProgram?.schedulePayload.missedDates, originalEvents)
        restored.refresh(now: tomorrow, calendar: calendar)
        XCTAssertEqual(restored.activeProgram?.schedulePayload.missedDates.count, 1)
    }
}

final class OlympiaBackupMergeTests: XCTestCase {
    private func empty() -> OlympiaBackup {
        OlympiaBackup(workouts: [], sessions: [], programs: [], weights: [])
    }

    private func workout(_ id: UUID, _ name: String) -> OlympiaBackup.Workout {
        .init(id: id, name: name, colorHex: "#63C7FF", exercises: [])
    }

    func testThreeWayMergeCombinesIndependentChangesAndPreservesDeletion() throws {
        let sharedID = UUID(), deletedID = UUID(), localID = UUID(), remoteID = UUID()
        var base = empty()
        base.workouts = [workout(sharedID, "Original"), workout(deletedID, "Deleted")]
        var local = base
        local.workouts = [workout(sharedID, "Edited"), workout(localID, "Local")]
        var remote = base
        remote.workouts.append(workout(remoteID, "Remote"))

        let merged = try local.merged(base: base, remote: remote)
        XCTAssertEqual(merged.workouts.map(\.name), ["Edited", "Local", "Remote"])
        XCTAssertEqual(base.workouts.map(\.name), ["Original", "Deleted"])
        XCTAssertTrue(try base.merged(base: base, remote: empty()).workouts.isEmpty)
    }

    func testThreeWayMergeRejectsEditDeleteAndDivergentEdits() throws {
        let id = UUID()
        var base = empty()
        base.workouts = [workout(id, "Original")]
        var edited = base
        edited.workouts[0].name = "Changed"
        XCTAssertThrowsError(try edited.merged(base: base, remote: empty())) { error in
            XCTAssertEqual(error as? OlympiaBackup.MergeError, .conflict(collection: "workout", id: id))
        }
        var otherEdit = base
        otherEdit.workouts[0].name = "Other"
        XCTAssertThrowsError(try edited.merged(base: base, remote: otherEdit)) { error in
            XCTAssertEqual(error as? OlympiaBackup.MergeError, .conflict(collection: "workout", id: id))
        }
    }

    func testThreeWayMergeRejectsDuplicateIDs() throws {
        let id = UUID()
        var base = empty()
        base.weights = [.init(id: id, measuredAt: .now, pounds: 180),
                        .init(id: id, measuredAt: .now, pounds: 181)]
        XCTAssertThrowsError(try empty().merged(base: base, remote: empty())) { error in
            XCTAssertEqual(error as? OlympiaBackup.MergeError, .duplicateID(collection: "weight", id: id))
        }
    }

    func testThreeWayMergeRejectsTwoActivePrograms() throws {
        let firstID = UUID(), secondID = UUID()
        let start = Date(timeIntervalSince1970: 1_000)
        var local = empty()
        local.programs = [.init(id: firstID, name: "First", scheduleType: "weekly",
                                rotationRestDays: 0, rotationAnchor: start,
                                scheduleShiftDays: 0, slots: [], isActive: true)]
        var remote = empty()
        remote.programs = [.init(id: secondID, name: "Second", scheduleType: "weekly",
                                 rotationRestDays: 0, rotationAnchor: start,
                                 scheduleShiftDays: 0, slots: [], isActive: true)]
        XCTAssertThrowsError(try local.merged(base: empty(), remote: remote)) { error in
            XCTAssertEqual(error as? OlympiaBackup.MergeError, .multipleActivePrograms)
        }
    }

    func testLegacyBackupDecodesNewFieldsWithDefaults() throws {
        let id = UUID()
        var backup = empty()
        backup.programs = [.init(id: id, name: "Plan", scheduleType: "weekly", rotationRestDays: 0,
                                 rotationAnchor: Date(timeIntervalSince1970: 1_000), scheduleShiftDays: 0,
                                 slots: []),
                           .init(id: UUID(), name: "Other", scheduleType: "weekly", rotationRestDays: 0,
                                 rotationAnchor: Date(timeIntervalSince1970: 1_000), scheduleShiftDays: 0,
                                 slots: [])]
        backup.sessions = [.init(id: id, name: "Workout", startedAt: Date(timeIntervalSince1970: 1_000),
                                 endedAt: nil, status: "completed", averageHeartRate: nil, sets: [])]
        let encoder = JSONEncoder()
        encoder.dateEncodingStrategy = .iso8601
        var object = try XCTUnwrap(JSONSerialization.jsonObject(with: encoder.encode(backup)) as? [String: Any])
        var programs = try XCTUnwrap(object["programs"] as? [[String: Any]])
        for index in programs.indices { programs[index].removeValue(forKey: "isActive") }
        object["programs"] = programs
        var session = try XCTUnwrap((object["sessions"] as? [[String: Any]])?.first)
        for key in ["workoutID", "plannedExercises", "heartRateSessionID", "exerciseIndex",
                    "setNumber", "phaseDeadline", "pausedRemaining", "pausedAt", "pausedPhase",
                    "totalPausedSeconds"] { session.removeValue(forKey: key) }
        object["sessions"] = [session]
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        let decoded = try decoder.decode(OlympiaBackup.self, from: JSONSerialization.data(withJSONObject: object))
        XCTAssertTrue(try XCTUnwrap(decoded.programs.first).isActive)
        XCTAssertFalse(try XCTUnwrap(decoded.programs.last).isActive)
        XCTAssertNil(decoded.sessions.first?.workoutID)
        XCTAssertTrue(try XCTUnwrap(decoded.sessions.first).plannedExercises.isEmpty)
        XCTAssertEqual(decoded.sessions.first?.setNumber, 1)
    }
}

@MainActor
final class ExperienceTests: XCTestCase {
    func testBackupApplyUpdatesAndDeletesRatherThanResurrectingRecords() throws {
        let store = try OlympiaTrainingStore(inMemory: true)
        let workoutID = UUID()
        let weightID = UUID()
        let original = OlympiaBackup(
            workouts: [.init(id: workoutID, name: "Original", colorHex: "#111111", exercises: [])],
            sessions: [], programs: [],
            weights: [.init(id: weightID, measuredAt: Date(timeIntervalSince1970: 1_000), pounds: 180)])
        try store.applyBackup(original)
        XCTAssertEqual(store.workouts.first?.name, "Original")
        XCTAssertEqual(store.weights.count, 1)

        let updated = OlympiaBackup(
            workouts: [.init(id: workoutID, name: "Updated", colorHex: "#222222", exercises: [])],
            sessions: [], programs: [], weights: [])
        try store.applyBackup(updated)
        XCTAssertEqual(store.workouts.map(\.name), ["Updated"])
        XCTAssertTrue(store.weights.isEmpty)
    }

    func testBackupApplyRejectsDuplicatesWithoutChangingLocalData() throws {
        let store = try OlympiaTrainingStore(inMemory: true)
        let id = UUID()
        let original = OlympiaBackup(workouts: [], sessions: [], programs: [],
                                     weights: [.init(id: id, measuredAt: .now, pounds: 180)])
        try store.applyBackup(original)
        var invalid = original
        invalid.weights.append(.init(id: id, measuredAt: .now, pounds: 190))
        XCTAssertThrowsError(try store.applyBackup(invalid))
        XCTAssertEqual(store.weights.count, 1)
        XCTAssertEqual(store.weights.first?.pounds, 180)
    }

    func testCloudConflictGuardAllowsOwnNextEditButBlocksDivergentRemoteRevision() throws {
        let store = try OlympiaTrainingStore(inMemory: true)
        var local = OlympiaBackup(store: store)
        let id = UUID()
        local.workouts = [.init(id: id, name: "Local", colorHex: "#63C7FF", exercises: [])]
        var remote = local
        remote.workouts[0].name = "Remote"

        XCTAssertFalse(local.conflicts(with: remote, lastUploadedRevision: 4, remoteRevision: 4))
        XCTAssertTrue(local.conflicts(with: remote, lastUploadedRevision: 4, remoteRevision: 5))
        XCTAssertTrue(local.conflicts(with: remote, lastUploadedRevision: nil, remoteRevision: 5))
        remote.workouts[0].name = "Local"
        XCTAssertFalse(local.conflicts(with: remote, lastUploadedRevision: 4, remoteRevision: 5))
    }

    func testCloudConflictGuardBlocksLocalOnlyRecordsAfterRemoteAdvance() throws {
        let store = try OlympiaTrainingStore(inMemory: true)
        var local = OlympiaBackup(store: store)
        var remote = local
        local.weights = [.init(id: UUID(), measuredAt: .now, pounds: 180)]
        remote.weights = [.init(id: UUID(), measuredAt: .now, pounds: 175)]
        XCTAssertFalse(local.conflicts(with: remote, lastUploadedRevision: 1, remoteRevision: 1))
        XCTAssertTrue(local.conflicts(with: remote, lastUploadedRevision: 1, remoteRevision: 2))
        XCTAssertTrue(local.conflicts(with: remote, lastUploadedRevision: nil, remoteRevision: 2))

        remote.weights[0].id = local.weights[0].id
        XCTAssertTrue(local.conflicts(with: remote, lastUploadedRevision: 1, remoteRevision: 2))
    }

    func testCloudConflictGuardAllowsRemoteOnlyRecordsAfterRemoteAdvance() throws {
        let store = try OlympiaTrainingStore(inMemory: true)
        let local = OlympiaBackup(store: store)
        var remote = local
        remote.workouts = [.init(id: UUID(), name: "Remote", colorHex: "#63C7FF", exercises: [])]
        XCTAssertFalse(local.conflicts(with: remote, lastUploadedRevision: 1, remoteRevision: 2))
    }

    func testCloudConflictGuardIgnoresDatePrecisionLostInJSON() throws {
        let store = try OlympiaTrainingStore(inMemory: true)
        var local = OlympiaBackup(store: store)
        let id = UUID()
        local.weights = [.init(id: id, measuredAt: Date(timeIntervalSince1970: 1_000.5), pounds: 180)]
        var remote = local
        remote.weights[0].measuredAt = Date(timeIntervalSince1970: 1_000)
        XCTAssertFalse(local.conflicts(with: remote, lastUploadedRevision: 1, remoteRevision: 2))
    }

    func testEditedWorkoutSetCountPersists() throws {
        let store = try OlympiaTrainingStore(inMemory: true)
        store.upsertWorkout(name: "Push", colorHex: "#63C7FF", exercises: [
            OlympiaExercise(name: "Bench Press", sets: 3, restSeconds: 90)
        ])
        let workout = try XCTUnwrap(store.workouts.first)
        var exercises = workout.exercises
        exercises[0].sets = 5
        store.upsertWorkout(id: workout.id, name: workout.name,
                           colorHex: workout.colorHex, exercises: exercises)
        XCTAssertEqual(store.workouts.first?.exercises.first?.sets, 5)
    }

    func testDecreasedWorkoutSetCountPersists() throws {
        let store = try OlympiaTrainingStore(inMemory: true)
        store.upsertWorkout(name: "Push", colorHex: "#63C7FF", exercises: [
            OlympiaExercise(name: "Bench Press", sets: 3, restSeconds: 90)
        ])
        let workout = try XCTUnwrap(store.workouts.first)
        var exercises = workout.exercises
        exercises[0].sets = 2
        store.upsertWorkout(id: workout.id, name: workout.name,
                           colorHex: workout.colorHex, exercises: exercises)
        XCTAssertEqual(store.workouts.first?.exercises.first?.sets, 2)
    }

    func testRotationCycleStartsOnSelectedDate() throws {
        let store = try OlympiaTrainingStore(inMemory: true)
        store.upsertWorkout(name: "Push", colorHex: "#63C7FF", exercises: [
            OlympiaExercise(name: "Bench Press", sets: 3, restSeconds: 90)
        ])
        store.upsertWorkout(name: "Pull", colorHex: "#FF7384", exercises: [
            OlympiaExercise(name: "Row", sets: 3, restSeconds: 90)
        ])
        let workouts = store.workouts
        var calendar = Calendar(identifier: .gregorian)
        calendar.timeZone = TimeZone(secondsFromGMT: 0)!
        let start = calendar.date(from: DateComponents(year: 2026, month: 10, day: 5))!
        let slots = workouts.map { OlympiaProgramSlot(workoutID: $0.id, weekdays: [], colorHex: $0.colorHex) }
        store.upsertProgram(name: "Rotation", scheduleType: "rotation", rotationRestDays: 1,
                            rotationStartDate: start, slots: slots)

        XCTAssertEqual(store.activeProgram?.rotationAnchor, start)
        XCTAssertTrue(store.scheduledWorkouts(on: calendar.date(byAdding: .day, value: -1, to: start)!,
                                              calendar: calendar).isEmpty)
        XCTAssertEqual(store.scheduledWorkouts(on: start, calendar: calendar).map(\.name), ["Push"])
        XCTAssertEqual(store.scheduledWorkouts(on: calendar.date(byAdding: .day, value: 1, to: start)!,
                                               calendar: calendar).map(\.name), ["Pull"])
        XCTAssertTrue(store.scheduledWorkouts(on: calendar.date(byAdding: .day, value: 2, to: start)!,
                                              calendar: calendar).isEmpty)

        let movedStart = calendar.date(byAdding: .day, value: 3, to: start)!
        store.upsertProgram(id: store.activeProgram?.id, name: "Rotation", scheduleType: "rotation",
                            rotationRestDays: 1, rotationStartDate: movedStart, slots: slots)
        XCTAssertEqual(store.scheduledWorkouts(on: movedStart, calendar: calendar).map(\.name), ["Push"])
    }

    func testConsecutiveWorkoutsUseDistinctRecordingsAndDiscardPreservesPrevious() async throws {
        let defaults = UserDefaults(suiteName: "test.workout.lifecycle.\(UUID().uuidString)")!
        let repository = SwiftDataSessionRepository(container: try SolarPersistence.makeContainer(inMemory: true))
        let recording = RecordingController(repository: repository)
        let coordinator = SensorCoordinator(sensor: PolarH9Client(defaults: defaults), recording: recording)
        await coordinator.select(.simulator)

        let firstResult = await coordinator.startWorkout()
        let firstID = try XCTUnwrap(firstResult)
        let firstEnded = await coordinator.endWorkout(id: firstID)
        XCTAssertTrue(firstEnded)
        let secondResult = await coordinator.startWorkout()
        let secondID = try XCTUnwrap(secondResult)
        XCTAssertNotEqual(firstID, secondID)
        XCTAssertTrue(coordinator.hasActiveRecording)
        XCTAssertEqual(recording.draft?.id, secondID)

        let secondEnded = await coordinator.endWorkout(id: secondID)
        XCTAssertTrue(secondEnded)
        try await repository.deleteSession(id: secondID)
        let saved = try await repository.sessions(scope: .all)
        XCTAssertEqual(saved.map(\.id), [firstID])
    }

    func testWorkoutStartDoesNotAdoptAnExistingRecordingAndScopedEndLeavesItActive() async throws {
        let defaults = UserDefaults(suiteName: "test.workout.identity.\(UUID().uuidString)")!
        let repository = SwiftDataSessionRepository(container: try SolarPersistence.makeContainer(inMemory: true))
        let recording = RecordingController(repository: repository)
        let coordinator = SensorCoordinator(sensor: PolarH9Client(defaults: defaults), recording: recording)
        await coordinator.select(.simulator)
        let activeResult = await coordinator.startWorkout()
        let activeID = try XCTUnwrap(activeResult)

        let duplicateResult = await coordinator.startWorkout()
        XCTAssertNil(duplicateResult)
        let unrelatedEnded = await coordinator.endWorkout(id: UUID())
        XCTAssertTrue(unrelatedEnded)
        XCTAssertTrue(coordinator.hasActiveRecording)
        XCTAssertEqual(recording.draft?.id, activeID)

        await coordinator.pauseOrResume(id: UUID())
        XCTAssertEqual(recording.status, .recording(activeID))
        await coordinator.pauseOrResume(id: activeID)
        XCTAssertEqual(recording.status, .paused(activeID))
        await coordinator.pauseOrResume(id: UUID())
        XCTAssertEqual(recording.status, .paused(activeID))
        await coordinator.pauseOrResume(id: activeID)
        XCTAssertEqual(recording.status, .recording(activeID))

        // Cleanup does not require a view-local "started" flag or a ready
        // sensor: a restored paused workout only needs its persisted ID.
        await coordinator.pauseOrResume()
        XCTAssertEqual(recording.status, .paused(activeID))
        let ended = await coordinator.endWorkout(id: activeID)
        XCTAssertTrue(ended)
        XCTAssertFalse(coordinator.hasActiveRecording)
    }

    func testDiscardWorkoutRemovesLoggedSetsAndSession() throws {
        let store = try OlympiaTrainingStore(inMemory: true)
        let engine = OlympiaWorkoutEngine(store: store)
        let workout = OlympiaWorkoutTemplate(name: "Push", exercises: [
            OlympiaExercise(name: "Bench Press", sets: 3, restSeconds: 90)
        ])
        engine.start(workout)
        engine.beginNow()
        engine.completeSet(weightPounds: 100, reps: 12)
        XCTAssertEqual(store.sessions.first?.completedSets.count, 1)
        engine.cancel()
        XCTAssertFalse(engine.isActive)
        XCTAssertTrue(store.sessions.isEmpty)
        XCTAssertEqual(engine.secondsRemaining, 0)
    }

    func testFinishWorkoutKeepsPartialSession() throws {
        let store = try OlympiaTrainingStore(inMemory: true)
        let engine = OlympiaWorkoutEngine(store: store)
        engine.start(OlympiaWorkoutTemplate(name: "Push", exercises: [
            OlympiaExercise(name: "Bench Press", sets: 3, restSeconds: 90)
        ]))
        engine.beginNow()
        engine.completeSet(weightPounds: 100, reps: 12)
        engine.finish()
        XCTAssertFalse(engine.isActive)
        XCTAssertEqual(store.sessions.count, 1)
        XCTAssertEqual(store.sessions.first?.status, "partial")
        XCTAssertEqual(store.sessions.first?.completedSets.first?.reps, 12)
    }

    func testReducingRestPastZeroAdvancesToNextSet() throws {
        let store = try OlympiaTrainingStore(inMemory: true)
        let engine = OlympiaWorkoutEngine(store: store)
        engine.start(OlympiaWorkoutTemplate(name: "Push", exercises: [
            OlympiaExercise(name: "Bench Press", sets: 2, restSeconds: 90)
        ]))
        engine.beginNow()
        engine.completeSet(weightPounds: 100, reps: 12)
        XCTAssertEqual(engine.phase, "resting")
        engine.session?.phaseDeadline = .now.addingTimeInterval(3)

        engine.adjustRest(by: -15)

        XCTAssertEqual(engine.phase, "working")
        XCTAssertEqual(engine.session?.setNumber, 2)
        XCTAssertNil(engine.session?.phaseDeadline)
        XCTAssertEqual(engine.session?.completedSets.count, 1)
    }

    func testPrepDeadlineSetsWorkoutStartAfterSuspensionButNotWhenStartedEarly() throws {
        let store = try OlympiaTrainingStore(inMemory: true)
        let engine = OlympiaWorkoutEngine(store: store)
        let workout = OlympiaWorkoutTemplate(name: "Push", exercises: [
            OlympiaExercise(name: "Bench Press", sets: 1, restSeconds: 90)
        ])

        engine.start(workout)
        let overdueDeadline = Date().addingTimeInterval(-180)
        engine.session?.phaseDeadline = overdueDeadline
        engine.refreshTime()
        XCTAssertEqual(engine.phase, "working")
        XCTAssertEqual(engine.session?.startedAt.timeIntervalSince1970 ?? 0,
                       overdueDeadline.timeIntervalSince1970, accuracy: 0.001)
        XCTAssertGreaterThanOrEqual(engine.elapsedSeconds, 180)

        engine.cancel()
        engine.start(workout)
        let beforeEarlyStart = Date()
        engine.beginNow()
        let afterEarlyStart = Date()
        let startedAt = try XCTUnwrap(engine.session?.startedAt)
        XCTAssertGreaterThanOrEqual(startedAt, beforeEarlyStart)
        XCTAssertLessThanOrEqual(startedAt, afterEarlyStart)
    }

    func testNoteImportPreservesSlashSetsAndFinalSetOverride() throws {
        let store = try OlympiaTrainingStore(inMemory: true)
        let report = OlympiaNoteImporter.importWorkouts("""
        Push 7/28/25:
        1. Bench Press - 17/15/15 - 85lbs
        2. Lateral Raises - 4 sets - 12 reps (Last set 15) - 19lbs
        """, into: store)
        XCTAssertEqual(report.sets, 7)
        let sets = try XCTUnwrap(store.sessions.first).completedSets
        XCTAssertEqual(sets.prefix(3).compactMap(\.reps), [17, 15, 15])
        XCTAssertEqual(sets.suffix(4).compactMap(\.reps), [12, 12, 12, 15])
        XCTAssertEqual(sets.prefix(3).compactMap(\.weightPounds), [85, 85, 85])
    }

    func testNoteImportPreservesRepGroupsAndKnownCableCurlAlias() throws {
        let store = try OlympiaTrainingStore(inMemory: true)
        let report = OlympiaNoteImporter.importWorkouts("""
        Pull 9/2/25:
        1. Cable Straight Bar Bicep Curl - 4 sets - 12/12/11.5/10 reps - 37.5lbs
        Pull 3/20/26:
        1. Cable Straight Bar Curl (Smith bar under armpits) - 8/7 (20kg), 9 (30lbs)
        """, into: store)

        XCTAssertEqual(report.sessions, 2)
        XCTAssertEqual(report.sets, 7)
        let latest = try XCTUnwrap(store.sessions.first)
        XCTAssertEqual(latest.completedSets.compactMap(\.reps), [8, 7, 9])
        let weights = latest.completedSets.compactMap(\.weightPounds)
        XCTAssertEqual(weights.count, 3)
        XCTAssertEqual(weights[0], 20 * 2.2046226218, accuracy: 0.001)
        XCTAssertEqual(weights[1], 20 * 2.2046226218, accuracy: 0.001)
        XCTAssertEqual(weights[2], 30, accuracy: 0.001)
        XCTAssertEqual(olympiaExerciseKey("Cable Straight Bar Bicep Curl"),
                       olympiaExerciseKey("Cable Straight Bar Curl (Smith bar under armpits)"))
        XCTAssertEqual(store.historyExercises().count, 1)
        XCTAssertEqual(store.historyWorkoutSuggestions().first?.exercises.first?.sets, 3)
        let early = try XCTUnwrap(store.sessions.last)
        XCTAssertEqual(early.completedSets[2].reps, 12)
        XCTAssertEqual(early.completedSets[2].preciseReps, 11.5)
        XCTAssertEqual(early.completedSets[2].effectiveReps, 11.5)
        XCTAssertEqual(early.completedSets[2].displayReps, "11.5")

        let encoded = try JSONEncoder().encode(early.completedSets[2])
        var legacy = try XCTUnwrap(JSONSerialization.jsonObject(with: encoded) as? [String: Any])
        legacy.removeValue(forKey: "preciseReps")
        let legacySet = try JSONDecoder().decode(OlympiaCompletedSet.self,
                                                 from: JSONSerialization.data(withJSONObject: legacy))
        XCTAssertNil(legacySet.preciseReps)
        XCTAssertEqual(legacySet.effectiveReps, 12)
    }

    func testHistoryWorkoutSuggestionsKeepsDistinctRoutinesWithSameName() throws {
        let store = try OlympiaTrainingStore(inMemory: true)
        _ = OlympiaNoteImporter.importWorkouts("""
        Pull 3/20/26:
        1. Cable Row - 3 sets - 12 reps - 60lbs
        Pull 3/21/26:
        1. Lat Pulldown - 3 sets - 10 reps - 70lbs
        """, into: store)

        XCTAssertEqual(store.historyWorkoutSuggestions().count, 2)
    }

    func testNoteImportDoesNotTreatDateLookingSlashRepsAsAHeader() throws {
        let store = try OlympiaTrainingStore(inMemory: true)
        let report = OlympiaNoteImporter.importWorkouts("""
        Push 7/28/25:
        1. Bench Press - 12/10/10 - 85lbs
        """, into: store)
        XCTAssertEqual(report.sessions, 1)
        XCTAssertEqual(report.sets, 3)
        XCTAssertEqual(store.sessions.count, 1)
        let session = try XCTUnwrap(store.sessions.first)
        XCTAssertEqual(session.name, "Push")
        XCTAssertEqual(session.completedSets.compactMap(\.reps), [12, 10, 10])
    }

    func testInvalidWorkoutDatesDoNotCreateSessionsOrLeakSetsIntoPriorWorkout() throws {
        let store = try OlympiaTrainingStore(inMemory: true)
        let report = OlympiaNoteImporter.importWorkouts("""
        Push 7/28/25:
        1. Bench Press - 12/10/10 - 85lbs
        Invalid February 2/30/25:
        1. Squat - 8/8/8 - 135lbs
        Invalid Month 13/1/25:
        1. Deadlift - 5/5/5 - 185lbs
        Pull 7/29/25:
        1. Row - 10/10/10 - 65lbs
        """, into: store)
        XCTAssertEqual(report.sessions, 2)
        XCTAssertEqual(report.sets, 6)
        XCTAssertEqual(store.sessions.count, 2)
        XCTAssertEqual(Set(store.sessions.map(\.name)), ["Push", "Pull"])
        let push = try XCTUnwrap(store.sessions.first { $0.name == "Push" })
        let pull = try XCTUnwrap(store.sessions.first { $0.name == "Pull" })
        XCTAssertEqual(push.completedSets.map(\.exerciseName), Array(repeating: "Bench Press", count: 3))
        XCTAssertEqual(pull.completedSets.map(\.exerciseName), Array(repeating: "Row", count: 3))
        XCTAssertEqual(push.completedSets.compactMap(\.reps), [12, 10, 10])
    }

    func testZoneLadderRepresentsEveryZoneAndTargetRelationship() {
        for zone in 1...5 {
            let snapshot = SolarZoneSnapshot(beatsPerMinute: 80 + zone * 20, currentZone: zone, targetZone: 3)
            XCTAssertEqual(snapshot.currentZone, zone)
            XCTAssertEqual(snapshot.targetState, zone < 3 ? .belowTarget : zone == 3 ? .inTarget : .aboveTarget)
        }
    }

    func testZoneLadderHasExplicitUnavailableState() {
        let snapshot = SolarZoneSnapshot(beatsPerMinute: nil, currentZone: nil, targetZone: 2)
        XCTAssertEqual(snapshot.targetState, .noTarget)
    }

    func testLiveActivityStateCoversGoodPoorAndDisconnectedSignal() {
        let qualities: [HeartRateActivityAttributes.ContentState.ConnectionQuality] = [.good, .poor, .disconnected]
        XCTAssertEqual(qualities.map(\.label), ["Good signal", "Signal delayed", "Disconnected"])
    }

    func testMonitoringAndWorkoutAreDistinctLiveActivityModes() {
        XCTAssertNotEqual(HeartRateActivityAttributes.Mode.monitoring, .workout)
        XCTAssertEqual(HeartRateActivityAttributes.Mode.monitoring.title, "Monitoring")
        XCTAssertEqual(HeartRateActivityAttributes.Mode.workout.title, "Workout")
    }

    func testPassiveMonitoringStartsWithoutRecordingAndWorkoutTransitionStartsPersistedSession() async throws {
        let defaults = UserDefaults(suiteName: "test.monitoring.\(UUID().uuidString)")!
        let repository = SwiftDataSessionRepository(container: try SolarPersistence.makeContainer(inMemory: true))
        let recording = RecordingController(repository: repository)
        let coordinator = SensorCoordinator(sensor: PolarH9Client(defaults: defaults), recording: recording)
        await coordinator.select(.simulator)
        await coordinator.toggleDemo()
        await coordinator.startMonitoring()
        XCTAssertTrue(coordinator.isMonitoring)
        XCTAssertNil(recording.draft)
        XCTAssertFalse(coordinator.hasActiveRecording)

        await coordinator.startWorkout()
        XCTAssertFalse(coordinator.isMonitoring)
        XCTAssertTrue(coordinator.hasActiveRecording)
        XCTAssertEqual(recording.draft?.purpose, .exerciseSession)
        await coordinator.endWorkout()
        let storedSessions = try await repository.sessions(scope: .all)
        XCTAssertEqual(storedSessions.count, 1)
        await coordinator.toggleDemo()
    }

    func testSignalQualityAgesFromGoodToPoorToDisconnected() {
        let sample: UInt64 = 1_000_000_000
        XCTAssertEqual(HeartRateSignalQualityEvaluator.evaluate(connected: true, reconnecting: false,
                                                                lastSampleNanoseconds: sample, nowNanoseconds: sample + 3_000_000_000), .good)
        XCTAssertEqual(HeartRateSignalQualityEvaluator.evaluate(connected: true, reconnecting: false,
                                                                lastSampleNanoseconds: sample, nowNanoseconds: sample + 3_000_000_001), .poor)
        XCTAssertEqual(HeartRateSignalQualityEvaluator.evaluate(connected: true, reconnecting: false,
                                                                lastSampleNanoseconds: sample, nowNanoseconds: sample + 10_000_000_001), .disconnected)
        XCTAssertEqual(HeartRateSignalQualityEvaluator.evaluate(connected: false, reconnecting: true,
                                                                lastSampleNanoseconds: sample, nowNanoseconds: sample), .poor)
    }

    func testAppearancePresetsRoundTripWithoutLosingAccessibilityChoices() throws {
        for background in SolarBackgroundPreset.allCases {
            for accent in SolarAccentPreset.allCases {
                let original = SolarThemePreferences(background: background, accent: accent, appearance: .system,
                                                     highContrast: true, reducedAnimation: true)
                let decoded = try JSONDecoder().decode(SolarThemePreferences.self,
                                                       from: JSONEncoder().encode(original))
                XCTAssertEqual(decoded, original)
            }
        }
    }

    func testCoachExposesAllObjectivesAndDoesNotInventEvidenceWithoutRealWorkouts() {
        let results = CoachEngine.recommendations(from: [])
        XCTAssertEqual(Set(results.map(\.objective)), Set(CoachingObjective.allCases))
        XCTAssertTrue(results.allSatisfy { !$0.isAvailable })
        XCTAssertTrue(results.allSatisfy { $0.evidence.contains(CoachEngine.algorithmVersion) })
    }
}
