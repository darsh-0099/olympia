# Olympia for iPhone

Native SwiftUI rebuild of the Olympia workout tracker, adapted from the prior web app and the SolarH9 heart-rate project. The display name and app icon are Olympia. The project targets iOS 17 or later.

## Included in the source

- SwiftData workouts, programs, sessions, individual sets, body weight, and workout history.
- Weekly schedules with the same workout on multiple days, or workout rotation with configurable rest days.
- Native workout flow: 120-second equipment prep, previous-set targets, editable weight/reps, wall-clock rest timer, pause/resume, partial completion, and recovery of an interrupted session.
- Home calendar with planned colors and completed sessions, progress charts, Notes/text workout and body-weight imports, JSON export, units, and appearance settings.
- Standard Bluetooth Heart Rate Service (0x180D / 0x2A37) scanning and recording inherited from SolarH9. Polar H9 and WHOOP in HR Broadcast mode are expected to be discoverable if they advertise that standard service; neither has been device-tested in this rebuild.
- Heart-rate Live Activity (Lock Screen and Dynamic Island), a Home Screen launch widget, and large Week/Active Workout widgets.
- Supabase email/password account and manual cloud-sync code, plus row-level-security schema. Cloud sync needs a project URL and publishable key and has not been end-to-end tested.

## Set up Supabase

1. Create a free Supabase project.
2. Run [supabase/schema.sql](supabase/schema.sql) in its SQL Editor.
3. In the iPhone app's Settings, enter the project's HTTPS URL and **publishable/anon** key. Never enter a service-role key.
4. Create an account, confirm its email if required, sign in, and tap Sync now.

The native app uses separate Supabase accounts. It does not automatically inherit the website's ChatGPT session or hosted database. To bring old data over, import the original workout note; the current website JSON export only includes routines, not all historical workouts and weights.

## Build

This Mac currently lacks full Xcode and iOS signing credentials. Hosted builds can compile and package an unprovisioned engineering preview. On a Mac with Xcode 16+ and a configured Apple Developer team, open `SolarH9.xcodeproj`, select the `SolarH9` scheme (the internal scheme name), configure signing and a unique bundle identifier, then archive/export an iOS app.

The private [Olympia GitHub repository](https://github.com/darsh-0099/olympia) has a manual macOS Actions workflow. [Run 36216324484](https://github.com/darsh-0099/olympia/actions/runs/36216324484) successfully compiled for the simulator and packaged an unsigned `Olympia.ipa`. Its regression suite had one failing note-import test; all other tests passed. The importer defect is now fixed in source, with the latest changes awaiting hosted verification. The workflow defaults to focused Olympia experience tests to conserve Actions minutes; enable `full_suite` when dispatching to run every regression test.

For an unprovisioned SideStore preview, run `scripts/build_unsigned_ipa.sh`; it outputs `Olympia.ipa`. The app and extension carry ad-hoc signatures only so SideStore can discover their App Group request. They have no provisioning profile or device-installable signature: SideStore must provision and re-sign both before an iPhone can install them.

## Known gaps before release

- Latest-source hosted verification is pending. Physical-device QA, hardware HR validation, cloud-sync end-to-end testing, and signed installation remain unverified.
- Supabase sync is currently manual and snapshot-based; it needs a robust multi-device conflict/deletion strategy before it is safe to market as seamless real-time sync.
- Native Sign in with Apple and a complete migration from the existing hosted website are not yet connected. Home-widget workout data requires matching App Group provisioning and device verification (see below).
- The note importer covers common dated workout lines and slash-separated reps; unusual free-form lines should be reviewed after import.
## Large home-screen widgets

The Week and Active Workout widgets are `systemLarge` only. They read a compact
snapshot of actual local Olympia training data (schedule, completed sessions,
workout phase/sets, and an optional recent Polar H9 reading). The widgets do not
show demo heart-rate values. A reading disappears after 30 seconds; WidgetKit
controls actual refresh timing, so the widget is not a live heart-rate monitor.

Both the app and widget extension declare the `group.com.olympia.app` App Group.
To show personal data, the installed signatures and provisioning profiles **must
both** authorize the same group. If the shared container cannot be opened (or
the app has not written a snapshot yet), the widgets show an honest unavailable
state and open Olympia when tapped. SideStore may re-sign or remap App Groups;
widget-to-app group sharing has been reported to fail in SideStore even when an
Xcode-installed build works. Verify the final signed app and `.appex` entitlements
and test on-device before relying on data display. The unprovisioned IPA build does
not prove App Group access.
