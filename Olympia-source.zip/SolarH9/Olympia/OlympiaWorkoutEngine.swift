import Foundation
import Combine
@preconcurrency import ActivityKit

/// A wall-clock driven set/rest state machine. Absolute deadlines make countdowns
/// accurate after a screen lock or normal iOS suspension; no synthetic ticks are saved.
@MainActor
final class OlympiaWorkoutEngine: ObservableObject {
    @Published private(set) var session: OlympiaTrainingSession?
    @Published private(set) var secondsRemaining = 0
    @Published private(set) var elapsedSeconds = 0
    private weak var store: OlympiaTrainingStore?
    private var ticker: Task<Void, Never>?
    private var activityTask: Task<Void, Never>?
    private var workoutActivity: Activity<OlympiaWorkoutActivityAttributes>?
    private var lastActivityState: OlympiaWorkoutActivityAttributes.ContentState?
    private var liveHeartRate: Int?
    private var liveHeartRateAt: Date?
    private var lastHeartRatePublish: Date?
    var reduceActivityMotion = false


    init(store: OlympiaTrainingStore) {
        self.store = store
        OlympiaWorkoutActions.engine = self
        if let draft = store.sessions.first(where: { ["preparing", "working", "resting", "paused"].contains($0.status) }) {
            session = draft
            refreshTime()
            startTicker()
            publishActivity()
        }
    }

    var isActive: Bool { session != nil }
    var phase: String { session?.status ?? "idle" }
    var exercises: [OlympiaExercise] { session?.plannedExercises ?? [] }
    var currentExercise: OlympiaExercise? {
        guard let session, exercises.indices.contains(session.exerciseIndex) else { return nil }
        return exercises[session.exerciseIndex]
    }

    var completedSetCount: Int { session?.completedSets.count ?? 0 }
    var totalSetCount: Int { exercises.reduce(0) { $0 + $1.sets } }
    var progress: Double { totalSetCount > 0 ? Double(completedSetCount) / Double(totalSetCount) : 0 }

    func start(_ workout: OlympiaWorkoutTemplate) {
        guard let store else { return }
        if let current = session {
            if ["completed", "partial"].contains(current.status) {
                session = nil
                ticker?.cancel(); ticker = nil
            } else {
                store.errorMessage = "Finish or discard \(current.name) before starting another workout."
                return
            }
        }
        guard !workout.exercises.isEmpty else {
            store.errorMessage = "Add an exercise to \(workout.name) before starting it."
            return
        }
        guard let draft = store.createSession(for: workout) else { return }
        session = draft
        refreshTime(); startTicker(); publishActivity()
        OlympiaHaptics.acceptedAction()
    }

    func beginNow() {
        guard let session, session.status == "preparing" else { return }
        let now = Date()
        // An expired prep deadline may be observed after suspension; the workout
        // clock still began when prep ended. Starting early begins it now.
        session.startedAt = min(now, session.phaseDeadline ?? now)
        session.status = "working"
        session.phaseDeadline = nil
        store?.persistSession(session)
        refreshTime(); publishActivity()
    }

    @discardableResult
    func completeSet(weightPounds: Double?, reps: Int?) -> Bool {
        guard let session, session.status == "working", let exercise = currentExercise else { return false }
        let value = weightPounds.flatMap { $0 >= 0 && $0 <= 2000 ? $0 : nil }
        let repetitions = reps.flatMap { $0 >= 0 && $0 <= 1000 ? $0 : nil }
        guard value != nil || repetitions != nil else { return false }
        var sets = session.completedSets
        sets.append(OlympiaCompletedSet(exerciseName: exercise.name,
                                         exercisePosition: session.exerciseIndex,
                                         setNumber: session.setNumber,
                                         weightPounds: value, reps: repetitions,
                                         restSeconds: exercise.restSeconds,
                                         completedAt: .now))
        session.completedSets = sets
        let isLastSet = session.setNumber >= exercise.sets
        let isLastExercise = session.exerciseIndex >= exercises.count - 1
        if isLastSet && isLastExercise { return finish() }
        if isLastSet { session.exerciseIndex += 1; session.setNumber = 1 }
        else { session.setNumber += 1 }
        session.status = "resting"
        session.phaseDeadline = .now.addingTimeInterval(TimeInterval(max(0, exercise.restSeconds)))
        guard store?.persistSession(session) == true else { refreshTime(); return false }
        refreshTime(); publishActivity()
        return true
    }

    func adjustRest(by seconds: Int) {
        guard let session, session.status == "resting" else { return }
        let remaining = (session.phaseDeadline ?? .now).timeIntervalSinceNow + TimeInterval(seconds)
        if remaining <= 0 { skipRest(); return }
        session.phaseDeadline = .now.addingTimeInterval(remaining)
        store?.persistSession(session)
        refreshTime(); publishActivity()
    }

    func skipRest() {
        guard let session, session.status == "resting" else { return }
        session.status = "working"; session.phaseDeadline = nil
        store?.persistSession(session); refreshTime(); publishActivity()
    }

    func pause() {
        guard let session, ["working", "resting"].contains(session.status) else { return }
        session.pausedPhase = session.status
        session.pausedRemaining = max(0, (session.phaseDeadline ?? .now).timeIntervalSinceNow)
        session.phaseDeadline = nil; session.pausedAt = .now; session.status = "paused"
        store?.persistSession(session); refreshTime(); publishActivity()
    }

    func resume() {
        guard let session, session.status == "paused" else { return }
        if let pausedAt = session.pausedAt {
            session.totalPausedSeconds += Date().timeIntervalSince(pausedAt)
        }
        session.pausedAt = nil
        session.status = session.pausedPhase ?? "working"
        if session.status == "resting" {
            session.phaseDeadline = .now.addingTimeInterval(session.pausedRemaining)
        }
        session.pausedPhase = nil; session.pausedRemaining = 0
        store?.persistSession(session); refreshTime(); publishActivity()
    }

    @discardableResult
    func finish() -> Bool {
        guard let session else { return false }
        if session.status == "paused", let pausedAt = session.pausedAt {
            session.totalPausedSeconds += Date().timeIntervalSince(pausedAt)
        }
        session.pausedAt = nil; session.phaseDeadline = nil; session.endedAt = .now
        session.status = session.completedSets.count >= totalSetCount ? "completed" : "partial"
        guard store?.persistSession(session) == true else { refreshTime(); return false }
        self.session = nil
        ticker?.cancel(); ticker = nil
        publishActivity()
        return true
    }

    func cancel() {
        guard let session else { return }
        // Discard means discard, even when the user has already logged sets.
        // The separate finish() action preserves partial workouts.
        store?.deleteSession(session)
        self.session = nil
        ticker?.cancel(); ticker = nil
        secondsRemaining = 0; elapsedSeconds = 0
        publishActivity()
    }

    func refreshTime() {
        guard let session else { return }
        let elapsed = max(0, Int(session.duration.rounded(.down)))
        if elapsedSeconds != elapsed { elapsedSeconds = elapsed }
        if let deadline = session.phaseDeadline {
            let remaining = max(0, Int(deadline.timeIntervalSinceNow.rounded(.up)))
            if secondsRemaining != remaining { secondsRemaining = remaining }
            if remaining == 0 {
                if session.status == "preparing" { beginNow() }
                else if session.status == "resting" { skipRest() }
            }
        } else if session.status == "paused" {
            let remaining = max(0, Int(session.pausedRemaining.rounded(.up)))
            if secondsRemaining != remaining { secondsRemaining = remaining }
        } else if secondsRemaining != 0 { secondsRemaining = 0 }
    }

    func updateActivityHeartRate(_ bpm: Int?, sampledAt: Date?) {
        liveHeartRate = bpm
        liveHeartRateAt = sampledAt
        let now = Date()
        if bpm == nil || lastHeartRatePublish.map({ now.timeIntervalSince($0) >= 15 }) != false {
            lastHeartRatePublish = now
            publishActivity()
        }
    }

    func publishActivity() {
        guard store?.isInMemory == false else { return }
        let preceding = activityTask
        activityTask = Task { @MainActor [weak self] in
            await preceding?.value
            guard let self else { return }
            await self.synchronizeActivity()
        }
    }

    func waitForActivity() async { await activityTask?.value }

    func activityState() -> OlympiaWorkoutActivityAttributes.ContentState? {
        guard let session else { return nil }
        let exercise = currentExercise
        let previous = store?.previousSet(workoutID: session.workoutID,
                                          exercise: exercise?.name ?? "", setNumber: session.setNumber,
                                          excluding: session.id)
        let pounds = previous?.weightPounds ?? exercise?.targetWeightPounds
        let kilograms = UserDefaults.standard.string(forKey: "olympia.units") == "kg"
        let weight = pounds.map { String(format: "%g %@", kilograms ? $0 / 2.2046226218 : $0, kilograms ? "kg" : "lb") }
        let reps = previous?.displayReps
        let target = [weight, reps.map { "\($0) reps" }].compactMap { $0 }.joined(separator: " × ")
        let timerLength = session.status == "preparing" ? 120 : max(1, session.completedSets.last?.restSeconds ?? 90)
        return .init(workoutName: session.name, exerciseName: exercise?.name ?? "Workout",
                     phase: session.status, setNumber: session.setNumber, exerciseSets: exercise?.sets ?? 0,
                     completedSets: completedSetCount, totalSets: totalSetCount,
                     target: target.isEmpty ? "Open workout to enter your set" : target,
                     deadline: session.phaseDeadline,
                     countdownStart: session.phaseDeadline.map { min(Date(), $0.addingTimeInterval(-Double(timerLength))) },
                     elapsedStart: session.startedAt.addingTimeInterval(session.totalPausedSeconds),
                     frozenElapsed: max(0, Int(session.duration)),
                     pausedRemaining: max(0, Int(session.pausedRemaining.rounded(.up))),
                     pausedPhase: session.pausedPhase,
                     heartRate: liveHeartRate, heartRateUpdatedAt: liveHeartRateAt,
                     reduceMotion: reduceActivityMotion)
    }

    private func synchronizeActivity() async {
        let existing = Activity<OlympiaWorkoutActivityAttributes>.activities
        guard let state = activityState(), let session else {
            for activity in existing { await activity.end(nil, dismissalPolicy: .immediate) }
            workoutActivity = nil; lastActivityState = nil
            return
        }
        for activity in existing where activity.attributes.sessionID != session.id {
            await activity.end(nil, dismissalPolicy: .immediate)
        }
        if workoutActivity?.attributes.sessionID != session.id {
            workoutActivity = existing.first { $0.attributes.sessionID == session.id && $0.activityState == .active }
            lastActivityState = nil
        }
        let staleDate = state.heartRateUpdatedAt?.addingTimeInterval(30)
        if let activity = workoutActivity {
            guard state != lastActivityState else { return }
            await activity.update(.init(state: state, staleDate: staleDate))
        } else if ActivityAuthorizationInfo().areActivitiesEnabled {
            do {
                workoutActivity = try Activity.request(attributes: .init(sessionID: session.id),
                                                      content: .init(state: state, staleDate: staleDate), pushType: nil)
            } catch {
                // Sensor-free training remains usable if system Live Activities are disabled.
                workoutActivity = nil
            }
        }
        if workoutActivity != nil { lastActivityState = state }
    }

    private func startTicker() {
        ticker?.cancel()
        ticker = Task { [weak self] in
            while !Task.isCancelled, self?.session != nil {
                self?.refreshTime()
                try? await Task.sleep(for: .milliseconds(250))
            }
        }
    }
}


/// LiveActivityIntent runs in the app process. Reuse the visible engine or recover
/// the persisted workout after a cold launch, without needing shared entitlements.
@MainActor
enum OlympiaWorkoutActions {
    static weak var engine: OlympiaWorkoutEngine?
    static weak var sensor: SensorCoordinator?

    static func perform(sessionID: String, action: String) async throws {
        guard let id = UUID(uuidString: sessionID) else { return }
        let recoveryStore: OlympiaTrainingStore?
        let active: OlympiaWorkoutEngine
        if let engine {
            recoveryStore = nil
            active = engine
        } else {
            let store = try OlympiaTrainingStore()
            recoveryStore = store
            active = OlympiaWorkoutEngine(store: store)
        }
        guard active.session?.id == id else { return }
        active.refreshTime()
        let oldPhase = active.phase
        switch action {
        case "pause": active.pause()
        case "resume": active.resume()
        case "skipRest": active.skipRest()
        default: return
        }
        if oldPhase != active.phase, action == "pause" || action == "resume",
           let recordingID = active.session?.heartRateSessionID {
            await sensor?.pauseOrResume(id: recordingID)
        }
        await active.waitForActivity()
        withExtendedLifetime(recoveryStore) {}
    }
}
