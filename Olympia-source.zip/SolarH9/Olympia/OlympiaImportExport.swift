import Foundation

struct OlympiaImportReport {
    var sessions = 0
    var sets = 0
    var weights = 0
    var skipped = 0
}

@MainActor enum OlympiaNoteImporter {
    static func importWorkouts(_ text: String, into store: OlympiaTrainingStore) -> OlympiaImportReport {
        var report = OlympiaImportReport()
        var title = ""
        var date: Date?
        var sets: [OlympiaCompletedSet] = []
        var position = 0
        func flush() {
            if let date, !sets.isEmpty {
                store.addImportedSession(name: title, date: date, sets: sets)
                report.sessions += 1; report.sets += sets.count
            }
            sets = []; position = 0
        }
        for raw in text.components(separatedBy: .newlines) {
            let line = raw.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !line.isEmpty else { continue }
            // A workout header ends with its date. Exercise rows can contain
            // date-shaped rep sequences (even valid dates such as 12/10/10).
            if !line.contains(" - "),
               firstMatch(#"^\d+[.)]\s*"#, in: line) == nil,
               let found = firstMatch(#"^(.*?)\b(\d{1,2})/(\d{1,2})/(\d{2}|\d{4})\s*:?$"#, in: line) {
                flush()
                date = strictDate(month: found[2], day: found[3], year: found[4])
                title = found[1]
                    .trimmingCharacters(in: CharacterSet(charactersIn: " :,-"))
                if title.isEmpty { title = "Workout" }
                if date == nil { report.skipped += 1 }
                continue
            }
            guard let workoutDate = date else { report.skipped += 1; continue }
            let content = line.replacingOccurrences(of: #"^\d+[.)]\s*"#, with: "", options: .regularExpression)
            let parts = content.components(separatedBy: " - ")
            guard let exercise = parts.first?.trimmingCharacters(in: .whitespaces), !exercise.isEmpty else {
                report.skipped += 1; continue
            }
            position += 1
            let explicit = firstMatch(#"(\d+)\s*sets?"#, in: content.lowercased()).flatMap { Int($0[1]) }
                ?? (parts.count > 1 ? Int(parts[1].trimmingCharacters(in: .whitespaces)) : nil)
            let repsChunk = parts.dropFirst().first {
                $0.contains("/") || $0.lowercased().contains("rep") || ($0.contains(",") && $0.lowercased().contains("lb"))
            } ?? ""
            // Commas can separate weight groups ("8/7 (35lbs), 9 (30lbs)").
            // Parse the first rep number in each slash segment, ignoring notes
            // such as "8 + 3 half" and weights in parentheses.
            let repGroups = repsChunk.components(separatedBy: ",")
            let parsedReps: [(reps: Double, weightPounds: Double?)] = repGroups.flatMap { group in
                let groupWeight = firstMatch(#"(\d+(?:\.\d+)?)\s*(lbs?|pounds?|kg)\b"#, in: group.lowercased())
                    .flatMap { match -> Double? in
                        guard let value = Double(match[1]) else { return nil }
                        return match[2] == "kg" ? value * 2.2046226218 : value
                    }
                let cleaned = group.replacingOccurrences(of: #"\([^)]*\)"#, with: "", options: .regularExpression)
                return cleaned.components(separatedBy: "/").compactMap { segment -> (reps: Double, weightPounds: Double?)? in
                    guard let match = firstMatch(#"\b(\d+(?:\.\d+)?)\b"#, in: segment),
                          let value = Double(match[1]) else { return nil }
                    return (value, groupWeight)
                }
            }
            let fixedReps = firstMatch(#"\b(\d+(?:\.\d+)?)\s*reps?\b"#, in: content.lowercased())
                .flatMap { Double($0[1]) }
            // Notes such as "4 sets - 12 reps (Last set 15)" describe a
            // different final set; preserving it matters in workout history.
            let finalSetReps = firstMatch(#"\blast\s+set\s+(\d+(?:\.\d+)?)\b"#, in: content.lowercased())
                .flatMap { Double($0[1]) }
            let count = min(20, max(1, explicit ?? (parsedReps.isEmpty ? 1 : parsedReps.count)))
            let weightSource = parts.last ?? content
            let weight = (firstMatch(#"(\d+(?:\.\d+)?)\s*(lbs?|pounds?|kg)\b"#, in: weightSource.lowercased())
                ?? firstMatch(#"(\d+(?:\.\d+)?)\s*(lbs?|pounds?|kg)\b"#, in: content.lowercased()))
                .flatMap { match -> Double? in
                    guard let value = Double(match[1]) else { return nil }
                    return match[2] == "kg" ? value * 2.2046226218 : value
                }
            for index in 0..<count {
                let recorded = index < parsedReps.count ? parsedReps[index] : nil
                let setWeight = recorded?.weightPounds ?? weight
                let preciseReps = index == count - 1 ? (finalSetReps ?? recorded?.reps ?? fixedReps)
                    : (recorded?.reps ?? fixedReps)
                sets.append(OlympiaCompletedSet(exerciseName: exercise, exercisePosition: position - 1,
                                                setNumber: index + 1,
                                                weightPounds: setWeight,
                                                reps: preciseReps.map { Int($0.rounded()) },
                                                preciseReps: preciseReps,
                                                restSeconds: 0, completedAt: workoutDate))
            }
        }
        flush()
        return report
    }

    static func importWeights(_ text: String, into store: OlympiaTrainingStore) -> OlympiaImportReport {
        var report = OlympiaImportReport()
        for line in text.components(separatedBy: .newlines) {
            guard let dateParts = firstMatch(#"\b(\d{1,2})/(\d{1,2})/(\d{2,4})\b"#, in: line),
                  let valueParts = firstMatch(#"(\d{2,3}(?:\.\d+)?)\s*(lb|lbs|pounds|kg)\b"#, in: line.lowercased()) else {
                report.skipped += 1; continue
            }
            guard let date = strictDate(month: dateParts[1], day: dateParts[2], year: dateParts[3]),
                  let value = Double(valueParts[1]) else { report.skipped += 1; continue }
            if !store.importedWeightExists(on: date) {
                store.logWeight(value, kilograms: valueParts[2] == "kg", at: date)
                report.weights += 1
            }
        }
        return report
    }

    private static func strictDate(month: String, day: String, year: String) -> Date? {
        guard let month = Int(month), let day = Int(day), let rawYear = Int(year),
              year.count == 2 || year.count == 4 else { return nil }
        let year = rawYear < 100 ? 2000 + rawYear : rawYear
        let calendar = Calendar(identifier: .gregorian)
        let components = DateComponents(year: year, month: month, day: day)
        guard let date = calendar.date(from: components) else { return nil }
        // Calendar.date(from:) normalizes overflow (for example February 30).
        let actual = calendar.dateComponents([.year, .month, .day], from: date)
        guard actual.year == year, actual.month == month, actual.day == day else { return nil }
        return date
    }

    private static func firstMatch(_ pattern: String, in text: String) -> [String]? {
        guard let regex = try? NSRegularExpression(pattern: pattern, options: [.caseInsensitive]),
              let match = regex.firstMatch(in: text, range: NSRange(text.startIndex..<text.endIndex, in: text)) else { return nil }
        return (0..<match.numberOfRanges).map { index in
            guard let range = Range(match.range(at: index), in: text) else { return "" }
            return String(text[range])
        }
    }
}

struct OlympiaBackup: Codable {
    struct Workout: Codable { var id: UUID; var name: String; var colorHex: String; var exercises: [OlympiaExercise] }
    struct Session: Codable {
        var id: UUID
        var name: String
        var startedAt: Date
        var endedAt: Date?
        var status: String
        var averageHeartRate: Double?
        var sets: [OlympiaCompletedSet]
        var workoutID: UUID?
        var plannedExercises: [OlympiaExercise]
        var heartRateSessionID: UUID?
        var exerciseIndex: Int
        var setNumber: Int
        var phaseDeadline: Date?
        var pausedRemaining: TimeInterval
        var pausedAt: Date?
        var pausedPhase: String?
        var totalPausedSeconds: TimeInterval

        init(id: UUID, name: String, startedAt: Date, endedAt: Date?, status: String,
             averageHeartRate: Double?, sets: [OlympiaCompletedSet], workoutID: UUID? = nil,
             plannedExercises: [OlympiaExercise] = [], heartRateSessionID: UUID? = nil,
             exerciseIndex: Int = 0, setNumber: Int = 1, phaseDeadline: Date? = nil,
             pausedRemaining: TimeInterval = 0, pausedAt: Date? = nil, pausedPhase: String? = nil,
             totalPausedSeconds: TimeInterval = 0) {
            self.id = id; self.name = name; self.startedAt = startedAt; self.endedAt = endedAt
            self.status = status; self.averageHeartRate = averageHeartRate; self.sets = sets
            self.workoutID = workoutID; self.plannedExercises = plannedExercises
            self.heartRateSessionID = heartRateSessionID; self.exerciseIndex = exerciseIndex
            self.setNumber = setNumber; self.phaseDeadline = phaseDeadline
            self.pausedRemaining = pausedRemaining; self.pausedAt = pausedAt
            self.pausedPhase = pausedPhase; self.totalPausedSeconds = totalPausedSeconds
        }

        private enum CodingKeys: String, CodingKey {
            case id, name, startedAt, endedAt, status, averageHeartRate, sets, workoutID
            case plannedExercises, heartRateSessionID, exerciseIndex, setNumber, phaseDeadline
            case pausedRemaining, pausedAt, pausedPhase, totalPausedSeconds
        }

        init(from decoder: Decoder) throws {
            let values = try decoder.container(keyedBy: CodingKeys.self)
            id = try values.decode(UUID.self, forKey: .id)
            name = try values.decode(String.self, forKey: .name)
            startedAt = try values.decode(Date.self, forKey: .startedAt)
            endedAt = try values.decodeIfPresent(Date.self, forKey: .endedAt)
            status = try values.decode(String.self, forKey: .status)
            averageHeartRate = try values.decodeIfPresent(Double.self, forKey: .averageHeartRate)
            sets = try values.decode([OlympiaCompletedSet].self, forKey: .sets)
            workoutID = try values.decodeIfPresent(UUID.self, forKey: .workoutID)
            plannedExercises = try values.decodeIfPresent([OlympiaExercise].self, forKey: .plannedExercises) ?? []
            heartRateSessionID = try values.decodeIfPresent(UUID.self, forKey: .heartRateSessionID)
            exerciseIndex = try values.decodeIfPresent(Int.self, forKey: .exerciseIndex) ?? 0
            setNumber = try values.decodeIfPresent(Int.self, forKey: .setNumber) ?? 1
            phaseDeadline = try values.decodeIfPresent(Date.self, forKey: .phaseDeadline)
            pausedRemaining = try values.decodeIfPresent(TimeInterval.self, forKey: .pausedRemaining) ?? 0
            pausedAt = try values.decodeIfPresent(Date.self, forKey: .pausedAt)
            pausedPhase = try values.decodeIfPresent(String.self, forKey: .pausedPhase)
            totalPausedSeconds = try values.decodeIfPresent(TimeInterval.self, forKey: .totalPausedSeconds) ?? 0
        }
    }
    struct Program: Codable {
        var id: UUID
        var name: String
        var scheduleType: String
        var rotationRestDays: Int
        var rotationAnchor: Date
        var scheduleShiftDays: Int
        var slots: [OlympiaProgramSlot]
        var checkedThrough: Date? = nil
        var missedDates: [Date] = []
        var skippedDates: [Date] = []
        var substitutions: [OlympiaDaySubstitution] = []
        var repeatCount: Int? = nil
        var isActive: Bool
        fileprivate var isActiveWasMissing: Bool = false

        init(id: UUID, name: String, scheduleType: String, rotationRestDays: Int,
             rotationAnchor: Date, scheduleShiftDays: Int, slots: [OlympiaProgramSlot],
             checkedThrough: Date? = nil, missedDates: [Date] = [], skippedDates: [Date] = [],
             substitutions: [OlympiaDaySubstitution] = [], repeatCount: Int? = nil,
             isActive: Bool = true) {
            self.id = id; self.name = name; self.scheduleType = scheduleType
            self.rotationRestDays = rotationRestDays; self.rotationAnchor = rotationAnchor
            self.scheduleShiftDays = scheduleShiftDays; self.slots = slots
            self.checkedThrough = checkedThrough; self.missedDates = missedDates
            self.skippedDates = skippedDates
            self.substitutions = substitutions; self.repeatCount = repeatCount
            self.isActive = isActive
            self.isActiveWasMissing = false
        }

        private enum CodingKeys: String, CodingKey {
            case id, name, scheduleType, rotationRestDays, rotationAnchor, scheduleShiftDays
            case slots, checkedThrough, missedDates, skippedDates, substitutions, repeatCount, isActive
        }

        init(from decoder: Decoder) throws {
            let values = try decoder.container(keyedBy: CodingKeys.self)
            id = try values.decode(UUID.self, forKey: .id)
            name = try values.decode(String.self, forKey: .name)
            scheduleType = try values.decode(String.self, forKey: .scheduleType)
            rotationRestDays = try values.decode(Int.self, forKey: .rotationRestDays)
            rotationAnchor = try values.decode(Date.self, forKey: .rotationAnchor)
            scheduleShiftDays = try values.decode(Int.self, forKey: .scheduleShiftDays)
            slots = try values.decode([OlympiaProgramSlot].self, forKey: .slots)
            checkedThrough = try values.decodeIfPresent(Date.self, forKey: .checkedThrough)
            missedDates = try values.decodeIfPresent([Date].self, forKey: .missedDates) ?? []
            skippedDates = try values.decodeIfPresent([Date].self, forKey: .skippedDates) ?? []
            substitutions = try values.decodeIfPresent([OlympiaDaySubstitution].self, forKey: .substitutions) ?? []
            repeatCount = try values.decodeIfPresent(Int.self, forKey: .repeatCount)
            isActive = try values.decodeIfPresent(Bool.self, forKey: .isActive) ?? false
            isActiveWasMissing = !values.contains(.isActive)
        }
    }
    struct Weight: Codable { var id: UUID; var measuredAt: Date; var pounds: Double }
    var workouts: [Workout]
    var sessions: [Session]
    var programs: [Program]
    var weights: [Weight]

    init(workouts: [Workout], sessions: [Session], programs: [Program], weights: [Weight]) {
        self.workouts = workouts; self.sessions = sessions
        self.programs = programs; self.weights = weights
    }

    private enum CodingKeys: String, CodingKey {
        case workouts, sessions, programs, weights
    }

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        workouts = try values.decode([Workout].self, forKey: .workouts)
        sessions = try values.decode([Session].self, forKey: .sessions)
        programs = try values.decode([Program].self, forKey: .programs)
        weights = try values.decode([Weight].self, forKey: .weights)
        // Historical backups did not record which program was active. Retain
        // the old importer's first-program behavior without activating all of
        // them or changing a modern backup that intentionally has none active.
        if !programs.contains(where: \.isActive),
           let firstLegacy = programs.firstIndex(where: \.isActiveWasMissing) {
            programs[firstLegacy].isActive = true
        }
    }

    enum MergeError: LocalizedError, Equatable {
        case duplicateID(collection: String, id: UUID)
        case conflict(collection: String, id: UUID)
        case multipleActivePrograms

        var errorDescription: String? {
            switch self {
            case let .duplicateID(collection, id):
                return "Duplicate \(collection) ID in backup: \(id)."
            case let .conflict(collection, id):
                return "Both devices changed the same \(collection) record (\(id))."
            case .multipleActivePrograms:
                return "The merged backup has more than one active program."
            }
        }
    }

    /// Merge two descendants of a common uploaded snapshot. Missing IDs are
    /// deletions, so a deletion wins over an unchanged copy and conflicts with
    /// an edit. The result is independent of storage and does not mutate inputs.
    func merged(base: OlympiaBackup, remote: OlympiaBackup) throws -> OlympiaBackup {
        let encoder = JSONEncoder()
        encoder.dateEncodingStrategy = .iso8601
        encoder.outputFormatting = .sortedKeys
        let result = OlympiaBackup(
            workouts: try Self.merge(base.workouts, workouts, remote.workouts,
                                     collection: "workout", id: { $0.id }, encoder: encoder),
            sessions: try Self.merge(base.sessions, sessions, remote.sessions,
                                     collection: "session", id: { $0.id }, encoder: encoder),
            programs: try Self.merge(base.programs, programs, remote.programs,
                                     collection: "program", id: { $0.id }, encoder: encoder),
            weights: try Self.merge(base.weights, weights, remote.weights,
                                    collection: "weight", id: { $0.id }, encoder: encoder))
        guard result.programs.filter(\.isActive).count <= 1 else {
            throw MergeError.multipleActivePrograms
        }
        return result
    }

    private static func merge<Item: Encodable>(_ base: [Item], _ local: [Item], _ remote: [Item],
                                                collection: String, id: (Item) -> UUID,
                                                encoder: JSONEncoder) throws -> [Item] {
        func keyed(_ items: [Item]) throws -> [UUID: Item] {
            var result: [UUID: Item] = [:]
            for item in items {
                let key = id(item)
                guard result.updateValue(item, forKey: key) == nil else {
                    throw MergeError.duplicateID(collection: collection, id: key)
                }
            }
            return result
        }
        let baseByID = try keyed(base)
        let localByID = try keyed(local)
        let remoteByID = try keyed(remote)
        let orderedIDs = local.map(id) + remote.map(id).filter { localByID[$0] == nil }
        var result: [Item] = []
        for key in orderedIDs {
            let ancestor = baseByID[key]
            let ours = localByID[key]
            let theirs = remoteByID[key]
            let ancestorData = try ancestor.map { try encoder.encode($0) }
            let oursData = try ours.map { try encoder.encode($0) }
            let theirsData = try theirs.map { try encoder.encode($0) }
            let oursChanged = oursData != ancestorData
            let theirsChanged = theirsData != ancestorData
            if oursChanged && theirsChanged && oursData != theirsData {
                throw MergeError.conflict(collection: collection, id: key)
            }
            if let selected = theirsChanged ? theirs : ours {
                result.append(selected)
            }
        }
        return result
    }

    /// The current importer keeps local records when IDs match. Detect differing
    /// remote versions before that importer can silently replace them on upload.
    func hasDivergentOverlap(with remote: OlympiaBackup) -> Bool {
        let encoder = JSONEncoder()
        encoder.dateEncodingStrategy = .iso8601
        encoder.outputFormatting = .sortedKeys
        func differs<Item: Encodable>(_ local: [Item], _ remote: [Item], id: (Item) -> UUID) -> Bool {
            let byID = Dictionary(local.map { (id($0), $0) }, uniquingKeysWith: { first, _ in first })
            return remote.contains { item in
                guard let localItem = byID[id(item)] else { return false }
                // Compare the actual wire representation: ISO-8601 encoding
                // drops subsecond precision, so raw Date equality is too strict.
                guard let localData = try? encoder.encode(localItem),
                      let remoteData = try? encoder.encode(item) else { return true }
                return localData != remoteData
            }
        }
        return differs(workouts, remote.workouts, id: { $0.id }) ||
            differs(sessions, remote.sessions, id: { $0.id }) ||
            differs(programs, remote.programs, id: { $0.id }) ||
            differs(weights, remote.weights, id: { $0.id })
    }

    /// Without tombstones, a local-only ID may have been deleted remotely.
    /// Treat it as unresolved after any unobserved remote revision change.
    func hasLocalOnlyRecords(comparedWith remote: OlympiaBackup) -> Bool {
        func hasLocalOnly<Item>(_ local: [Item], _ remote: [Item], id: (Item) -> UUID) -> Bool {
            let remoteIDs = Set(remote.map(id))
            return local.contains { !remoteIDs.contains(id($0)) }
        }
        return hasLocalOnly(workouts, remote.workouts, id: { $0.id }) ||
            hasLocalOnly(sessions, remote.sessions, id: { $0.id }) ||
            hasLocalOnly(programs, remote.programs, id: { $0.id }) ||
            hasLocalOnly(weights, remote.weights, id: { $0.id })
    }

    func conflicts(with remote: OlympiaBackup, lastUploadedRevision: Int?, remoteRevision: Int) -> Bool {
        lastUploadedRevision != remoteRevision &&
            (hasDivergentOverlap(with: remote) || hasLocalOnlyRecords(comparedWith: remote))
    }

    @MainActor init(store: OlympiaTrainingStore) {
        workouts = store.workouts.map { Workout(id: $0.id, name: $0.name, colorHex: $0.colorHex, exercises: $0.exercises) }
        sessions = store.sessions.map { Session(id: $0.id, name: $0.name, startedAt: $0.startedAt,
                                                endedAt: $0.endedAt, status: $0.status,
                                                averageHeartRate: $0.averageHeartRate, sets: $0.completedSets,
                                                workoutID: $0.workoutID, plannedExercises: $0.plannedExercises,
                                                heartRateSessionID: $0.heartRateSessionID,
                                                exerciseIndex: $0.exerciseIndex, setNumber: $0.setNumber,
                                                phaseDeadline: $0.phaseDeadline, pausedRemaining: $0.pausedRemaining,
                                                pausedAt: $0.pausedAt, pausedPhase: $0.pausedPhase,
                                                totalPausedSeconds: $0.totalPausedSeconds) }
        programs = store.programs.map { Program(id: $0.id, name: $0.name, scheduleType: $0.scheduleType,
                                                rotationRestDays: $0.rotationRestDays, rotationAnchor: $0.rotationAnchor,
                                                scheduleShiftDays: $0.scheduleShiftDays,
                                                slots: $0.slots,
                                                checkedThrough: $0.schedulePayload.checkedThrough,
                                                missedDates: $0.schedulePayload.missedDates,
                                                skippedDates: $0.schedulePayload.skippedDates,
                                                substitutions: $0.schedulePayload.substitutions,
                                                repeatCount: $0.schedulePayload.repeatCount,
                                                isActive: $0.isActive) }
        weights = store.weights.map { Weight(id: $0.id, measuredAt: $0.measuredAt, pounds: $0.pounds) }
    }
}
