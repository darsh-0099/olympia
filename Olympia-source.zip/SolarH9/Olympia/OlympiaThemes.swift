// OlympiaThemes.swift — GENERATED from the design tokens in tokens/themes.json.
// NOTE: written without a Swift compiler in the loop. Treat as a faithful starting point; fix any compile nits.
import SwiftUI

enum ThemeBackground { case mesh, image(String) }

struct OlympiaTheme: Identifiable, Equatable {
    static func == (l: Self, r: Self) -> Bool { l.id == r.id }
    let id: String            // persisted in @AppStorage("theme")
    let name: String
    let text: Color           // primary text
    var muted: Color          // secondary text
    let hairline: Color       // dividers inside glass cards
    let specular: Color       // top inner highlight on glass (fallback look only)
    var glassFill: Color      // fallback fill when .glassEffect is unavailable
    var glassStroke: Color
    let shadowColor: Color
    let blurFallback: CGFloat // fallback blur radius (CSS px ~ pt) for Material-less recreation
    let pull: Color           // workout colour slot "p" (Back/Pull)
    let push: Color           // slot "b" (Chest/Push)
    let legs: Color           // slot "a" (Legs/Accessories)
    let ringStart: Color
    let ringEnd: Color
    let accent: Color         // links, small icons, selected text
    let buttonFill: Color     // primary CTA pill fill
    let buttonText: Color
    let tileText: Color       // letter on the A/B/C/D tiles
    let tabAccentStart: Color // centre "+" button gradient
    let tabAccentEnd: Color
    let background: ThemeBackground
    let backgroundFallbackTop: Color
    let backgroundFallbackBottom: Color

    var workoutColors: [Color] { [pull, push, legs] }
    var chart: Color { ringStart }
    var ringGradient: LinearGradient { LinearGradient(colors: [ringStart, ringEnd], startPoint: .topLeading, endPoint: .bottomTrailing) }
    var tabAccentGradient: LinearGradient { LinearGradient(colors: [tabAccentStart, tabAccentEnd], startPoint: .topLeading, endPoint: .bottomTrailing) }
}

private struct OlympiaThemeKey: EnvironmentKey {
    static let defaultValue: OlympiaTheme = .aurora
}

extension EnvironmentValues {
    var olympiaTheme: OlympiaTheme {
        get { self[OlympiaThemeKey.self] }
        set { self[OlympiaThemeKey.self] = newValue }
    }
}

struct ThemeBackgroundView: View {
    @Environment(\.olympiaTheme) private var theme

    var body: some View {
        GeometryReader { geometry in
            ZStack(alignment: .top) {
                LinearGradient(colors: [theme.backgroundFallbackTop, theme.backgroundFallbackBottom],
                               startPoint: .top, endPoint: .bottom)
                image
                    .resizable()
                    .scaledToFill()
                    .frame(width: geometry.size.width, height: geometry.size.height)
                    .clipped()
                if ["forest", "tropical", "dusk", "sakura", "space"].contains(theme.id) {
                    LinearGradient(colors: [Color.black.opacity(headerScrimOpacity), .clear],
                                   startPoint: .top, endPoint: .bottom)
                        .frame(height: 330)
                        .frame(maxHeight: .infinity, alignment: .top)
                }
            }
        }
        .ignoresSafeArea()
        .accessibilityHidden(true)
    }

    private var image: Image {
        switch theme.background {
        case .mesh: return Image("BgAurora")
        case .image(let name): return Image(name)
        }
    }

    private var headerScrimOpacity: Double {
        switch theme.id {
        case "sakura": return 0.55
        case "forest": return 0.52
        case "tropical": return 0.45
        default: return 0.34
        }
    }
}

private struct OlympiaGlassSurface: ViewModifier {
    @Environment(\.olympiaTheme) private var theme
    @Environment(\.accessibilityReduceTransparency) private var reduceTransparency
    @Environment(\.colorSchemeContrast) private var systemContrast
    @AppStorage("olympia.highContrast") private var higherContrast = false
    let radius: CGFloat
    let tint: Color?
    let interactive: Bool

    func body(content: Content) -> some View {
        let shape = RoundedRectangle(cornerRadius: radius, style: .continuous)
        let contrast = higherContrast || systemContrast == .increased
        return Group {
            if #available(iOS 26.0, *), !reduceTransparency {
                content
                    .glassEffect(glass, in: shape)
                    .background(shape.fill(contrast ? Color.white.opacity(0.12) : .clear))
                    .overlay(shape.strokeBorder(theme.glassStroke.opacity(contrast ? 1 : 0.68),
                                                lineWidth: contrast ? 1.5 : 0.8))
            } else {
                content
                    .background(shape.fill(reduceTransparency ? Color.black.opacity(0.9) : theme.glassFill))
                    .background(reduceTransparency ? AnyShapeStyle(Color.clear) : AnyShapeStyle(.ultraThinMaterial), in: shape)
                    .overlay(shape.strokeBorder(theme.glassStroke, lineWidth: contrast ? 1.5 : 1))
                    .shadow(color: theme.shadowColor, radius: 16, y: 12)
            }
        }
    }

    @available(iOS 26.0, *)
    private var glass: Glass {
        var value = Glass.regular
        if let tint { value = value.tint(tint) }
        if interactive { value = value.interactive() }
        return value
    }
}

extension View {
    func glassSurface(radius: CGFloat = 28, tint: Color? = nil, interactive: Bool = false) -> some View {
        modifier(OlympiaGlassSurface(radius: radius, tint: tint, interactive: interactive))
    }
}

/// Sheets reuse the calendar card's exact glass modifier and theme tokens.
/// Clear presentation prevents UIKit's opaque sheet fill masking the material.
private struct OlympiaCalendarGlassSheet: ViewModifier {
    func body(content: Content) -> some View {
        content
            .background { Color.clear.glassSurface(radius: 28).ignoresSafeArea() }
            .presentationBackground(.clear)
            .presentationCornerRadius(28)
    }
}

extension View {
    func calendarGlassSheet() -> some View { modifier(OlympiaCalendarGlassSheet()) }
}

struct OlympiaGlassGroup<Content: View>: View {
    let content: Content
    init(@ViewBuilder content: () -> Content) { self.content = content() }
    var body: some View {
        if #available(iOS 26.0, *) {
            GlassEffectContainer(spacing: 10) { content }
        } else {
            content
        }
    }
}

struct OlympiaPrimaryButton: View {
    @Environment(\.olympiaTheme) private var theme
    let title: String
    var showsArrow = false
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            ZStack {
                Text(title).font(.system(size: 17, weight: .heavy))
                if showsArrow {
                    HStack { Spacer(); Image(systemName: "arrow.right").font(.system(size: 18, weight: .bold)) }
                        .padding(.trailing, 22)
                }
            }
            .foregroundStyle(theme.buttonText)
            .frame(maxWidth: .infinity, minHeight: 58)
            .background(theme.buttonFill, in: Capsule())
            .overlay(Capsule().strokeBorder(.white.opacity(0.45), lineWidth: 1))
            .shadow(color: theme.shadowColor, radius: 14, y: 9)
        }
        .buttonStyle(OlympiaPressStyle())
    }
}

struct OlympiaWorkoutTile: View {
    @Environment(\.olympiaTheme) private var theme
    let letter: String
    let color: Color

    var body: some View {
        Text(letter)
            .font(.system(size: 19, weight: .heavy))
            .foregroundStyle(theme.tileText)
            .frame(width: 44, height: 44)
            .background(LinearGradient(colors: [color, color.opacity(0.6)], startPoint: .topLeading,
                                       endPoint: .bottomTrailing),
                        in: RoundedRectangle(cornerRadius: 15, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 15).strokeBorder(.white.opacity(0.38), lineWidth: 1))
            .shadow(color: color.opacity(0.4), radius: 9, y: 5)
    }
}

struct OlympiaProgressRing: View {
    @Environment(\.olympiaTheme) private var theme
    let progress: Double
    var lineWidth: CGFloat = 12

    var body: some View {
        ZStack {
            Circle().stroke(.white.opacity(0.16), lineWidth: lineWidth)
            Circle().trim(from: 0, to: min(1, max(0, progress)))
                .stroke(theme.ringGradient, style: StrokeStyle(lineWidth: lineWidth + 5, lineCap: .round))
                .blur(radius: 9).opacity(0.5).rotationEffect(.degrees(-90))
            Circle().trim(from: 0, to: min(1, max(0, progress)))
                .stroke(theme.ringGradient, style: StrokeStyle(lineWidth: lineWidth, lineCap: .round))
                .rotationEffect(.degrees(-90))
        }
        .accessibilityValue("\(Int(progress * 100)) percent")
    }
}

extension OlympiaTheme {
    static let aurora = OlympiaTheme(
        id: "aurora", name: "Aurora",
        text: Color(.sRGB, red: 1.000, green: 1.000, blue: 1.000, opacity: 1.000), muted: Color(.sRGB, red: 1.000, green: 1.000, blue: 1.000, opacity: 0.640), hairline: Color(.sRGB, red: 1.000, green: 1.000, blue: 1.000, opacity: 0.133), specular: Color(.sRGB, red: 1.000, green: 1.000, blue: 1.000, opacity: 0.400),
        glassFill: Color(.sRGB, red: 1.000, green: 1.000, blue: 1.000, opacity: 0.130), glassStroke: Color(.sRGB, red: 1.000, green: 1.000, blue: 1.000, opacity: 0.240), shadowColor: Color(.sRGB, red: 0.000, green: 0.000, blue: 0.000, opacity: 0.280), blurFallback: 26,
        pull: Color(.sRGB, red: 0.655, green: 0.545, blue: 0.980, opacity: 1.000), push: Color(.sRGB, red: 0.231, green: 0.616, blue: 1.000, opacity: 1.000), legs: Color(.sRGB, red: 0.961, green: 0.722, blue: 0.353, opacity: 1.000),
        ringStart: Color(.sRGB, red: 0.478, green: 0.843, blue: 1.000, opacity: 1.000), ringEnd: Color(.sRGB, red: 0.765, green: 0.420, blue: 1.000, opacity: 1.000), accent: Color(.sRGB, red: 0.624, green: 0.863, blue: 1.000, opacity: 1.000),
        buttonFill: Color(.sRGB, red: 1.000, green: 1.000, blue: 1.000, opacity: 0.920), buttonText: Color(.sRGB, red: 0.125, green: 0.063, blue: 0.271, opacity: 1.000), tileText: Color(.sRGB, red: 0.051, green: 0.051, blue: 0.125, opacity: 1.000),
        tabAccentStart: Color(.sRGB, red: 0.478, green: 0.549, blue: 1.000, opacity: 1.000), tabAccentEnd: Color(.sRGB, red: 0.765, green: 0.420, blue: 1.000, opacity: 1.000),
        background: .mesh, backgroundFallbackTop: Color(.sRGB, red: 0.478, green: 0.302, blue: 1.000, opacity: 1.000), backgroundFallbackBottom: Color(.sRGB, red: 0.043, green: 0.039, blue: 0.122, opacity: 1.000))
    static let forest = OlympiaTheme(
        id: "forest", name: "Forest",
        text: Color(.sRGB, red: 0.949, green: 1.000, blue: 0.953, opacity: 1.000), muted: Color(.sRGB, red: 0.922, green: 1.000, blue: 0.933, opacity: 0.660), hairline: Color(.sRGB, red: 1.000, green: 1.000, blue: 1.000, opacity: 0.133), specular: Color(.sRGB, red: 1.000, green: 1.000, blue: 1.000, opacity: 0.380),
        glassFill: Color(.sRGB, red: 0.784, green: 1.000, blue: 0.843, opacity: 0.090), glassStroke: Color(.sRGB, red: 0.863, green: 1.000, blue: 0.882, opacity: 0.220), shadowColor: Color(.sRGB, red: 0.000, green: 0.000, blue: 0.000, opacity: 0.350), blurFallback: 9,
        pull: Color(.sRGB, red: 0.718, green: 0.941, blue: 0.439, opacity: 1.000), push: Color(.sRGB, red: 0.310, green: 0.820, blue: 0.773, opacity: 1.000), legs: Color(.sRGB, red: 1.000, green: 0.820, blue: 0.400, opacity: 1.000),
        ringStart: Color(.sRGB, red: 0.718, green: 0.941, blue: 0.439, opacity: 1.000), ringEnd: Color(.sRGB, red: 0.310, green: 0.820, blue: 0.773, opacity: 1.000), accent: Color(.sRGB, red: 0.718, green: 0.941, blue: 0.439, opacity: 1.000),
        buttonFill: Color(.sRGB, red: 0.941, green: 1.000, blue: 0.882, opacity: 0.940), buttonText: Color(.sRGB, red: 0.043, green: 0.165, blue: 0.102, opacity: 1.000), tileText: Color(.sRGB, red: 0.031, green: 0.129, blue: 0.086, opacity: 1.000),
        tabAccentStart: Color(.sRGB, red: 0.482, green: 0.847, blue: 0.561, opacity: 1.000), tabAccentEnd: Color(.sRGB, red: 0.184, green: 0.710, blue: 0.604, opacity: 1.000),
        background: .image("BgForest"), backgroundFallbackTop: Color(.sRGB, red: 0.290, green: 0.616, blue: 0.384, opacity: 1.000), backgroundFallbackBottom: Color(.sRGB, red: 0.024, green: 0.090, blue: 0.059, opacity: 1.000))
    static let tropical = OlympiaTheme(
        id: "tropical", name: "Tropical",
        text: Color(.sRGB, red: 1.000, green: 1.000, blue: 1.000, opacity: 1.000), muted: Color(.sRGB, red: 1.000, green: 1.000, blue: 1.000, opacity: 0.780), hairline: Color(.sRGB, red: 1.000, green: 1.000, blue: 1.000, opacity: 0.188), specular: Color(.sRGB, red: 1.000, green: 1.000, blue: 1.000, opacity: 0.500),
        glassFill: Color(.sRGB, red: 0.000, green: 0.275, blue: 0.392, opacity: 0.170), glassStroke: Color(.sRGB, red: 1.000, green: 1.000, blue: 1.000, opacity: 0.380), shadowColor: Color(.sRGB, red: 0.000, green: 0.196, blue: 0.314, opacity: 0.300), blurFallback: 8,
        pull: Color(.sRGB, red: 1.000, green: 0.541, blue: 0.604, opacity: 1.000), push: Color(.sRGB, red: 0.290, green: 0.941, blue: 0.941, opacity: 1.000), legs: Color(.sRGB, red: 1.000, green: 0.878, blue: 0.541, opacity: 1.000),
        ringStart: Color(.sRGB, red: 1.000, green: 0.878, blue: 0.541, opacity: 1.000), ringEnd: Color(.sRGB, red: 1.000, green: 0.541, blue: 0.604, opacity: 1.000), accent: Color(.sRGB, red: 1.000, green: 0.914, blue: 0.659, opacity: 1.000),
        buttonFill: Color(.sRGB, red: 1.000, green: 1.000, blue: 1.000, opacity: 0.950), buttonText: Color(.sRGB, red: 0.024, green: 0.290, blue: 0.388, opacity: 1.000), tileText: Color(.sRGB, red: 0.024, green: 0.220, blue: 0.310, opacity: 1.000),
        tabAccentStart: Color(.sRGB, red: 1.000, green: 0.604, blue: 0.478, opacity: 1.000), tabAccentEnd: Color(.sRGB, red: 1.000, green: 0.435, blue: 0.569, opacity: 1.000),
        background: .image("BgTropical"), backgroundFallbackTop: Color(.sRGB, red: 1.000, green: 0.941, blue: 0.659, opacity: 1.000), backgroundFallbackBottom: Color(.sRGB, red: 0.024, green: 0.227, blue: 0.345, opacity: 1.000))
    static let dusk = OlympiaTheme(
        id: "dusk", name: "Dusk",
        text: Color(.sRGB, red: 1.000, green: 0.965, blue: 0.933, opacity: 1.000), muted: Color(.sRGB, red: 1.000, green: 0.941, blue: 0.902, opacity: 0.700), hairline: Color(.sRGB, red: 1.000, green: 1.000, blue: 1.000, opacity: 0.149), specular: Color(.sRGB, red: 1.000, green: 1.000, blue: 1.000, opacity: 0.400),
        glassFill: Color(.sRGB, red: 1.000, green: 0.922, blue: 0.863, opacity: 0.130), glassStroke: Color(.sRGB, red: 1.000, green: 0.922, blue: 0.863, opacity: 0.260), shadowColor: Color(.sRGB, red: 0.157, green: 0.000, blue: 0.118, opacity: 0.350), blurFallback: 26,
        pull: Color(.sRGB, red: 0.827, green: 0.639, blue: 1.000, opacity: 1.000), push: Color(.sRGB, red: 1.000, green: 0.690, blue: 0.439, opacity: 1.000), legs: Color(.sRGB, red: 1.000, green: 0.878, blue: 0.541, opacity: 1.000),
        ringStart: Color(.sRGB, red: 1.000, green: 0.851, blue: 0.627, opacity: 1.000), ringEnd: Color(.sRGB, red: 1.000, green: 0.541, blue: 0.659, opacity: 1.000), accent: Color(.sRGB, red: 1.000, green: 0.851, blue: 0.627, opacity: 1.000),
        buttonFill: Color(.sRGB, red: 1.000, green: 0.965, blue: 0.933, opacity: 0.940), buttonText: Color(.sRGB, red: 0.290, green: 0.086, blue: 0.259, opacity: 1.000), tileText: Color(.sRGB, red: 0.165, green: 0.051, blue: 0.173, opacity: 1.000),
        tabAccentStart: Color(.sRGB, red: 1.000, green: 0.604, blue: 0.361, opacity: 1.000), tabAccentEnd: Color(.sRGB, red: 1.000, green: 0.361, blue: 0.541, opacity: 1.000),
        background: .image("BgDusk"), backgroundFallbackTop: Color(.sRGB, red: 0.106, green: 0.043, blue: 0.204, opacity: 1.000), backgroundFallbackBottom: Color(.sRGB, red: 1.000, green: 0.702, blue: 0.420, opacity: 1.000))
    static let sakura = OlympiaTheme(
        id: "sakura", name: "Sakura",
        text: Color(.sRGB, red: 1.000, green: 0.945, blue: 0.969, opacity: 1.000), muted: Color(.sRGB, red: 1.000, green: 0.922, blue: 0.961, opacity: 0.680), hairline: Color(.sRGB, red: 1.000, green: 1.000, blue: 1.000, opacity: 0.141), specular: Color(.sRGB, red: 1.000, green: 1.000, blue: 1.000, opacity: 0.400),
        glassFill: Color(.sRGB, red: 1.000, green: 0.882, blue: 0.941, opacity: 0.120), glassStroke: Color(.sRGB, red: 1.000, green: 0.882, blue: 0.941, opacity: 0.240), shadowColor: Color(.sRGB, red: 0.078, green: 0.000, blue: 0.118, opacity: 0.380), blurFallback: 26,
        pull: Color(.sRGB, red: 1.000, green: 0.604, blue: 0.784, opacity: 1.000), push: Color(.sRGB, red: 0.714, green: 0.612, blue: 1.000, opacity: 1.000), legs: Color(.sRGB, red: 1.000, green: 0.816, blue: 0.627, opacity: 1.000),
        ringStart: Color(.sRGB, red: 1.000, green: 0.718, blue: 0.835, opacity: 1.000), ringEnd: Color(.sRGB, red: 0.714, green: 0.612, blue: 1.000, opacity: 1.000), accent: Color(.sRGB, red: 1.000, green: 0.718, blue: 0.835, opacity: 1.000),
        buttonFill: Color(.sRGB, red: 1.000, green: 0.945, blue: 0.969, opacity: 0.940), buttonText: Color(.sRGB, red: 0.227, green: 0.078, blue: 0.314, opacity: 1.000), tileText: Color(.sRGB, red: 0.165, green: 0.059, blue: 0.227, opacity: 1.000),
        tabAccentStart: Color(.sRGB, red: 1.000, green: 0.541, blue: 0.753, opacity: 1.000), tabAccentEnd: Color(.sRGB, red: 0.690, green: 0.486, blue: 1.000, opacity: 1.000),
        background: .image("BgSakura"), backgroundFallbackTop: Color(.sRGB, red: 0.541, green: 0.227, blue: 0.541, opacity: 1.000), backgroundFallbackBottom: Color(.sRGB, red: 0.392, green: 0.157, blue: 0.373, opacity: 1.000))
    static let space = OlympiaTheme(
        id: "space", name: "Space",
        text: Color(.sRGB, red: 1.000, green: 1.000, blue: 1.000, opacity: 1.000), muted: Color(.sRGB, red: 1.000, green: 1.000, blue: 1.000, opacity: 0.640), hairline: Color(.sRGB, red: 1.000, green: 1.000, blue: 1.000, opacity: 0.133), specular: Color(.sRGB, red: 1.000, green: 1.000, blue: 1.000, opacity: 0.400),
        glassFill: Color(.sRGB, red: 0.745, green: 0.784, blue: 1.000, opacity: 0.100), glassStroke: Color(.sRGB, red: 0.784, green: 0.824, blue: 1.000, opacity: 0.220), shadowColor: Color(.sRGB, red: 0.000, green: 0.000, blue: 0.000, opacity: 0.280), blurFallback: 14,
        pull: Color(.sRGB, red: 0.714, green: 0.612, blue: 1.000, opacity: 1.000), push: Color(.sRGB, red: 0.361, green: 0.784, blue: 1.000, opacity: 1.000), legs: Color(.sRGB, red: 1.000, green: 0.722, blue: 0.420, opacity: 1.000),
        ringStart: Color(.sRGB, red: 0.478, green: 0.843, blue: 1.000, opacity: 1.000), ringEnd: Color(.sRGB, red: 0.765, green: 0.420, blue: 1.000, opacity: 1.000), accent: Color(.sRGB, red: 0.624, green: 0.863, blue: 1.000, opacity: 1.000),
        buttonFill: Color(.sRGB, red: 1.000, green: 1.000, blue: 1.000, opacity: 0.920), buttonText: Color(.sRGB, red: 0.125, green: 0.063, blue: 0.271, opacity: 1.000), tileText: Color(.sRGB, red: 0.051, green: 0.051, blue: 0.125, opacity: 1.000),
        tabAccentStart: Color(.sRGB, red: 0.478, green: 0.549, blue: 1.000, opacity: 1.000), tabAccentEnd: Color(.sRGB, red: 0.765, green: 0.420, blue: 1.000, opacity: 1.000),
        background: .image("BgSpace"), backgroundFallbackTop: Color(.sRGB, red: 0.020, green: 0.024, blue: 0.059, opacity: 1.000), backgroundFallbackBottom: Color(.sRGB, red: 0.012, green: 0.016, blue: 0.063, opacity: 1.000))
    static let all: [OlympiaTheme] = [aurora, forest, tropical, dusk, sakura, space]
    static func named(_ id: String) -> OlympiaTheme { all.first { $0.id == id } ?? .aurora }
}

#if DEBUG
/// Launch directly from a SwiftUI preview to check the shared surfaces across all six scenes.
struct OlympiaThemeGallery: View {
    @State private var selectedID = "aurora"
    private var selected: OlympiaTheme { .named(selectedID) }

    var body: some View {
        ZStack {
            ThemeBackgroundView()
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    Text("Aurora Glass gallery").font(.largeTitle.bold())
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack {
                            ForEach(OlympiaTheme.all) { theme in
                                Button(theme.name) { selectedID = theme.id }
                                    .font(.subheadline.bold())
                                    .padding(.horizontal, 15).frame(minHeight: 44)
                                    .glassSurface(radius: 22, tint: selectedID == theme.id ? theme.accent.opacity(0.2) : nil)
                            }
                        }
                    }
                    HStack {
                        OlympiaWorkoutTile(letter: "A", color: selected.pull)
                        OlympiaWorkoutTile(letter: "B", color: selected.push)
                        OlympiaWorkoutTile(letter: "C", color: selected.legs)
                    }
                    OlympiaGlassGroup {
                        VStack(spacing: 10) {
                            Text("Glass card · \(selected.name)")
                                .frame(maxWidth: .infinity, minHeight: 80)
                                .glassSurface(radius: 28)
                            HStack {
                                OlympiaProgressRing(progress: 0.65).frame(width: 124, height: 124)
                                Text("65% progress").font(.title2.bold())
                            }.frame(maxWidth: .infinity).padding().glassSurface(radius: 32)
                        }
                    }
                    OlympiaPrimaryButton(title: "Primary action", showsArrow: true) {}
                }
                .foregroundStyle(selected.text)
                .padding(20)
            }
        }
        .environment(\.olympiaTheme, selected)
        .preferredColorScheme(.dark)
    }
}
#endif
