import SwiftUI
import UIKit

private let workoutColors = ["#63C7FF", "#FF7384", "#AD8CFF", "#73DD91", "#FFC56B"]

@MainActor enum OlympiaHaptics {
    static func acceptedAction() {
        let enabled = UserDefaults.standard.object(forKey: "olympia.hapticsEnabled") as? Bool ?? true
        acceptedAction(enabled: enabled)
    }

    static func acceptedAction(enabled: Bool) {
        guard enabled else { return }
        UIImpactFeedbackGenerator(style: .light).impactOccurred()
    }

    static func workoutCompleted() {
        let enabled = UserDefaults.standard.object(forKey: "olympia.hapticsEnabled") as? Bool ?? true
        guard enabled else { return }
        UINotificationFeedbackGenerator().notificationOccurred(.success)
    }
}

struct OlympiaProgramView: View {
    @ObservedObject var store: OlympiaTrainingStore
    @ObservedObject var engine: OlympiaWorkoutEngine
    @Environment(\.olympiaColors) private var colors
    @Environment(\.olympiaTheme) private var theme
    @State private var editingWorkout: OlympiaWorkoutTemplate?
    @State private var showNewWorkout = false
    @State private var showHistoryAdd = false
    @State private var showProgram = false
    @State private var makeRestSlotID: UUID?
    @State private var pendingDelete: OlympiaWorkoutTemplate?

    private var cycleSlots: [OlympiaProgramSlot] {
        guard let program = store.activeProgram, program.scheduleType == "rotation" else { return [] }
        return program.slots + (0..<program.rotationRestDays).map { _ in .rest() }
    }

    private func workout(for slot: OlympiaProgramSlot) -> OlympiaWorkoutTemplate? {
        store.workouts.first { $0.id == slot.workoutID }
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 24) {
                    HStack {
                        VStack(alignment: .leading, spacing: 4) {
                            Text("YOUR TRAINING PLAN").font(.caption2.bold()).tracking(1.5).foregroundStyle(colors.muted)
                            Text("Program").font(.system(size: 34, weight: .heavy)).foregroundStyle(colors.text)
                        }
                        Spacer()
                        Menu {
                            Button("New workout", systemImage: "plus") { showNewWorkout = true }
                            Button("Add from history", systemImage: "clock.arrow.circlepath") { showHistoryAdd = true }
                        } label: {
                            Image(systemName: "plus").font(.title3.bold()).foregroundStyle(colors.text)
                                .frame(width: 46, height: 46).glassSurface(radius: 23, interactive: true)
                        }.accessibilityLabel("Add workout")
                    }
                    VStack(alignment: .leading, spacing: 18) {
                        HStack(alignment: .top) {
                            VStack(alignment: .leading, spacing: 4) {
                                Text(store.activeProgram?.name ?? "My Program")
                                    .font(.title2.bold()).foregroundStyle(colors.text)
                                Text(store.activeProgram.map { program in
                                    program.scheduleType == "rotation"
                                        ? "\(cycleSlots.count)-day flexible cycle · \(program.repeatCount.map { "\($0) cycles" } ?? "repeats") · starts \(program.rotationAnchor.formatted(.dateTime.month(.abbreviated).day()))"
                                        : "Weekly schedule · \(program.slots.count) workout slots"
                                } ?? "Create workouts, then set up your schedule.")
                                    .font(.subheadline).foregroundStyle(colors.muted)
                            }
                            Spacer(minLength: 8)
                            if !store.workouts.isEmpty {
                                Button("Edit schedule ›") {
                                    makeRestSlotID = nil
                                    showProgram = true
                                }
                                    .font(.subheadline.bold()).foregroundStyle(theme.accent)
                                    .padding(.horizontal, 12).padding(.vertical, 9)
                                    .glassSurface(radius: 18, interactive: true)
                            }
                        }
                        if !cycleSlots.isEmpty {
                            ScrollView(.horizontal) {
                                HStack(spacing: 10) {
                                    ForEach(Array(cycleSlots.enumerated()), id: \.offset) { index, slot in
                                        let workout = workout(for: slot)
                                        Button {
                                            if let workout { editingWorkout = workout }
                                            else { makeRestSlotID = nil; showProgram = true }
                                        } label: {
                                            VStack(spacing: 6) {
                                                Text("DAY \(index + 1)").font(.system(size: 10, weight: .heavy)).foregroundStyle(colors.muted)
                                                ZStack {
                                                    RoundedRectangle(cornerRadius: 15).fill(slot.isRest ? Color.white.opacity(0.08) : Color(olympiaHex: slot.colorHex))
                                                    if slot.isRest { Image(systemName: "moon").foregroundStyle(colors.text) }
                                                    else { Text(workout.map { item in
                                                        String(UnicodeScalar(65 + (store.workouts.firstIndex { $0.id == item.id } ?? 0) % 26)!)
                                                    } ?? "W")
                                                            .font(.title3.weight(.black)).foregroundStyle(theme.tileText) }
                                                }.frame(width: 46, height: 46)
                                                Text(workout?.name ?? "Rest").font(.caption2).foregroundStyle(colors.muted)
                                                    .lineLimit(1).frame(width: 58)
                                            }
                                        }.buttonStyle(OlympiaPressStyle())
                                            .contextMenu {
                                                if !slot.isRest {
                                                    Button("Swap workout") {
                                                        makeRestSlotID = nil
                                                        showProgram = true
                                                    }
                                                    Button("Make rest day", systemImage: "moon") {
                                                        makeRestSlotID = slot.id
                                                        showProgram = true
                                                    }
                                                }
                                                Button("Edit cycle") {
                                                    makeRestSlotID = nil
                                                    showProgram = true
                                                }
                                            }
                                    }
                                }
                            }.scrollIndicators(.hidden)
                        }
                    }.padding(20).frame(maxWidth: .infinity, alignment: .leading).glassSurface(radius: 30)
                    HStack {
                        Text("Workouts").font(.title2.bold()).foregroundStyle(colors.text)
                        Spacer()
                        Text("\(store.workouts.count) · tap to edit").font(.caption).foregroundStyle(colors.muted)
                    }
                    if store.workouts.isEmpty {
                        OlympiaCard {
                            VStack(spacing: 10) {
                                Image(systemName: "dumbbell").font(.title).foregroundStyle(colors.accent)
                                Text("Create your first workout").font(.headline)
                                Text("Add exercises, sets, and rest times. Scheduling happens in Program.")
                                    .font(.caption).foregroundStyle(colors.muted).multilineTextAlignment(.center)
                                Button("Create workout") { showNewWorkout = true }
                                    .font(.subheadline.bold()).foregroundStyle(.white)
                                    .frame(maxWidth: .infinity).padding(.vertical, 15)
                                    .background(colors.accent, in: Capsule())
                                    .buttonStyle(OlympiaPressStyle())
                            }.frame(maxWidth: .infinity).padding(.vertical, 18)
                        }
                    } else {
                        VStack(spacing: 0) {
                            ForEach(Array(store.workouts.enumerated()), id: \.element.id) { index, workout in
                                if index > 0 { Divider().overlay(colors.border).padding(.leading, 14) }
                                OlympiaSwipeToDeleteRow(delete: { pendingDelete = workout }, duplicate: {
                                    _ = store.upsertWorkout(id: nil, name: "\(workout.name) Copy",
                                        colorHex: workout.colorHex, exercises: workout.exercises)
                                }) {
                                HStack(spacing: 12) {
                                    Button { editingWorkout = workout } label: {
                                        HStack(spacing: 12) {
                                            Text(String(UnicodeScalar(65 + index % 26)!))
                                                .font(.title3.weight(.black)).foregroundStyle(theme.tileText)
                                                .frame(width: 44, height: 44)
                                                .background(Color(olympiaHex: workout.colorHex), in: RoundedRectangle(cornerRadius: 15))
                                            VStack(alignment: .leading, spacing: 4) {
                                                Text(workout.name).font(.headline).foregroundStyle(colors.text)
                                                    .multilineTextAlignment(.leading).fixedSize(horizontal: false, vertical: true)
                                                Text("\(workout.exercises.count) exercises · \(workout.exercises.reduce(0) { $0 + $1.sets }) sets")
                                                    .font(.caption).foregroundStyle(colors.muted)
                                                Text(workout.exercises.map(\.name).joined(separator: " · "))
                                                    .font(.caption).foregroundStyle(colors.muted).lineLimit(1)
                                            }
                                            Spacer(minLength: 0)
                                        }.contentShape(Rectangle())
                                    }.buttonStyle(.plain)
                                    Button { engine.start(workout) } label: {
                                        Image(systemName: "play.fill").font(.subheadline)
                                            .foregroundStyle(colors.text).frame(width: 44, height: 44)
                                            .glassSurface(radius: 22, interactive: true)
                                    }.accessibilityLabel("Start \(workout.name)")
                                    Image(systemName: "chevron.right").font(.caption.bold()).foregroundStyle(colors.muted)
                                }.padding(.vertical, 14)
                                    .contextMenu {
                                        Button("Duplicate", systemImage: "plus.square.on.square") {
                                            _ = store.upsertWorkout(id: nil, name: "\(workout.name) Copy",
                                                colorHex: workout.colorHex, exercises: workout.exercises)
                                        }
                                        Button("Delete", systemImage: "trash", role: .destructive) { pendingDelete = workout }
                                    }
                                }
                            }
                        }.padding(.horizontal, 16).glassSurface(radius: 28)
                    }
                    HStack(spacing: 12) {
                        Button("＋ New workout") { showNewWorkout = true }
                        Button("↺ Add from history") { showHistoryAdd = true }
                    }.font(.subheadline.bold()).buttonStyle(.plain)
                        .frame(maxWidth: .infinity).padding(.vertical, 16).glassSurface(radius: 24)
                }.padding(20)
            }.scrollIndicators(.hidden).background { ThemeBackgroundView() }.toolbar(.hidden, for: .navigationBar)
            .sheet(isPresented: $showNewWorkout) { OlympiaWorkoutEditor(store: store, workout: nil) }
            .sheet(isPresented: $showHistoryAdd) { OlympiaWorkoutEditor(store: store, workout: nil, openHistoryOnAppear: true) }
            .sheet(item: $editingWorkout) { OlympiaWorkoutEditor(store: store, workout: $0) }
            .sheet(isPresented: $showProgram) { OlympiaProgramEditor(store: store, makeRestSlotID: makeRestSlotID) }
            .confirmationDialog("Delete this workout? History will be kept.", isPresented: Binding(
                get: { pendingDelete != nil }, set: { if !$0 { pendingDelete = nil } })) {
                Button("Delete workout", role: .destructive) {
                    if let pendingDelete { store.deleteWorkout(pendingDelete) }
                    pendingDelete = nil
                }
            }
        }
    }
}

private struct OlympiaSwipeToDeleteRow<Content: View>: View {
    let delete: () -> Void
    let duplicate: (() -> Void)?
    @ViewBuilder let content: Content
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var offset: CGFloat = 0
    @State private var rowWidth: CGFloat = 320

    var body: some View {
        ZStack(alignment: .trailing) {
            HStack(spacing: 0) {
                if let duplicate {
                    Button {
                        duplicate()
                        withAnimation(reduceMotion ? nil : .snappy) { offset = 0 }
                    } label: {
                        Label("Duplicate", systemImage: "plus.square.on.square")
                            .labelStyle(.iconOnly).frame(width: 88, height: 100)
                    }.buttonStyle(.plain).background(Color.blue.opacity(0.75))
                }
                Button(role: .destructive) {
                    withAnimation(reduceMotion ? nil : .snappy) { offset = 0 }
                    delete()
                } label: {
                    Label("Delete", systemImage: "trash")
                        .labelStyle(.iconOnly).frame(width: 88, height: 100)
                }.buttonStyle(.plain).background(Color.red.opacity(0.75))
            }
            .font(.caption.bold()).foregroundStyle(.white)
            .opacity(offset < 0 ? 1 : 0)
            .allowsHitTesting(offset < 0)
            .accessibilityHidden(offset >= 0)
            .clipShape(RoundedRectangle(cornerRadius: 18))
            content
                .offset(x: offset)
                .simultaneousGesture(
                    DragGesture(minimumDistance: 18)
                        .onChanged { value in
                            guard abs(value.translation.width) > abs(value.translation.height) else { return }
                            offset = min(0, max(-rowWidth, value.translation.width))
                        }
                        .onEnded { value in
                            guard abs(value.translation.width) > abs(value.translation.height) else { return }
                            if value.translation.width < -max(180, rowWidth * 0.8) {
                                offset = 0
                                delete()
                            } else {
                                withAnimation(reduceMotion ? nil : .easeOut(duration: 0.18)) {
                                    offset = value.translation.width < -44 ? (duplicate == nil ? -88 : -176) : 0
                                }
                            }
                        }
                )
        }
        .background {
            GeometryReader { geometry in
                Color.clear
                    .onAppear { rowWidth = geometry.size.width }
                    .onChange(of: geometry.size.width) { _, width in rowWidth = width }
            }
        }
        .accessibilityAction(named: "Delete workout", delete)
        .accessibilityAction(named: "Duplicate workout") { duplicate?() }
    }
}

struct OlympiaWorkoutEditor: View {
    @ObservedObject var store: OlympiaTrainingStore
    let workout: OlympiaWorkoutTemplate?
    var openHistoryOnAppear = false
    @Environment(\.dismiss) private var dismiss
    @Environment(\.olympiaColors) private var colors
    @Environment(\.olympiaTheme) private var theme
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var name = ""
    @State private var colorHex = workoutColors[0]
    @State private var exercises: [OlympiaExercise] = []
    @State private var showHistory = false
    @State private var historySearch = ""
    @State private var historyTab = "Workouts"
    @State private var selectedHistorySession: OlympiaTrainingSession?
    @State private var showAllHistory = false
    @State private var showDelete = false
    @State private var showValidation = false
    @State private var validationMessage = ""
    @State private var pendingHistoryWorkout: OlympiaWorkoutSuggestion?
    @State private var weightInputs: [UUID: String] = [:]
    @State private var didLoadWorkout = false
    @State private var didOpenHistory = false
    @State private var allSets = 2
    @State private var allRest = 90
    @State private var showAllExercises = false
    @FocusState private var textFieldFocused: Bool
    @AppStorage("olympia.units") private var units = "lb"
    @AppStorage("olympia.hapticsEnabled") private var hapticsEnabled = true

    private var canSave: Bool {
        !name.trimmingCharacters(in: .whitespaces).isEmpty &&
        exercises.contains { !$0.name.trimmingCharacters(in: .whitespaces).isEmpty } &&
        !hasInvalidTargetWeight
    }

    private var hasInvalidTargetWeight: Bool {
        exercises.contains { exercise in
            guard let text = weightInputs[exercise.id]?.trimmingCharacters(in: .whitespacesAndNewlines),
                  !text.isEmpty else { return false }
            guard let value = Double(text) else { return true }
            return !value.isFinite || !(0...2000).contains(value)
        }
    }

    var body: some View {
        NavigationStack {
            Form {
                Section("Workout") {
                    TextField("Workout name", text: $name)
                        .font(.title2.bold()).foregroundStyle(Color(olympiaHex: colorHex))
                        .textInputAutocapitalization(.words).padding(.vertical, 8)
                        .focused($textFieldFocused)
                    ScrollView(.horizontal) {
                        HStack(spacing: 12) {
                            Label("Color", systemImage: "paintpalette.fill").font(.subheadline.bold())
                            ForEach(workoutColors, id: \.self) { hex in
                                Button { colorHex = hex } label: {
                                    Circle().fill(Color(olympiaHex: hex)).frame(width: 32, height: 32)
                                        .overlay(Circle().stroke(.white, lineWidth: colorHex == hex ? 2 : 0).padding(3))
                                        .frame(width: 44, height: 44)
                                }.buttonStyle(OlympiaPressStyle()).accessibilityLabel("Select workout color \(hex)")
                                    .accessibilityAddTraits(colorHex == hex ? .isSelected : [])
                            }
                        }
                    }.scrollIndicators(.hidden)
                }.listRowBackground(colors.surface)
                Section("Apply to all") {
                    HStack {
                        Text("Sets").font(.subheadline.bold())
                        Stepper("\(allSets)", value: $allSets, in: 1...12).labelsHidden()
                        Text("\(allSets)").monospacedDigit().frame(minWidth: 22)
                        Spacer()
                        Menu("\(allRest)s") {
                            ForEach([0, 30, 45, 60, 90, 120, 150, 180, 240, 300], id: \.self) { seconds in
                                Button(seconds == 0 ? "No rest" : "\(seconds)s") { allRest = seconds }
                            }
                        }
                        Button("Apply") {
                            for index in exercises.indices {
                                exercises[index].sets = allSets
                                exercises[index].restSeconds = allRest
                            }
                            OlympiaHaptics.acceptedAction(enabled: hapticsEnabled)
                        }.font(.subheadline.bold())
                    }.frame(minHeight: 44)
                }.listRowBackground(colors.surface)
                Section {
                    ForEach($exercises) { $exercise in
                        if showAllExercises || (exercises.firstIndex(where: { $0.id == exercise.id }) ?? 0) < 4 {
                        VStack(alignment: .leading, spacing: 14) {
                            TextField("Exercise name", text: $exercise.name)
                                .font(.subheadline.bold()).textInputAutocapitalization(.words)
                                .padding(.horizontal, 13).padding(.vertical, 10)
                                .background(colors.secondarySurface, in: RoundedRectangle(cornerRadius: 12))
                                .focused($textFieldFocused)
                            HStack(alignment: .top, spacing: 12) {
                                VStack(alignment: .leading, spacing: 7) {
                                    Text("SETS").font(.caption2.bold()).foregroundStyle(colors.muted)
                                    HStack(spacing: 0) {
                                        Button {
                                            exercise.sets = max(1, exercise.sets - 1)
                                        } label: {
                                            Image(systemName: "minus")
                                                .frame(width: 44, height: 44)
                                                .contentShape(Rectangle())
                                        }
                                        .disabled(exercise.sets == 1)
                                        .accessibilityLabel("Decrease sets for \(exercise.name)")
                                        Text("\(exercise.sets)")
                                            .font(.subheadline.bold()).monospacedDigit()
                                            .frame(minWidth: 28)
                                            .accessibilityLabel("\(exercise.sets) sets")
                                        Button {
                                            exercise.sets = min(12, exercise.sets + 1)
                                        } label: {
                                            Image(systemName: "plus")
                                                .frame(width: 44, height: 44)
                                                .contentShape(Rectangle())
                                        }
                                        .disabled(exercise.sets == 12)
                                        .accessibilityLabel("Increase sets for \(exercise.name)")
                                    }
                                    .buttonStyle(.borderless)
                                    .foregroundStyle(colors.text)
                                    .background(colors.secondarySurface, in: Capsule())
                                }
                                Spacer(minLength: 0)
                                VStack(alignment: .leading, spacing: 7) {
                                    Text("REST").font(.caption2.bold()).foregroundStyle(colors.muted)
                                    Menu {
                                        ForEach([0, 30, 45, 60, 90, 120, 150, 180, 240, 300], id: \.self) { seconds in
                                            Button(seconds == 0 ? "No rest" : "\(seconds)s") { exercise.restSeconds = seconds }
                                        }
                                    } label: {
                                        HStack(spacing: 4) {
                                            Text(exercise.restSeconds == 0 ? "None" : "\(exercise.restSeconds)s")
                                            Image(systemName: "chevron.up.chevron.down").font(.caption2)
                                        }
                                        .font(.subheadline.bold()).foregroundStyle(colors.text)
                                        .frame(minWidth: 92, minHeight: 42)
                                        .background(colors.secondarySurface, in: Capsule())
                                    }
                                }
                            }
                            HStack(spacing: 10) {
                                Text("Target weight").font(.caption).foregroundStyle(colors.muted)
                                Spacer(minLength: 0)
                                TextField("Optional", text: targetWeightBinding(for: $exercise))
                                    .keyboardType(.decimalPad)
                                    .multilineTextAlignment(.trailing)
                                    .focused($textFieldFocused)
                                    .frame(maxWidth: 96)
                                Text(units).font(.caption).foregroundStyle(colors.muted)
                            }
                            .padding(.horizontal, 12).frame(minHeight: 44)
                            .background(colors.secondarySurface, in: RoundedRectangle(cornerRadius: 12))
                        }.padding(.vertical, 8).listRowBackground(colors.surface)
                            .swipeActions(edge: .trailing, allowsFullSwipe: true) {
                                Button("Delete", role: .destructive) {
                                    exercises.removeAll { $0.id == exercise.id }
                                }
                            }
                        }
                    }.onMove {
                        guard showAllExercises || exercises.count <= 4 else { return }
                        exercises.move(fromOffsets: $0, toOffset: $1)
                    }
                        .onDelete { exercises.remove(atOffsets: $0) }
                    if exercises.count > 4 {
                        Button {
                            withAnimation(reduceMotion ? nil : .snappy) { showAllExercises.toggle() }
                        } label: {
                            Label(showAllExercises ? "Show fewer" : "\(exercises.count - 4) more · \(exercises.dropFirst(4).map(\.name).joined(separator: ", "))",
                                  systemImage: showAllExercises ? "chevron.up" : "chevron.down")
                                .font(.caption.bold()).lineLimit(1)
                        }
                    }
                    Button("Add blank exercise") { exercises.append(OlympiaExercise(name: "", sets: 3, restSeconds: 90)) }
                    Button("Choose from past exercises") { showHistory = true }
                } header: { Text("Exercises · \(exercises.count) · \(exercises.reduce(0) { $0 + $1.sets }) sets · drag to reorder") }
                    .listRowBackground(colors.surface)
                if workout != nil {
                    Section { Button("Delete workout", role: .destructive) { showDelete = true } }
                        .listRowBackground(colors.surface)
                }
            }
            .scrollContentBackground(.hidden).scrollIndicators(.hidden)
            .scrollDismissesKeyboard(.interactively).background(Color.clear)
            .foregroundStyle(colors.text)
            .safeAreaInset(edge: .bottom, spacing: 0) {
                Button {
                    textFieldFocused = false
                    guard canSave else {
                        validationMessage = hasInvalidTargetWeight
                            ? "Enter a target weight from 0 to 2000 \(units), or leave it blank."
                            : "Enter a workout name and at least one exercise name."
                        showValidation = true
                        return
                    }
                    guard store.upsertWorkout(id: workout?.id, name: name, colorHex: colorHex, exercises: exercises) else { return }
                    OlympiaHaptics.acceptedAction(enabled: hapticsEnabled)
                    dismiss()
                } label: {
                    Text(workout == nil ? "Create workout" : "Save workout")
                        .font(.headline.bold()).foregroundStyle(theme.buttonText)
                        .frame(maxWidth: .infinity).frame(minHeight: 52)
                        .background(theme.buttonFill.opacity(canSave ? 1 : 0.35), in: Capsule())
                        .contentShape(Capsule())
                }
                    .buttonStyle(.borderless)
                    .padding(.horizontal, 20).padding(.vertical, 12)
            }
            .navigationTitle(workout == nil ? "New workout" : "Edit workout")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) { EditButton() }
                ToolbarItemGroup(placement: .keyboard) {
                    Spacer()
                    Button("Done") { textFieldFocused = false }
                }
            }
            .onAppear {
                if openHistoryOnAppear && !didOpenHistory {
                    didOpenHistory = true
                    showHistory = true
                }
                guard let workout, !didLoadWorkout else { return }
                didLoadWorkout = true
                name = workout.name; colorHex = workout.colorHex; exercises = workout.exercises
            }
            .onChange(of: units) { _, _ in weightInputs.removeAll() }
            .sheet(isPresented: $showHistory) {
                NavigationStack {
                    List {
                        Section {
                            TextField("Search history", text: $historySearch)
                                .textInputAutocapitalization(.never)
                            Picker("Source", selection: $historyTab) {
                                ForEach(["Workouts", "Exercises", "History"], id: \.self) { Text($0).tag($0) }
                            }.pickerStyle(.segmented)
                        }.listRowBackground(colors.surface)
                        let suggestions = store.historyWorkoutSuggestions()
                        if historyTab == "Workouts" && !suggestions.isEmpty {
                            Section("Quick add a previous workout") {
                                ForEach(suggestions.filter { historySearch.isEmpty || $0.name.localizedStandardContains(historySearch) || $0.exercises.contains { $0.name.localizedStandardContains(historySearch) } }, id: \.id) { suggestion in
                                    Button {
                                        if workout != nil ||
                                            !name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ||
                                            !exercises.isEmpty {
                                            pendingHistoryWorkout = suggestion
                                        } else {
                                            useHistoryWorkout(suggestion)
                                        }
                                    } label: {
                                        HStack(spacing: 12) {
                                            Image(systemName: "clock.arrow.circlepath").foregroundStyle(colors.accent)
                                            VStack(alignment: .leading, spacing: 4) {
                                                Text(suggestion.name).foregroundStyle(colors.text)
                                                Text("\(suggestion.exercises.map(\.name).joined(separator: " · ")) · \(suggestion.lastPerformedAt, style: .date)")
                                                    .font(.caption).foregroundStyle(colors.muted)
                                                    .lineLimit(2)
                                            }
                                            Spacer()
                                            Image(systemName: "plus.circle.fill").foregroundStyle(colors.accent)
                                        }
                                        .frame(minHeight: 48).contentShape(Rectangle())
                                    }.buttonStyle(.plain).listRowBackground(colors.surface)
                                }
                            }
                        }
                        if historyTab == "Exercises" { Section("Individual exercises") {
                            ForEach(store.historyExercises().filter {
                                historySearch.isEmpty || $0.localizedStandardContains(historySearch)
                            }, id: \.self) { exercise in
                                let selected = exercises.contains { olympiaExerciseKey($0.name) == olympiaExerciseKey(exercise) }
                                Button {
                                    if selected {
                                        exercises.removeAll { olympiaExerciseKey($0.name) == olympiaExerciseKey(exercise) }
                                    } else {
                                        let recentCount = store.sessions.first { session in
                                            session.completedSets.contains { olympiaExerciseKey($0.exerciseName) == olympiaExerciseKey(exercise) }
                                        }?.completedSets.filter { olympiaExerciseKey($0.exerciseName) == olympiaExerciseKey(exercise) }.count ?? 3
                                        exercises.append(OlympiaExercise(
                                            name: exercise, sets: max(1, min(12, recentCount)), restSeconds: 90,
                                            targetWeightPounds: store.mostRecentExerciseSet(exercise: exercise, setNumber: 1)?.weightPounds))
                                    }
                                } label: {
                                    HStack {
                                        Text(exercise).foregroundStyle(colors.text)
                                        Spacer()
                                        if let prior = store.mostRecentExerciseSet(exercise: exercise, setNumber: 1) {
                                            Text(prior.weightPounds.map { weight in
                                                "\(prior.displayReps) reps · \(String(format: "%g", units == "kg" ? weight / 2.2046226218 : weight)) \(units)"
                                            } ?? "\(prior.displayReps) reps")
                                                .font(.caption).foregroundStyle(colors.muted)
                                        }
                                        Image(systemName: selected ? "checkmark.circle.fill" : "plus.circle")
                                            .foregroundStyle(selected ? colors.accent : colors.muted)
                                    }
                                    .frame(minHeight: 44).contentShape(Rectangle())
                                }.buttonStyle(.plain)
                                    .accessibilityLabel("\(exercise), \(selected ? "selected" : "not selected")")
                                    .accessibilityAddTraits(selected ? .isSelected : [])
                                    .listRowBackground(colors.surface)
                            }
                        } }
                        if historyTab == "History" {
                            let sessions = store.sessions.filter {
                                !["preparing", "working", "resting", "paused"].contains($0.status) &&
                                (historySearch.isEmpty || $0.name.localizedStandardContains(historySearch) ||
                                 $0.completedSets.contains { $0.exerciseName.localizedStandardContains(historySearch) })
                            }
                            Section("Recent history") {
                                ForEach(Array(sessions.prefix(showAllHistory ? sessions.count : 6))) { session in
                                    Button { selectedHistorySession = session } label: {
                                        HStack(spacing: 10) {
                                            Circle().fill(Color(olympiaHex: store.workouts.first { $0.id == session.workoutID }?.colorHex ?? workoutColors[0]))
                                                .frame(width: 10, height: 10)
                                            VStack(alignment: .leading, spacing: 3) {
                                                Text(session.name).font(.subheadline.bold()).foregroundStyle(colors.text)
                                                Text(session.startedAt.formatted(date: .abbreviated, time: .shortened))
                                                    .font(.caption).foregroundStyle(colors.muted)
                                            }
                                            Spacer()
                                            Text("\(session.completedSets.count) sets").font(.caption.bold()).foregroundStyle(colors.accent)
                                        }.frame(minHeight: 46)
                                    }.buttonStyle(.plain)
                                }
                                if sessions.count > 6 && !showAllHistory {
                                    Button("See all") { showAllHistory = true }
                                }
                            }.listRowBackground(colors.surface)
                        }
                    }
                        .scrollContentBackground(.hidden).scrollIndicators(.hidden)
                        .background(Color.clear).navigationTitle("Add from history")
                        .toolbar {
                            ToolbarItem(placement: .cancellationAction) { Button("Back") { showHistory = false } }
                            ToolbarItem(placement: .confirmationAction) { Button("Done") { showHistory = false } }
                        }
                        .sheet(item: $selectedHistorySession) { OlympiaSessionDetailView(store: store, session: $0) }
                        .confirmationDialog("Add exercises from this workout?",
                                            isPresented: Binding(
                                                get: { pendingHistoryWorkout != nil },
                                                set: { if !$0 { pendingHistoryWorkout = nil } })) {
                            Button("Add exercises") {
                                if let pendingHistoryWorkout { addHistoryExercises(pendingHistoryWorkout) }
                            }
                            Button("Replace with logged workout", role: .destructive) {
                                if let pendingHistoryWorkout { useHistoryWorkout(pendingHistoryWorkout) }
                            }
                            Button("Keep editing", role: .cancel) { pendingHistoryWorkout = nil }
                        } message: {
                            Text("Add its exercises to this workout, or replace the current name and exercise list.")
                        }
                }
            }
            .confirmationDialog("Delete this workout? History will be kept.", isPresented: $showDelete) {
                Button("Delete workout", role: .destructive) {
                    if let workout { store.deleteWorkout(workout) }; dismiss()
                }
            }
            .alert("Can't save workout", isPresented: $showValidation) {
                Button("OK", role: .cancel) { }
            } message: {
                Text(validationMessage)
            }
        }.tint(colors.accent).presentationCornerRadius(28)
            .animation(reduceMotion ? nil : .easeInOut(duration: 0.18), value: colorHex)
    }

    private func useHistoryWorkout(_ suggestion: OlympiaWorkoutSuggestion) {
        name = suggestion.name
        exercises = suggestion.exercises
        weightInputs.removeAll()
        pendingHistoryWorkout = nil
        showHistory = false
    }

    private func addHistoryExercises(_ suggestion: OlympiaWorkoutSuggestion) {
        let existing = Set(exercises.map { olympiaExerciseKey($0.name) })
        exercises += suggestion.exercises.filter { !existing.contains(olympiaExerciseKey($0.name)) }
        pendingHistoryWorkout = nil
        showHistory = false
    }

    private func targetWeightBinding(for exercise: Binding<OlympiaExercise>) -> Binding<String> {
        Binding(
            get: {
                let item = exercise.wrappedValue
                return weightInputs[item.id] ??
                    item.targetWeightPounds.map { String(format: "%g", units == "kg" ? $0 / 2.2046226218 : $0) } ?? ""
            },
            set: { text in
                var updated = exercise.wrappedValue
                weightInputs[updated.id] = text
                let parsed = Double(text.trimmingCharacters(in: .whitespacesAndNewlines))
                updated.targetWeightPounds = parsed.flatMap { value in
                    value.isFinite && (0...2000).contains(value)
                        ? (units == "kg" ? value * 2.2046226218 : value) : nil
                }
                exercise.wrappedValue = updated
            }
        )
    }
}

struct OlympiaProgramEditor: View {
    @ObservedObject var store: OlympiaTrainingStore
    var makeRestSlotID: UUID? = nil
    @Environment(\.dismiss) private var dismiss
    @Environment(\.olympiaColors) private var colors
    @Environment(\.olympiaTheme) private var theme
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var name = "My Program"
    @State private var scheduleMode = "rotation"
    @State private var rotationStartDate = Date()
    @State private var slots: [OlympiaProgramSlot] = []
    @State private var rotationDraft: [OlympiaProgramSlot] = []
    @State private var weeklyDraft: [OlympiaProgramSlot] = []
    @State private var pullWorkoutID: UUID?
    @State private var pushWorkoutID: UUID?
    @State private var legsWorkoutID: UUID?
    @State private var repeatIndefinitely = true
    @State private var repeatCount = 4
    @State private var showValidation = false
    @State private var showRoles = false
    @State private var pendingPreset: Bool?
    @FocusState private var nameFocused: Bool
    @AppStorage("olympia.hapticsEnabled") private var hapticsEnabled = true
    private let days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
    private let calendarWeekdays = [2, 3, 4, 5, 6, 7, 1]
    private var isRotation: Bool { scheduleMode == "rotation" }
    private var savedSlots: [OlympiaProgramSlot] { isRotation ? slots : slots.filter { !$0.isRest } }
    private var canSave: Bool {
        !name.trimmingCharacters(in: .whitespaces).isEmpty &&
        savedSlots.contains { slot in !slot.isRest && store.workouts.contains { $0.id == slot.workoutID } } &&
        (isRotation || savedSlots.contains { !$0.weekdays.isEmpty })
    }
    private var rotationDescription: String {
        slots.enumerated().map { entry in
            let name = entry.element.isRest ? "Rest" :
                (store.workouts.first(where: { $0.id == entry.element.workoutID })?.name ?? "Workout")
            return "\(entry.offset + 1). \(name)"
        }.joined(separator: "  ·  ")
    }

    var body: some View {
        NavigationStack {
            Form {
                Section("Program") {
                    TextField("Program name", text: $name)
                        .font(.title2.bold()).padding(.vertical, 8)
                        .focused($nameFocused)
                }.listRowBackground(colors.surface)
                Section("Schedule") {
                    Picker("Schedule", selection: Binding(get: { scheduleMode }, set: { changeMode($0) })) {
                        Text("Weekly").tag("weekly")
                        Text("Flexible cycle").tag("rotation")
                    }.pickerStyle(.segmented)
                    Text(isRotation ? "Workouts and rest days in any order; the cycle repeats." : "Choose weekdays for each workout.")
                        .font(.caption).foregroundStyle(colors.muted)
                    if isRotation {
                        DatePicker("Cycle starts", selection: $rotationStartDate, displayedComponents: .date)
                        Text("Day 1 of the cycle is scheduled on this date.")
                            .font(.caption).foregroundStyle(.secondary)
                        Toggle("Repeat indefinitely", isOn: $repeatIndefinitely)
                        if !repeatIndefinitely {
                            Stepper("Repeat \(repeatCount) \(repeatCount == 1 ? "cycle" : "cycles")", value: $repeatCount, in: 1...999)
                            Text("The schedule ends after the final cycle.")
                                .font(.caption).foregroundStyle(.secondary)
                        }
                    }
                }.listRowBackground(colors.surface)
                Section(isRotation ? "Cycle · \(slots.count) days · drag to reorder" : "Workouts · choose weekdays") {
                    if !isRotation {
                        ForEach(store.workouts) { workout in
                            VStack(alignment: .leading, spacing: 10) {
                                Toggle(isOn: Binding(
                                    get: { slots.contains { $0.workoutID == workout.id } },
                                    set: { enabled in
                                        if enabled {
                                            slots.append(OlympiaProgramSlot(workoutID: workout.id,
                                                                            weekdays: [], colorHex: workout.colorHex))
                                        } else { slots.removeAll { $0.workoutID == workout.id } }
                                    })) {
                                        Text(workout.name).font(.subheadline.bold())
                                            .foregroundStyle(Color(olympiaHex: workout.colorHex))
                                    }
                                if scheduleMode == "weekly", let index = slots.firstIndex(where: { $0.workoutID == workout.id }) {
                                    HStack(spacing: 5) {
                                        ForEach(0..<7, id: \.self) { dayIndex in
                                            let weekday = calendarWeekdays[dayIndex]
                                            let selected = slots[index].weekdays.contains(weekday)
                                            Button(days[dayIndex]) {
                                                if selected { slots[index].weekdays.removeAll { $0 == weekday } }
                                                else { slots[index].weekdays.append(weekday) }
                                            }.font(.caption2.bold()).frame(maxWidth: .infinity).frame(minHeight: 44)
                                                .background(selected ? Color(olympiaHex: workout.colorHex) : colors.secondarySurface,
                                                            in: Capsule())
                                                .foregroundStyle(selected ? Color.black : colors.muted)
                                                .buttonStyle(OlympiaPressStyle())
                                                .accessibilityAddTraits(selected ? .isSelected : [])
                                        }
                                    }
                                }
                            }.padding(.vertical, 3)
                        }
                    } else {
                        ScrollView(.horizontal) {
                            HStack(spacing: 9) {
                                ForEach(Array(slots.enumerated()), id: \.element.id) { index, slot in
                                    VStack(spacing: 4) {
                                        Text(slot.isRest ? "☾ Rest" : (store.workouts.first { $0.id == slot.workoutID }?.name ?? "Workout"))
                                            .font(.caption2.bold()).lineLimit(1).frame(width: 72)
                                            .padding(.horizontal, 5).padding(.vertical, 8)
                                            .glassSurface(radius: 14, tint: slot.isRest ? nil : Color(olympiaHex: slot.colorHex))
                                        Text(Calendar.current.date(byAdding: .day, value: index, to: rotationStartDate)?
                                            .formatted(.dateTime.month(.abbreviated).day()) ?? "")
                                            .font(.caption2).foregroundStyle(colors.muted)
                                    }
                                }
                            }
                        }.scrollIndicators(.hidden)
                        ForEach(slots) { slot in
                            HStack(spacing: 12) {
                                Image(systemName: "line.3.horizontal").foregroundStyle(colors.muted)
                                if slot.isRest {
                                    Label("Rest day", systemImage: "moon.zzz.fill")
                                        .foregroundStyle(colors.muted)
                                } else {
                                    Menu {
                                        ForEach(store.workouts) { workout in
                                            Button(workout.name) { changeWorkout(slot.id, to: workout) }
                                        }
                                    } label: {
                                        HStack {
                                            Circle().fill(Color(olympiaHex: slot.colorHex)).frame(width: 8, height: 8)
                                            Text(store.workouts.first(where: { $0.id == slot.workoutID })?.name ?? "Choose workout")
                                                .foregroundStyle(colors.text)
                                            Image(systemName: "chevron.up.chevron.down").font(.caption2)
                                        }
                                    }
                                }
                                Spacer()
                                Button { slots.removeAll { $0.id == slot.id } } label: {
                                    Image(systemName: "xmark").font(.caption.bold()).frame(width: 44, height: 44)
                                }.buttonStyle(.plain).accessibilityLabel("Remove cycle day")
                            }
                            .frame(minHeight: 44)
                        }
                        .onMove { slots.move(fromOffsets: $0, toOffset: $1) }
                        .onDelete { slots.remove(atOffsets: $0) }
                        HStack {
                            Menu {
                                ForEach(store.workouts) { workout in
                                    Button(workout.name) {
                                        slots.append(OlympiaProgramSlot(workoutID: workout.id,
                                            weekdays: [], colorHex: workout.colorHex))
                                    }
                                }
                            } label: { Label("Workout", systemImage: "plus") }
                            Spacer()
                            Button { slots.append(.rest()) } label: { Label("Rest day", systemImage: "moon") }
                        }.font(.subheadline.bold()).frame(minHeight: 44)
                        if !slots.isEmpty {
                            Text("Cycle: \(rotationDescription)")
                                .font(.caption).foregroundStyle(colors.muted)
                        }
                    }
                }.listRowBackground(colors.surface)
                if isRotation && !store.workouts.isEmpty {
                    Section("Quick start") {
                        Button("Pull · Push · Legs · Rest · Rest") { requestPreset(restAfterSecond: false) }
                            .disabled(!hasPresetWorkouts)
                        Button("Pull · Push · Rest · Legs · Rest") { requestPreset(restAfterSecond: true) }
                            .disabled(!hasPresetWorkouts)
                        Button { showRoles = true } label: {
                            HStack {
                                Text("Roles").font(.subheadline.bold())
                                Spacer()
                                Text("Pull: \(roleName(pullWorkoutID)) · Push: \(roleName(pushWorkoutID)) · Legs: \(roleName(legsWorkoutID))")
                                    .font(.caption).lineLimit(1).foregroundStyle(colors.muted)
                                Image(systemName: "chevron.right")
                            }
                        }
                        Text("Pick a preset, then fine-tune the cycle above.")
                            .font(.caption).foregroundStyle(colors.muted)
                    }.listRowBackground(colors.surface)
                }
            }.scrollContentBackground(.hidden).scrollIndicators(.hidden)
                .scrollDismissesKeyboard(.interactively).background(Color.clear)
                .foregroundStyle(colors.text)
                .safeAreaInset(edge: .bottom, spacing: 0) {
                    Button {
                        nameFocused = false
                        guard canSave else { showValidation = true; return }
                        guard store.upsertProgram(id: store.activeProgram?.id, name: name,
                                            scheduleType: scheduleMode == "weekly" ? "weekly" : "rotation",
                                            rotationRestDays: 0,
                                            rotationStartDate: rotationStartDate, slots: savedSlots,
                                            repeatCount: isRotation && !repeatIndefinitely ? repeatCount : nil) else { return }
                        OlympiaHaptics.acceptedAction(enabled: hapticsEnabled)
                        dismiss()
                    } label: {
                        Text("Save schedule")
                            .font(.headline.bold()).foregroundStyle(theme.buttonText)
                            .frame(maxWidth: .infinity).frame(minHeight: 52)
                            .background(theme.buttonFill.opacity(canSave ? 1 : 0.25), in: Capsule())
                            .contentShape(Capsule())
                    }
                        .buttonStyle(.borderless)
                        .disabled(!canSave)
                        .padding(.horizontal, 20).padding(.vertical, 12)
                }
                .navigationTitle("Schedule").navigationBarTitleDisplayMode(.inline)
                .toolbar {
                    ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } }
                    ToolbarItem(placement: .confirmationAction) { EditButton() }
                    ToolbarItemGroup(placement: .keyboard) {
                        Spacer()
                        Button("Done") { nameFocused = false }
                    }
                }
                .onAppear {
                    if let program = store.activeProgram {
                        name = program.name
                        slots = program.slots
                        if program.scheduleType == "rotation" && program.rotationRestDays > 0 {
                            slots += (0..<program.rotationRestDays).map { _ in .rest() }
                        }
                        rotationStartDate = program.rotationAnchor
                        scheduleMode = program.scheduleType == "weekly" ? "weekly" : "rotation"
                        repeatIndefinitely = program.repeatCount == nil
                        repeatCount = program.repeatCount ?? 4
                        let ids = program.slots.filter { !$0.isRest }.prefix(3).map(\.workoutID)
                        if ids.count == 3 {
                            pullWorkoutID = ids[0]; pushWorkoutID = ids[1]; legsWorkoutID = ids[2]
                        }
                    } else {
                        let ids = Array(store.workouts.prefix(3).map(\.id))
                        if ids.count == 3 {
                            pullWorkoutID = ids[0]; pushWorkoutID = ids[1]; legsWorkoutID = ids[2]
                        }
                    }
                    if let makeRestSlotID, let index = slots.firstIndex(where: { $0.id == makeRestSlotID }) {
                        slots[index].isRest = true
                        slots[index].colorHex = "#000000"
                    }
                    rotationDraft = slots
                    weeklyDraft = slots.filter { !$0.isRest }
                }
                .sheet(isPresented: $showRoles) {
                    NavigationStack {
                        Form {
                            workoutPicker("Pull", selection: $pullWorkoutID)
                            workoutPicker("Push", selection: $pushWorkoutID)
                            workoutPicker("Legs", selection: $legsWorkoutID)
                        }.navigationTitle("Roles")
                            .toolbar { Button("Done") { showRoles = false } }
                    }.presentationDetents([.medium])
                }
                .confirmationDialog("Replace the current cycle?", isPresented: Binding(
                    get: { pendingPreset != nil }, set: { if !$0 { pendingPreset = nil } })) {
                    Button("Replace cycle") {
                        if let pendingPreset { applyPreset(restAfterSecond: pendingPreset) }
                        pendingPreset = nil
                    }
                    Button("Keep cycle", role: .cancel) { pendingPreset = nil }
                }
                .alert("Schedule isn't ready", isPresented: $showValidation) {
                    Button("OK", role: .cancel) { }
                } message: {
                    Text(name.trimmingCharacters(in: .whitespaces).isEmpty
                         ? "Enter a program name."
                         : !savedSlots.contains(where: { !$0.isRest })
                            ? "Add at least one workout to the schedule."
                            : "Choose at least one weekday for a workout, or switch to a flexible cycle.")
                }
        }.tint(colors.accent).presentationCornerRadius(28)
            .animation(reduceMotion ? nil : .easeInOut(duration: 0.18), value: scheduleMode)
    }

    private func scheduleChoice(_ mode: String, title: String, detail: String, preview: String?) -> some View {
        Button {
            changeMode(mode)
        } label: {
            HStack(alignment: .top, spacing: 12) {
                Image(systemName: scheduleMode == mode ? "largecircle.fill.circle" : "circle")
                    .foregroundStyle(colors.accent).padding(.top, 2)
                VStack(alignment: .leading, spacing: 4) {
                    Text(title).font(.subheadline.bold()).foregroundStyle(colors.text)
                    Text(detail).font(.caption).foregroundStyle(colors.muted)
                    if let preview { Text(preview).font(.caption2).foregroundStyle(colors.accent) }
                }
                Spacer(minLength: 0)
            }.frame(maxWidth: .infinity, alignment: .leading).contentShape(Rectangle())
        }.buttonStyle(.plain).accessibilityAddTraits(scheduleMode == mode ? .isSelected : [])
    }

    private func changeMode(_ mode: String) {
        guard mode != scheduleMode else { return }
        if isRotation { rotationDraft = slots } else { weeklyDraft = slots }
        scheduleMode = mode
        if mode == "rotation" { slots = rotationDraft }
        else {
            var seen = Set<UUID>()
            slots = weeklyDraft.isEmpty
                ? rotationDraft.filter { !$0.isRest && seen.insert($0.workoutID).inserted }
                : weeklyDraft
        }
    }

    private func roleName(_ id: UUID?) -> String {
        store.workouts.first { $0.id == id }?.name ?? "Choose"
    }

    private func requestPreset(restAfterSecond: Bool) {
        if slots.isEmpty { applyPreset(restAfterSecond: restAfterSecond) }
        else { pendingPreset = restAfterSecond }
    }

    private func changeWorkout(_ slotID: UUID, to workout: OlympiaWorkoutTemplate) {
        guard let index = slots.firstIndex(where: { $0.id == slotID }) else { return }
        slots[index].workoutID = workout.id
        slots[index].colorHex = workout.colorHex
    }

    private var hasPresetWorkouts: Bool {
        [pullWorkoutID, pushWorkoutID, legsWorkoutID].allSatisfy { id in
            id.map { selected in store.workouts.contains { $0.id == selected } } ?? false
        }
    }

    private func workoutPicker(_ role: String, selection: Binding<UUID?>) -> some View {
        Picker("\(role) workout", selection: selection) {
            Text("Choose workout").tag(UUID?.none)
            ForEach(store.workouts) { workout in
                Text(workout.name).tag(Optional(workout.id))
            }
        }
    }

    private func applyPreset(restAfterSecond: Bool) {
        let workouts = [pullWorkoutID, pushWorkoutID, legsWorkoutID]
            .compactMap { id in store.workouts.first { $0.id == id } }
        guard workouts.count == 3 else { return }
        let workoutSlots = workouts.map {
            OlympiaProgramSlot(workoutID: $0.id, weekdays: [], colorHex: $0.colorHex)
        }
        slots = restAfterSecond
            ? [workoutSlots[0], workoutSlots[1], .rest(), workoutSlots[2], .rest()]
            : workoutSlots + [.rest(), .rest()]
    }
}
