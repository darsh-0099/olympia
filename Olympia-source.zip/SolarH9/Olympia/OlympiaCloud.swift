import Combine
import CryptoKit
import Foundation
import Security

/// Supabase REST client. Only the publishable/anon key belongs on device.
/// The user owns a single versioned JSON training snapshot behind RLS.
@MainActor final class OlympiaCloud: ObservableObject {
    static let shared = OlympiaCloud()
    @Published private(set) var signedInEmail: String?
    @Published private(set) var isBusy = false
    @Published var message: String?
    @Published var projectURL: String { didSet { UserDefaults.standard.set(projectURL, forKey: "olympia.supabase.url") } }
    @Published var publishableKey: String { didSet { UserDefaults.standard.set(publishableKey, forKey: "olympia.supabase.key") } }

    private var accessToken: String? { get { keychain("access") } set { setKeychain("access", newValue) } }
    private var refreshToken: String? { get { keychain("refresh") } set { setKeychain("refresh", newValue) } }
    private var userID: String? { get { keychain("user-id") } set { setKeychain("user-id", newValue) } }
    private var rootURL: URL? {
        guard let url = URL(string: projectURL), url.scheme == "https", url.host?.hasSuffix(".supabase.co") == true else { return nil }
        return url
    }

    private init() {
        projectURL = UserDefaults.standard.string(forKey: "olympia.supabase.url") ?? ""
        publishableKey = UserDefaults.standard.string(forKey: "olympia.supabase.key") ?? ""
        signedInEmail = UserDefaults.standard.string(forKey: "olympia.supabase.email")
    }

    var configured: Bool { rootURL != nil && !publishableKey.isEmpty }
    var signedIn: Bool { userID != nil && refreshToken != nil }

    func signUp(email: String, password: String) async {
        await authenticate(path: "auth/v1/signup", email: email, password: password)
    }

    func signIn(email: String, password: String) async {
        await authenticate(path: "auth/v1/token?grant_type=password", email: email, password: password)
    }

    private func authenticate(path: String, email: String, password: String) async {
        isBusy = true; defer { isBusy = false }
        do {
            let response = try await request(path: path, method: "POST",
                                             body: ["email": email, "password": password], authenticated: false)
            saveSession(response, email: email)
            message = signedIn ? "Signed in. Use Sync now to upload your training data." : "Check your email to confirm your account, then sign in."
        } catch { message = error.localizedDescription }
    }

    func signOut() {
        accessToken = nil; refreshToken = nil; userID = nil; signedInEmail = nil
        UserDefaults.standard.removeObject(forKey: "olympia.supabase.email")
        message = "Signed out. Your local training data remains on this iPhone."
    }

    func sync(store: OlympiaTrainingStore) async {
        guard !isBusy else { return }
        isBusy = true; defer { isBusy = false }
        do {
            try await renewSession()
            guard let userID else { throw CloudError("Sign in first.") }
            if let error = store.errorMessage {
                throw CloudError("Local training data has an unresolved error. No upload was made. \(error)")
            }
            store.refresh()
            if let error = store.errorMessage {
                throw CloudError("Local training data could not be read. No upload was made. \(error)")
            }
            guard !store.sessions.contains(where: { ["preparing", "working", "resting", "paused"].contains($0.status) }) else {
                throw CloudError("Finish or discard the current workout before syncing.")
            }
            let query = "rest/v1/training_data?select=payload,revision&user_id=eq.\(userID)"
            let response = try await request(path: query, method: "GET", authenticated: true)
            guard let rows = response as? [[String: Any]], rows.count <= 1 else {
                throw CloudError("Invalid cloud snapshot response.")
            }
            let remoteRevision = rows.first.flatMap { $0["revision"] as? Int }
            if rows.first != nil && (remoteRevision ?? 0) <= 0 {
                throw CloudError("Cloud snapshot has no valid revision.")
            }
            let remote: OlympiaBackup?
            if let row = rows.first {
                guard let payload = row["payload"] else { throw CloudError("Cloud snapshot has no payload.") }
                let data = try JSONSerialization.data(withJSONObject: payload)
                let decoded = try snapshotDecoder.decode(OlympiaBackup.self, from: data)
                _ = try decoded.merged(base: decoded, remote: decoded)
                remote = decoded
            } else {
                remote = nil
            }
            let stateURL = try syncStateURL(userID: userID)
            let baseline = try loadSyncState(at: stateURL)
            let local = OlympiaBackup(store: store)
            _ = try local.merged(base: local, remote: local)
            if remote == nil && (baseline != nil || keychain("uploaded-revision-\(userID)") != nil) {
                throw CloudError("The previous cloud snapshot is missing. No upload was made; review your cloud data before syncing again.")
            }
            if let baseline, let remoteRevision, baseline.revision > remoteRevision {
                throw CloudError("The cloud revision went backwards. No upload was made; review your cloud data.")
            }

            let merged: OlympiaBackup
            if let remote, let remoteRevision {
                if let baseline {
                    do {
                        merged = try local.merged(base: baseline.backup, remote: remote)
                    } catch {
                        throw CloudError("This device and the cloud changed the same workout, program, or weight differently. No upload was made. Export your local data before resolving the conflict. \(error.localizedDescription)")
                    }
                } else if !hasRecords(local) {
                    // A fresh install must download, never infer deletions from an
                    // old Keychain revision that survived the app's data store.
                    merged = remote
                } else if try snapshotsEqual(local, remote) {
                    merged = remote
                } else if keychain("uploaded-revision-\(userID)") == String(remoteRevision),
                          containsAllRemoteIDs(local: local, remote: remote) {
                    merged = try local.merged(base: remote, remote: remote)
                } else {
                    throw CloudError("This device has local data but no trusted sync history. No upload was made. Export your data before reconciling it with the cloud.")
                }
            } else {
                merged = local
            }

            if let remote, let remoteRevision, try snapshotsEqual(merged, remote) {
                try store.applyBackup(merged)
                try saveSyncState(SyncState(revision: remoteRevision, backup: remote), at: stateURL)
                setKeychain("uploaded-revision-\(userID)", String(remoteRevision))
                message = "Cloud sync complete. This device is up to date."
                return
            }

            let object = try JSONSerialization.jsonObject(with: snapshotEncoder.encode(merged))
            let revision = (remoteRevision ?? 0) + 1
            let uploaded: Any
            if let remoteRevision {
                // A revision filter makes the write conditional on the snapshot
                // still being the one we just read. Zero returned rows means a
                // concurrent device changed or removed it; never upsert over it.
                uploaded = try await request(path: "rest/v1/training_data?user_id=eq.\(userID)&revision=eq.\(remoteRevision)&select=revision",
                                             method: "PATCH", body: ["payload": object, "revision": revision],
                                             authenticated: true, extraHeaders: ["Prefer": "return=representation"])
            } else {
                uploaded = try await request(path: "rest/v1/training_data?on_conflict=user_id&select=revision",
                                             method: "POST", body: ["user_id": userID, "payload": object, "revision": revision],
                                             authenticated: true,
                                             extraHeaders: ["Prefer": "resolution=ignore-duplicates,return=representation"])
            }
            guard let uploadedRows = uploaded as? [[String: Any]], uploadedRows.count == 1,
                  uploadedRows[0]["revision"] as? Int == revision else {
                throw CloudError("Cloud data changed during sync. No overwrite was made; sync again after reviewing the data.")
            }
            // The MainActor may run local edits while the request is in flight.
            // Rebase those edits onto what was actually uploaded before applying.
            let currentLocal = OlympiaBackup(store: store)
            let applied: OlympiaBackup
            do {
                applied = try currentLocal.merged(base: local, remote: merged)
            } catch {
                throw CloudError("Upload succeeded, but this device changed during sync and needs review. Your cloud data was not overwritten again. \(error.localizedDescription)")
            }
            do {
                try store.applyBackup(applied)
                try saveSyncState(SyncState(revision: revision, backup: merged), at: stateURL)
            } catch {
                throw CloudError("Upload succeeded, but this device could not finish applying it. Sync again after checking local storage. \(error.localizedDescription)")
            }
            setKeychain("uploaded-revision-\(userID)", String(revision))
            message = "Cloud sync complete. Your workouts and body weight are backed up."
        } catch { message = "Sync failed: \(error.localizedDescription)" }
    }

    private struct SyncState: Codable {
        let revision: Int
        let backup: OlympiaBackup
    }

    private var snapshotEncoder: JSONEncoder {
        let encoder = JSONEncoder()
        encoder.dateEncodingStrategy = .iso8601
        encoder.outputFormatting = [.sortedKeys]
        return encoder
    }

    private var snapshotDecoder: JSONDecoder {
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        return decoder
    }

    private func snapshotsEqual(_ lhs: OlympiaBackup, _ rhs: OlympiaBackup) throws -> Bool {
        func normalized(_ value: OlympiaBackup) -> OlympiaBackup {
            OlympiaBackup(workouts: value.workouts.sorted { $0.id.uuidString < $1.id.uuidString },
                          sessions: value.sessions.sorted { $0.id.uuidString < $1.id.uuidString },
                          programs: value.programs.sorted { $0.id.uuidString < $1.id.uuidString },
                          weights: value.weights.sorted { $0.id.uuidString < $1.id.uuidString })
        }
        return try snapshotEncoder.encode(normalized(lhs)) == snapshotEncoder.encode(normalized(rhs))
    }

    private func hasRecords(_ backup: OlympiaBackup) -> Bool {
        !backup.workouts.isEmpty || !backup.sessions.isEmpty || !backup.programs.isEmpty || !backup.weights.isEmpty
    }

    private func containsAllRemoteIDs(local: OlympiaBackup, remote: OlympiaBackup) -> Bool {
        Set(remote.workouts.map(\.id)).isSubset(of: Set(local.workouts.map(\.id))) &&
        Set(remote.sessions.map(\.id)).isSubset(of: Set(local.sessions.map(\.id))) &&
        Set(remote.programs.map(\.id)).isSubset(of: Set(local.programs.map(\.id))) &&
        Set(remote.weights.map(\.id)).isSubset(of: Set(local.weights.map(\.id)))
    }

    private func syncStateURL(userID: String) throws -> URL {
        guard let rootURL else { throw CloudError("Enter a valid Supabase project URL.") }
        let identity = "\(rootURL.absoluteString)|\(userID)"
        let hash = SHA256.hash(data: Data(identity.utf8)).map { String(format: "%02x", $0) }.joined()
        let directory = try FileManager.default.url(for: .applicationSupportDirectory,
                                                     in: .userDomainMask, appropriateFor: nil, create: true)
            .appendingPathComponent("OlympiaSync", isDirectory: true)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        return directory.appendingPathComponent("\(hash).json")
    }

    private func loadSyncState(at url: URL) throws -> SyncState? {
        guard FileManager.default.fileExists(atPath: url.path) else { return nil }
        do { return try snapshotDecoder.decode(SyncState.self, from: Data(contentsOf: url)) }
        catch { throw CloudError("The local sync history could not be read. No upload was made. \(error.localizedDescription)") }
    }

    private func saveSyncState(_ state: SyncState, at url: URL) throws {
        let data = try snapshotEncoder.encode(state)
        try data.write(to: url, options: [.atomic, .completeFileProtectionUnlessOpen])
    }

    private func renewSession() async throws {
        guard let refreshToken else { throw CloudError("Sign in first.") }
        let response = try await request(path: "auth/v1/token?grant_type=refresh_token", method: "POST",
                                         body: ["refresh_token": refreshToken], authenticated: false)
        saveSession(response, email: signedInEmail)
    }

    private func saveSession(_ response: Any, email: String?) {
        guard let value = response as? [String: Any],
              let token = value["access_token"] as? String,
              let refresh = value["refresh_token"] as? String,
              let user = value["user"] as? [String: Any],
              let id = user["id"] as? String else { return }
        accessToken = token; refreshToken = refresh; userID = id
        signedInEmail = email ?? user["email"] as? String
        UserDefaults.standard.set(signedInEmail, forKey: "olympia.supabase.email")
    }

    private func request(path: String, method: String, body: [String: Any]? = nil,
                         authenticated: Bool, extraHeaders: [String: String] = [:]) async throws -> Any {
        guard let rootURL, !publishableKey.isEmpty else { throw CloudError("Enter your Supabase project URL and publishable key.") }
        guard let url = URL(string: path, relativeTo: rootURL) else { throw CloudError("Invalid request URL.") }
        var request = URLRequest(url: url)
        request.httpMethod = method
        request.setValue(publishableKey, forHTTPHeaderField: "apikey")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        if authenticated, let accessToken { request.setValue("Bearer \(accessToken)", forHTTPHeaderField: "Authorization") }
        extraHeaders.forEach { request.setValue($0.value, forHTTPHeaderField: $0.key) }
        if let body { request.httpBody = try JSONSerialization.data(withJSONObject: body) }
        let (data, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse else { throw CloudError("No server response.") }
        guard (200..<300).contains(http.statusCode) else {
            let server = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any]
            throw CloudError((server?["msg"] ?? server?["message"] ?? server?["error_description"] ?? "HTTP \(http.statusCode)") as? String ?? "HTTP \(http.statusCode)")
        }
        return data.isEmpty ? [:] : try JSONSerialization.jsonObject(with: data)
    }

    private func keychain(_ key: String) -> String? {
        let query: [String: Any] = [kSecClass as String: kSecClassGenericPassword,
                                    kSecAttrService as String: "OlympiaSupabase",
                                    kSecAttrAccount as String: key,
                                    kSecReturnData as String: true,
                                    kSecMatchLimit as String: kSecMatchLimitOne]
        var result: CFTypeRef?
        guard SecItemCopyMatching(query as CFDictionary, &result) == errSecSuccess,
              let data = result as? Data else { return nil }
        return String(data: data, encoding: .utf8)
    }

    private func setKeychain(_ key: String, _ value: String?) {
        let query: [String: Any] = [kSecClass as String: kSecClassGenericPassword,
                                    kSecAttrService as String: "OlympiaSupabase", kSecAttrAccount as String: key]
        SecItemDelete(query as CFDictionary)
        guard let value, let data = value.data(using: .utf8) else { return }
        var insert = query; insert[kSecValueData as String] = data
        SecItemAdd(insert as CFDictionary, nil)
    }

    private struct CloudError: LocalizedError {
        let message: String
        init(_ message: String) { self.message = message }
        var errorDescription: String? { message }
    }
}
