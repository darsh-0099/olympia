import Charts
import SwiftUI

struct OlympiaMonthCalendar: View {
    @ObservedObject var store: OlympiaTrainingStore
    @Binding var month: Date
    @Binding var selectedDate: Date
    @Binding var selectedSession: OlympiaTrainingSession?
    let onSubstitute: (Date) -> Void
    @Environment(\.olympiaColors) private var colors
    @State private var dayData: [Date: CalendarDay] = [:]

    private struct CalendarDay {
        var planned: [OlympiaWorkoutTemplate]
        var completed: [OlympiaTrainingSession]
        var skipped: Bool
    }

    private var first: Date { Calendar.current.date(from: Calendar.current.dateComponents([.year, .month], from: month)) ?? month }
    private var dayCount: Int { Calendar.current.range(of: .day, in: .month, for: month)?.count ?? 30 }
    private var offset: Int { Calendar.current.component(.weekday, from: first) - 1 }
    private var sessionsForDate: [OlympiaTrainingSession] {
        store.sessions.filter {
            ["completed", "partial", "imported"].contains($0.status) &&
            Calendar.current.isDate($0.endedAt ?? $0.startedAt, inSameDayAs: selectedDate)
        }
    }

    private func rebuildMonth() {
        let calendar = Calendar.current
        let dates = (0..<dayCount).compactMap { calendar.date(byAdding: .day, value: $0, to: first) }
        let dayKeys = Set(dates.map { calendar.startOfDay(for: $0) })
        var sessionsByDay: [Date: [OlympiaTrainingSession]] = [:]
        for session in store.sessions where ["completed", "partial", "imported"].contains(session.status) {
            let key = calendar.startOfDay(for: session.endedAt ?? session.startedAt)
            if dayKeys.contains(key) { sessionsByDay[key, default: []].append(session) }
        }
        var next: [Date: CalendarDay] = [:]
        for date in dates {
            let key = calendar.startOfDay(for: date)
            let all = sessionsByDay[key] ?? []
            let unique = all.filter { session in
                all.first { other in
                    if let id = session.workoutID { return other.workoutID == id }
                    return other.workoutID == nil && other.name.localizedCaseInsensitiveCompare(session.name) == .orderedSame
                }?.id == session.id
            }
            next[key] = CalendarDay(planned: store.scheduledWorkouts(on: date), completed: unique,
                                    skipped: store.isSkipped(on: date))
        }
        dayData = next
    }

    private func isCompleted(_ workout: OlympiaWorkoutTemplate, in sessions: [OlympiaTrainingSession]) -> Bool {
        sessions.contains { session in
            session.workoutID == workout.id ||
            (session.workoutID == nil && session.name.localizedCaseInsensitiveCompare(workout.name) == .orderedSame)
        }
    }

    var body: some View {
        OlympiaCard {
            VStack(spacing: 14) {
                HStack {
                    Button { changeMonth(-1) } label: { Image(systemName: "chevron.left").frame(width: 44, height: 44) }
                        .accessibilityLabel("Previous month")
                    Spacer()
                    Text(month.formatted(.dateTime.month(.wide).year())).font(.subheadline.bold()).foregroundStyle(colors.text)
                    Spacer()
                    Button { changeMonth(1) } label: { Image(systemName: "chevron.right").frame(width: 44, height: 44) }
                        .accessibilityLabel("Next month")
                }
                HStack {
                    ForEach(["S", "M", "T", "W", "T", "F", "S"].indices, id: \.self) { index in
                        Text(["S", "M", "T", "W", "T", "F", "S"][index]).frame(maxWidth: .infinity)
                            .font(.caption2).foregroundStyle(colors.muted)
                    }
                }
                LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 5), count: 7), spacing: 5) {
                    ForEach(0..<(offset + dayCount), id: \.self) { index in
                        if index < offset { Color.clear.frame(height: 45) }
                        else {
                            let date = Calendar.current.date(byAdding: .day, value: index - offset, to: first) ?? first
                            let snapshot = dayData[Calendar.current.startOfDay(for: date)]
                            let planned = snapshot?.planned ?? []
                            let completed = snapshot?.completed ?? []
                            let skipped = snapshot?.skipped ?? false
                            let remaining = skipped ? [] : planned.filter { !isCompleted($0, in: completed) }
                            Button {
                                selectedDate = date
                            } label: {
                                VStack(spacing: 4) {
                                    Text("\(index - offset + 1)").font(.caption.bold()).foregroundStyle(colors.text)
                                    HStack(spacing: 2) {
                                        ForEach(remaining.prefix(3)) { workout in
                                            Circle().fill(Color(olympiaHex: workout.colorHex)).frame(width: 4, height: 4)
                                        }
                                        ForEach(completed.prefix(3)) { session in
                                            let workoutColor = store.workouts.first { $0.id == session.workoutID }?.colorHex
                                            Circle().fill(workoutColor.map { Color(olympiaHex: $0) } ?? colors.accent)
                                                .frame(width: 4, height: 4)
                                        }
                                        if skipped {
                                            Circle().fill(colors.muted).frame(width: 4, height: 4)
                                        }
                                    }.frame(height: 4)
                                }.frame(maxWidth: .infinity).frame(height: 44)
                                    .background(Calendar.current.isDate(date, inSameDayAs: selectedDate) ? colors.secondarySurface : .clear,
                                                in: Capsule())
                            }.buttonStyle(OlympiaPressStyle())
                                .accessibilityLabel(date.formatted(date: .complete, time: .omitted))
                                .accessibilityValue(skipped ? "Workout skipped" : !completed.isEmpty ? "Workout completed" : planned.isEmpty ? "Rest day" : "Workout planned")
                                .accessibilityAddTraits(Calendar.current.isDate(date, inSameDayAs: selectedDate) ? .isSelected : [])
                        }
                    }
                }
                VStack(alignment: .leading, spacing: 7) {
                    Text(selectedDate.formatted(date: .complete, time: .omitted)).font(.caption.bold()).foregroundStyle(colors.text)
                    ForEach(sessionsForDate) { session in
                        Button { selectedSession = session } label: {
                            HStack {
                                Text(session.name)
                                Spacer()
                                Text("\(session.completedSets.count) sets")
                                Image(systemName: "chevron.right")
                            }.font(.caption).foregroundStyle(colors.accent)
                        }
                    }
                    if dayData[Calendar.current.startOfDay(for: selectedDate)]?.skipped == true {
                        Label("Workout skipped", systemImage: "forward.end")
                            .font(.caption).foregroundStyle(colors.muted)
                    } else {
                        ForEach((dayData[Calendar.current.startOfDay(for: selectedDate)]?.planned ?? [])
                            .filter { !isCompleted($0, in: sessionsForDate) }) { workout in
                            Label("Planned: \(workout.name)", systemImage: "calendar")
                                .font(.caption).foregroundStyle(colors.muted)
                        }
                    }
                    if sessionsForDate.isEmpty && (dayData[Calendar.current.startOfDay(for: selectedDate)]?.planned.isEmpty ?? true) {
                        Text("Rest day · no workout logged").font(.caption).foregroundStyle(colors.muted)
                    }
                    if store.activeProgram != nil && !store.workouts.isEmpty &&
                        Calendar.current.startOfDay(for: selectedDate) >= Calendar.current.startOfDay(for: .now) &&
                        sessionsForDate.isEmpty {
                        Button { onSubstitute(selectedDate) } label: {
                            Label("Substitute workout", systemImage: "arrow.triangle.2.circlepath")
                                .font(.caption.bold()).foregroundStyle(colors.accent)
                                .frame(minHeight: 44)
                        }
                    }
                }.frame(maxWidth: .infinity, alignment: .leading)
            }
        }
        .buttonStyle(OlympiaPressStyle())
        .tint(colors.muted)
        .gesture(DragGesture(minimumDistance: 35).onEnded { value in
            if value.translation.width < -45 { changeMonth(1) }
            if value.translation.width > 45 { changeMonth(-1) }
        })
        .onAppear(perform: rebuildMonth)
        .onChange(of: month) { _, _ in rebuildMonth() }
        .onChange(of: store.dataRevision) { _, _ in rebuildMonth() }
    }

    private func changeMonth(_ delta: Int) {
        if let date = Calendar.current.date(byAdding: .month, value: delta, to: first) {
            month = date
            selectedDate = date
        }
    }
}

struct OlympiaHistoryView: View {
    @ObservedObject var store: OlympiaTrainingStore
    @Environment(\.dismiss) private var dismiss
    @Environment(\.olympiaColors) private var colors
    @Environment(\.olympiaTheme) private var theme
    @State private var selected: OlympiaTrainingSession?
    @State private var search = ""

    private var visibleSessions: [OlympiaTrainingSession] {
        store.sessions.filter {
            !["preparing", "working", "resting", "paused"].contains($0.status) &&
            (search.isEmpty || $0.name.localizedStandardContains(search) ||
             $0.completedSets.contains { $0.exerciseName.localizedStandardContains(search) })
        }
    }

    var body: some View {
        NavigationStack {
            List {
                Section {
                    TextField("Search workouts or exercises", text: $search)
                        .textInputAutocapitalization(.never)
                }.listRowBackground(colors.surface)
                ForEach(visibleSessions) { session in
                    Button { selected = session } label: {
                        HStack(spacing: 12) {
                            Circle().fill(Color(olympiaHex: store.workouts.first { $0.id == session.workoutID }?.colorHex ?? "#63C7FF"))
                                .frame(width: 10, height: 10)
                            VStack(alignment: .leading, spacing: 4) {
                                Text(session.name).font(.subheadline.bold()).foregroundStyle(colors.text)
                                Text(session.startedAt.formatted(date: .abbreviated, time: .shortened))
                                    .font(.caption).foregroundStyle(colors.muted)
                            }
                            Spacer()
                            Text("\(session.completedSets.count) sets").font(.caption.bold())
                                .foregroundStyle(theme.accent).padding(.horizontal, 10).padding(.vertical, 7)
                                .glassSurface(radius: 16)
                        }
                    }.buttonStyle(.plain)
                }.onDelete { indices in
                    indices.forEach { store.deleteSession(visibleSessions[$0]) }
                }
                .listRowBackground(colors.surface)
                .listRowSeparatorTint(colors.border)
            }.navigationTitle("Workout history")
                .navigationBarTitleDisplayMode(.inline)
                .listStyle(.insetGrouped)
                .scrollContentBackground(.hidden)
                .scrollIndicators(.hidden)
                .background(Color.clear)
                .overlay {
                    if store.sessions.filter({ !["preparing", "working", "resting", "paused"].contains($0.status) }).isEmpty {
                        ContentUnavailableView("No workouts yet", systemImage: "calendar",
                                               description: Text("Completed workouts will appear here."))
                            .foregroundStyle(colors.muted)
                    }
                }
                .toolbar { Button("Done") { dismiss() } }
                .sheet(item: $selected) { OlympiaSessionDetailView(store: store, session: $0) }
        }
        .tint(colors.accent)
        .presentationCornerRadius(24)
        .preferredColorScheme(.dark)
    }
}

struct OlympiaSessionDetailView: View {
    @ObservedObject var store: OlympiaTrainingStore
    @EnvironmentObject private var productStore: ProductStore
    let session: OlympiaTrainingSession
    @Environment(\.dismiss) private var dismiss
    @Environment(\.olympiaColors) private var colors
    @AppStorage("olympia.units") private var units = "lb"
    @State private var confirmDelete = false

    private var names: [String] {
        var seen = Set<String>()
        return session.completedSets.map(\.exerciseName).filter { seen.insert($0).inserted }
    }
    private var heartOverview: SessionOverview? {
        guard let id = session.heartRateSessionID,
              let measurement = productStore.allSessions.first(where: { $0.id == id }) else { return nil }
        return ProductStore.makeOverview(measurement)
    }

    var body: some View {
        NavigationStack {
            List {
                Section {
                    LabeledContent("Date", value: session.startedAt.formatted(date: .complete, time: .omitted))
                    LabeledContent("Duration", value: "\(Int(session.duration / 60)) min")
                    LabeledContent("Total sets", value: "\(session.completedSets.count)")
                    if let average = session.averageHeartRate ?? heartOverview?.averageHeartRate.value {
                        LabeledContent("Average heart rate", value: "\(Int(average.rounded())) bpm")
                    }
                }
                .listRowBackground(colors.surface)
                ForEach(names, id: \.self) { name in
                    DisclosureGroup {
                        ForEach(session.completedSets.filter { $0.exerciseName == name }) { set in
                            HStack {
                                Text("Set \(set.setNumber)")
                                Spacer()
                                Text(set.weightPounds.map { weight in
                                    "\(set.displayReps) reps × \(String(format: "%.1f", units == "kg" ? weight / 2.2046226218 : weight)) \(units)"
                                } ?? "\(set.displayReps) reps × BW")
                                    .foregroundStyle(.secondary)
                            }
                        }
                    } label: {
                        HStack {
                            Text(name).font(.headline)
                            Spacer()
                            Text("\(session.completedSets.filter { $0.exerciseName == name }.count) sets")
                                .font(.caption).foregroundStyle(.secondary)
                        }
                    }
                    .swipeActions(edge: .trailing) {
                        Button("Delete", role: .destructive) { store.deleteExercise(name, from: session) }
                    }
                    .listRowBackground(colors.surface)
                }
                Section {
                    Button("Delete entire workout", role: .destructive) { confirmDelete = true }
                }
                .listRowBackground(colors.surface)
            }.navigationTitle(session.name)
                .navigationBarTitleDisplayMode(.inline)
                .listStyle(.insetGrouped)
                .scrollContentBackground(.hidden)
                .scrollIndicators(.hidden)
                .listRowSeparatorTint(colors.border)
                .foregroundStyle(colors.text)
                .background(Color.clear)
                .toolbar { Button("Done") { dismiss() } }
                .confirmationDialog("Delete this workout and all its sets?", isPresented: $confirmDelete) {
                    Button("Delete workout", role: .destructive) { store.deleteSession(session); dismiss() }
                }
        }
        .tint(colors.accent)
        .presentationCornerRadius(24)
        .preferredColorScheme(.dark)
    }
}

struct OlympiaWeightEntryView: View {
    @ObservedObject var store: OlympiaTrainingStore
    @Environment(\.dismiss) private var dismiss
    @Environment(\.olympiaColors) private var colors
    @Environment(\.olympiaTheme) private var theme
    @AppStorage("olympia.units") private var units = "lb"
    @AppStorage("olympia.hapticsEnabled") private var hapticsEnabled = true
    @State private var value = ""
    @State private var date = Date()
    @FocusState private var weightFocused: Bool

    private var validWeight: Double? {
        guard let number = Double(value), number.isFinite, number > 0 else { return nil }
        return number
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    Text("Body weight").font(.system(size: 30, weight: .heavy))
                    VStack(alignment: .leading, spacing: 16) {
                        VStack(alignment: .leading, spacing: 16) {
                            Text("Weight (\(units))").font(.caption).foregroundStyle(colors.muted)
                            TextField("0.0", text: $value).keyboardType(.decimalPad)
                                .font(.system(size: 44, weight: .heavy)).monospacedDigit()
                                .padding(.horizontal, 18).padding(.vertical, 12)
                                .glassSurface(radius: 20)
                                .focused($weightFocused)
                                .accessibilityLabel("Body weight in \(units)")
                            DatePicker("Date", selection: $date, in: ...Date(), displayedComponents: .date)
                                .font(.subheadline)
                        }
                    }.padding(20).glassSurface(radius: 28)
                }.padding(20)
            }.scrollIndicators(.hidden)
                .scrollDismissesKeyboard(.interactively)
                .foregroundStyle(colors.text)
                .background(Color.clear)
                .navigationBarTitleDisplayMode(.inline)
                .safeAreaInset(edge: .bottom) {
                    Button {
                        guard let number = validWeight,
                              store.logWeight(number, kilograms: units == "kg", at: date) else { return }
                        OlympiaHaptics.acceptedAction(enabled: hapticsEnabled)
                        dismiss()
                    } label: {
                        Text("Save weight").font(.headline.bold()).foregroundStyle(theme.buttonText)
                            .frame(maxWidth: .infinity).frame(height: 54)
                            .background(theme.buttonFill.opacity(validWeight == nil ? 0.3 : 1), in: Capsule())
                    }.buttonStyle(OlympiaPressStyle()).disabled(validWeight == nil)
                        .padding(.horizontal, 20).padding(.bottom, 10)
                    if validWeight == nil {
                        Text("Enter a weight to enable Save.")
                            .font(.caption).foregroundStyle(colors.muted)
                            .frame(maxWidth: .infinity)
                    }
                }
                .toolbar {
                    ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } }
                    ToolbarItemGroup(placement: .keyboard) {
                        Spacer()
                        Button("Done") { weightFocused = false }
                    }
                }
                .onAppear { weightFocused = true }
        }
        .tint(theme.accent)
        .presentationCornerRadius(24)
        .presentationDragIndicator(.visible)
        .preferredColorScheme(.dark)
    }
}
