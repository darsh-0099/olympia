import Charts
import SwiftUI
import UIKit

private struct OlympiaProgressPoint: Identifiable {
    var id: Date { date }
    let date: Date
    let value: Double
}

struct OlympiaProgressView: View {
    @ObservedObject var store: OlympiaTrainingStore
    @Environment(\.olympiaColors) private var colors
    @Environment(\.olympiaTheme) private var visualTheme
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @AppStorage("olympia.units") private var units = "lb"
    @AppStorage("olympia.hapticsEnabled") private var hapticsEnabled = true
    @Binding var category: String
    @State private var exercise = ""
    @State private var metric = "Top set"
    @State private var range = "7D"

    private var exerciseNames: [String] {
        let names = store.historyExercises()
        return names.filter { categoryFor($0) == category }
    }

    private var points: [OlympiaProgressPoint] {
        let from = rangeStart ?? .distantPast
        if category == "Weight" {
            return store.weights.filter { $0.measuredAt >= from }
                .map { OlympiaProgressPoint(date: $0.measuredAt, value: units == "kg" ? $0.pounds / 2.2046226218 : $0.pounds) }
        }
        let key = normalized(exercise)
        guard !key.isEmpty else { return [] }
        let matchingSets = store.sessions.flatMap(\.completedSets).filter {
            $0.completedAt >= from && normalized($0.exerciseName) == key
        }
        let byDay = Dictionary(grouping: matchingSets) { Calendar.current.startOfDay(for: $0.completedAt) }
        return byDay.compactMap { day, sets in
            let value: Double
            if metric == "Top set" {
                guard let maximum = sets.compactMap(\.weightPounds).max() else { return nil }
                value = maximum
            } else {
                let measuredSets = sets.filter { $0.weightPounds != nil && $0.effectiveReps != nil }
                guard !measuredSets.isEmpty else { return nil }
                value = measuredSets.reduce(0) { $0 + ($1.weightPounds ?? 0) * ($1.effectiveReps ?? 0) }
            }
            return OlympiaProgressPoint(date: day,
                                        value: units == "kg" ? value / 2.2046226218 : value)
        }.sorted { $0.date < $1.date }
    }

    private var rangeStart: Date? {
        let calendar = Calendar.current
        let today = calendar.startOfDay(for: .now)
        switch range {
        case "7D": return calendar.date(byAdding: .day, value: -6, to: today)
        case "1M": return calendar.date(byAdding: .month, value: -1, to: today)
        case "3M": return calendar.date(byAdding: .month, value: -3, to: today)
        case "6M": return calendar.date(byAdding: .month, value: -6, to: today)
        case "1Y": return calendar.date(byAdding: .year, value: -1, to: today)
        default: return nil
        }
    }

    private var chartStart: Date {
        rangeStart ?? points.first?.date ?? .now
    }

    private var weightChartDomain: ClosedRange<Double> {
        let pounds = store.weights.filter { $0.measuredAt >= (rangeStart ?? .distantPast) }.map(\.pounds)
        let divisor = units == "kg" ? 2.2046226218 : 1
        let lower = ((pounds.min() ?? 0) - 10) / divisor
        let upper = ((pounds.max() ?? 0) + 10) / divisor
        return lower...upper
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 17) {
                    VStack(alignment: .leading, spacing: 2) {
                        Text("TRENDS").font(.caption.weight(.bold)).tracking(2.6).foregroundStyle(colors.muted)
                        Text("Progress").font(.system(size: 34, weight: .heavy)).tracking(-0.7)
                    }
                    selectionPills(["Push", "Pull", "Legs", "Weight"], selection: $category)
                    if category != "Weight" {
                        VStack(alignment: .leading, spacing: 9) {
                                Text("Exercise").font(.caption).foregroundStyle(colors.muted)
                                Menu {
                                    ForEach(exerciseNames, id: \.self) { name in
                                        Button {
                                            exercise = name
                                        } label: {
                                            if name == exercise { Label(name, systemImage: "checkmark") }
                                            else { Text(name) }
                                        }
                                    }
                                } label: {
                                    HStack(spacing: 10) {
                                        Text(exercise.isEmpty ? "No exercises yet" : exercise)
                                            .font(.subheadline.weight(.semibold))
                                            .lineLimit(1).truncationMode(.tail)
                                        Spacer(minLength: 0)
                                        Image(systemName: "chevron.up.chevron.down").font(.caption)
                                    }
                                    .foregroundStyle(colors.text)
                                    .frame(maxWidth: .infinity, minHeight: 44, alignment: .leading)
                                    .padding(.horizontal, 14)
                                    .glassSurface(radius: 18)
                                }
                                .disabled(exerciseNames.isEmpty)
                        }.padding(18).glassSurface(radius: 28)
                        selectionPills(["Top set", "Total volume"], selection: $metric)
                    }
                    VStack(alignment: .leading, spacing: 6) {
                        Text(category == "Weight" ? "Body weight" : exercise)
                            .font(.caption).foregroundStyle(colors.muted)
                        if let last = points.last {
                            Text(String(format: "%.1f %@", last.value, units))
                                .font(.system(size: 46, weight: .heavy)).monospacedDigit().foregroundStyle(visualTheme.text)
                                .contentTransition(.numericText())
                        } else {
                            Text("No recorded data").font(.title3.bold()).foregroundStyle(colors.text)
                        }
                    }.padding(.top, 8)
                    VStack {
                        if points.isEmpty {
                            ContentUnavailableView("No data for this selection", systemImage: "chart.xyaxis.line",
                                                   description: Text("Import workouts or record sets to see progress."))
                                .frame(height: 190)
                        } else {
                            progressChart
                        }
                    }.padding(18).glassSurface(radius: 28)
                    selectionPills(["7D", "1M", "3M", "6M", "1Y", "All"], selection: $range)
                    if points.count > 1 {
                        VStack {
                            let change = points.last!.value - points.first!.value
                            Label(String(format: "%@%.1f %@ since your first point in this range",
                                         change >= 0 ? "+" : "", change, units),
                                  systemImage: change >= 0 ? "arrow.up.right" : "arrow.down.right")
                                .font(.subheadline.bold()).foregroundStyle(colors.text)
                        }.padding(18).glassSurface(radius: 24)
                    }
                }.padding(.horizontal, 20).padding(.top, 20).padding(.bottom, 20)
            }.scrollIndicators(.hidden)
                .background { ThemeBackgroundView() }.toolbar(.hidden, for: .navigationBar)
                .onAppear { ensureSelection() }
                .onChange(of: category) { _, _ in ensureSelection() }
                .onChange(of: store.sessions.count) { _, _ in ensureSelection() }
                .onChange(of: exerciseNames) { _, _ in ensureSelection() }
        }
    }

    private var progressChart: some View {
        let chart = Chart(points) { point in
            if category == "Weight" {
                AreaMark(x: .value("Date", point.date),
                         yStart: .value("Chart floor", weightChartDomain.lowerBound),
                         yEnd: .value("Value", point.value))
                    .interpolationMethod(.catmullRom)
                    .foregroundStyle(LinearGradient(colors: [visualTheme.ringStart.opacity(0.35),
                                                             visualTheme.ringStart.opacity(0.02)],
                                                    startPoint: .top, endPoint: .bottom))
            }
            LineMark(x: .value("Date", point.date), y: .value("Value", point.value))
                .interpolationMethod(.catmullRom)
                .lineStyle(StrokeStyle(lineWidth: 3, lineCap: .round))
                .foregroundStyle(visualTheme.ringGradient)
            PointMark(x: .value("Date", point.date), y: .value("Value", point.value))
                .symbolSize(70).foregroundStyle(visualTheme.ringEnd)
        }
        .chartXScale(domain: chartStart...max(.now, points.last?.date ?? .now))
        .chartYAxis { AxisMarks(position: .leading) { value in
            AxisGridLine(stroke: StrokeStyle(lineWidth: 1)).foregroundStyle(visualTheme.hairline)
            AxisValueLabel().foregroundStyle(colors.muted)
        } }
        .chartXAxis { AxisMarks { _ in
            AxisGridLine(stroke: StrokeStyle(lineWidth: 1, dash: [3, 4])).foregroundStyle(visualTheme.hairline)
            AxisValueLabel().foregroundStyle(colors.muted)
        } }
        .chartPlotStyle { plot in plot.clipped() }
        return Group {
            if category == "Weight" { chart.chartYScale(domain: weightChartDomain) }
            else { chart }
        }.frame(height: 215)
    }

    private func selectionPills(_ options: [String], selection: Binding<String>) -> some View {
        HStack(spacing: 5) {
            ForEach(options, id: \.self) { option in
                Button {
                    if hapticsEnabled && selection.wrappedValue != option { UISelectionFeedbackGenerator().selectionChanged() }
                    withAnimation(reduceMotion ? nil : .snappy(duration: 0.3)) { selection.wrappedValue = option }
                } label: {
                    Text(option).font(.caption.weight(.semibold))
                        .foregroundStyle(selection.wrappedValue == option ? visualTheme.text : colors.muted)
                        .frame(maxWidth: .infinity).frame(minHeight: 44)
                        .background {
                            if selection.wrappedValue == option { Capsule().fill(.white.opacity(0.20)) }
                        }
                }.buttonStyle(OlympiaPressStyle())
                    .accessibilityAddTraits(selection.wrappedValue == option ? .isSelected : [])
            }
        }.padding(4).glassSurface(radius: 22).accessibilityElement(children: .contain)
    }

    private func ensureSelection() {
        if !exerciseNames.contains(exercise) { exercise = exerciseNames.first ?? "" }
    }

    private func normalized(_ name: String) -> String { olympiaExerciseKey(name) }

    private func categoryFor(_ name: String) -> String {
        let value = normalized(name)
        if ["squat", "leg", "quad", "hamstring", "calf", "glute", "lunge", "deadlift", "hipthrust"].contains(where: value.contains) { return "Legs" }
        if ["row", "pull", "back", "lat", "bicep", "curl", "facepull", "rear"].contains(where: value.contains) { return "Pull" }
        return "Push"
    }
}
