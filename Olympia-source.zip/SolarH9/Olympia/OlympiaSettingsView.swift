import SwiftUI
import UIKit
import UniformTypeIdentifiers

struct OlympiaSettingsView: View {
    @ObservedObject var store: OlympiaTrainingStore
    @Environment(\.olympiaColors) private var colors
    @Environment(\.olympiaTheme) private var visualTheme
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @AppStorage("olympia.units") private var units = "lb"
    @AppStorage("olympia.visualTheme") private var visualThemeID = "aurora"
    @AppStorage("olympia.accent") private var accent = "theme"
    @AppStorage("olympia.highContrast") private var highContrast = false
    @AppStorage("olympia.hapticsEnabled") private var hapticsEnabled = true
    @AppStorage("olympia.completionGlowEnabled") private var completionConfettiEnabled = true
    @AppStorage("olympia.completionGlowPreset") private var confettiPalette = OlympiaConfettiPalette.multicolor.rawValue
    @AppStorage("olympia.displayName") private var displayName = ""
    @State private var confettiPreviewToken = 0
    @State private var importKind: ImportKind?
    @State private var showImporter = false
    @State private var importReport: OlympiaImportReport?
    @State private var backupURL: URL?
    @State private var alertMessage: String?
    @StateObject private var cloud = OlympiaCloud.shared
    @State private var email = ""
    @State private var password = ""
    @State private var showSensor = false
    private enum ImportKind: String, Identifiable { case workouts, weights; var id: String { rawValue } }

    var body: some View {
        NavigationStack {
            ScrollView {
              VStack(alignment: .leading, spacing: 20) {
                VStack(alignment: .leading, spacing: 2) {
                    Text("OLYMPIA").font(.caption.weight(.bold)).tracking(2.6).foregroundStyle(colors.muted)
                    Text("Settings").font(.system(size: 34, weight: .heavy)).tracking(-0.7)
                }
                settingsSection {
                    HStack(spacing: 12) {
                        Image("OlympiaMark").resizable().scaledToFit().frame(width: 58, height: 58)
                            .clipShape(RoundedRectangle(cornerRadius: 16))
                        VStack(alignment: .leading) {
                            Text("Olympia").font(.headline)
                            Text("Your training data stays on this iPhone until cloud sync is connected.")
                                .font(.caption).foregroundStyle(.secondary)
                        }
                    }
                }
                settingsSection("Profile") {
                    TextField("Your name", text: $displayName)
                        .textContentType(.name).textInputAutocapitalization(.words)
                        .modifier(SettingsPillField())
                    if let email = cloud.signedInEmail { Text(email).font(.caption).foregroundStyle(.secondary) }
                }
                settingsSection("Appearance") {
                    LabeledContent("Mode") {
                        Text("Dark").foregroundStyle(colors.accent).modifier(SettingsPillField())
                    }
                    Text("Themes use a dark appearance.")
                        .font(.caption).foregroundStyle(colors.muted)
                    LabeledContent("Accent") {
                        Picker("Accent", selection: $accent) {
                            Text("Theme default").tag("theme")
                            Text("Ember orange").tag("ember")
                            Text("Sky blue").tag("sky"); Text("Emerald").tag("emerald")
                            Text("Violet").tag("violet"); Text("Sunset").tag("sunset")
                            Text("Rose pink").tag("rose"); Text("Ocean teal").tag("ocean")
                            Text("Electric lime").tag("lime"); Text("Gold").tag("gold")
                        }.labelsHidden().pickerStyle(.menu).modifier(SettingsPillField())
                    }
                    Toggle("Higher contrast", isOn: $highContrast)
                        .tint(colors.accent)
                    Text("Makes secondary labels and card outlines easier to see.")
                        .font(.caption).foregroundStyle(.secondary)
                    Divider().overlay(visualTheme.hairline)
                    HStack {
                        Text("Theme").font(.subheadline.weight(.semibold))
                        Spacer()
                        Text("6 THEMES").font(.caption2.weight(.bold)).tracking(1).foregroundStyle(colors.muted)
                    }
                    themePicker
                }
                settingsSection("Workout preferences") {
                    LabeledContent("Weight units") {
                        Picker("Weight units", selection: $units) { Text("Pounds (lb)").tag("lb"); Text("Kilograms (kg)").tag("kg") }
                            .labelsHidden().pickerStyle(.menu).modifier(SettingsPillField())
                    }
                    Toggle("Haptic feedback", isOn: $hapticsEnabled)
                        .tint(colors.accent)
                    Text("Tactile cues for sets, rest transitions, and the final countdown.")
                        .font(.caption).foregroundStyle(.secondary)
                }
                settingsSection("Workout celebration") {
                    Toggle("Completion confetti", isOn: $completionConfettiEnabled)
                        .tint(colors.accent)
                    LabeledContent("Color") {
                        Picker("Confetti color", selection: $confettiPalette) {
                            ForEach(OlympiaConfettiPalette.allCases) { palette in
                                Text(palette.title).tag(palette.rawValue)
                            }
                        }
                        .labelsHidden().pickerStyle(.menu).modifier(SettingsPillField())
                    }
                    Button {
                        confettiPreviewToken += 1
                    } label: {
                        Label("Preview confetti", systemImage: "sparkles")
                            .frame(maxWidth: .infinity, minHeight: 44)
                            .background(colors.secondarySurface, in: RoundedRectangle(cornerRadius: 12))
                    }
                    .accessibilityHint("Shows the selected confetti without starting a workout")
                    Text("Confetti appears after a fully completed workout. Reduce Motion skips the animation.")
                        .font(.caption).foregroundStyle(.secondary)
                }
                settingsSection("Data & privacy") {
                    Button { exportBackup() } label: {
                        Label("Export all training data", systemImage: "square.and.arrow.up")
                    }
                    if let backupURL { ShareLink("Share backup", item: backupURL) }
                    Button { importKind = .workouts; showImporter = true } label: {
                        Label("Import workout data", systemImage: "square.and.arrow.down")
                    }
                    Button { importKind = .weights; showImporter = true } label: {
                        Label("Import body weight data", systemImage: "square.and.arrow.down")
                    }
                    Text("Import a workout note or text file. Logged workouts become quick adds when you create a workout in Program. Weight logs can be imported separately.")
                        .font(.caption).foregroundStyle(.secondary)
                }
                settingsSection("Heart rate") {
                    Button { showSensor = true } label: {
                        Label("Connect or view heart-rate sensor", systemImage: "heart.text.square")
                    }
                    Text("Use Live to connect a Bluetooth heart-rate strap or a device broadcasting the standard Heart Rate Service. Live Activities show sensor readings while the app is open or backgrounded when iOS permits.")
                        .font(.caption).foregroundStyle(.secondary)
                    Text("Heart-rate metrics are for fitness and wellness, not diagnosis or emergency monitoring.")
                        .font(.caption).foregroundStyle(.secondary)
                }
                settingsSection("Cloud sync · Supabase") {
                    TextField("Project URL", text: $cloud.projectURL)
                        .textInputAutocapitalization(.never).autocorrectionDisabled()
                        .modifier(SettingsPillField())
                    SecureField("Publishable / anon key", text: $cloud.publishableKey)
                        .modifier(SettingsPillField())
                    if cloud.signedIn {
                        Text(cloud.signedInEmail ?? "Signed in").font(.caption).foregroundStyle(.secondary)
                        Button(cloud.isBusy ? "Syncing…" : "Sync now") { Task { await cloud.sync(store: store) } }
                            .disabled(cloud.isBusy)
                        Button("Sign out", role: .destructive) { cloud.signOut() }
                    } else {
                        TextField("Email", text: $email).textInputAutocapitalization(.never)
                            .keyboardType(.emailAddress).autocorrectionDisabled()
                            .modifier(SettingsPillField())
                        SecureField("Password", text: $password)
                            .modifier(SettingsPillField())
                        HStack {
                            Button { Task { await cloud.signIn(email: email, password: password) } } label: {
                                Text("Sign in").font(.subheadline.bold()).foregroundStyle(.white)
                                    .padding(.horizontal, 22).frame(minHeight: 44)
                                    .background(colors.accent, in: Capsule())
                            }
                            Spacer()
                            Button("Create account") { Task { await cloud.signUp(email: email, password: password) } }
                        }.disabled(!cloud.configured || cloud.isBusy || email.isEmpty || password.count < 6)
                    }
                    if let message = cloud.message { Text(message).font(.caption).foregroundStyle(.secondary) }
                    Text("Create a free Supabase project and run the included schema.sql first. Only use its publishable key here—not a service-role key.")
                        .font(.caption).foregroundStyle(.secondary)
                }
              }.padding(.horizontal, 20).padding(.top, 20).padding(.bottom, 20)
            }
            .font(.subheadline)
            .foregroundStyle(colors.text)
            .buttonStyle(OlympiaPressStyle())
            .scrollIndicators(.hidden)
            .scrollDismissesKeyboard(.interactively)
            .background(Color.clear)
            .toolbar(.hidden, for: .navigationBar)
            .sheet(isPresented: $showSensor) {
                LiveView()
                    .presentationBackground { ThemeBackgroundView() }
                    .presentationCornerRadius(24)
                    .presentationDragIndicator(.visible)
                    .preferredColorScheme(.dark)
            }
            .fileImporter(isPresented: $showImporter,
                          allowedContentTypes: [.plainText, .utf8PlainText], allowsMultipleSelection: false) { result in
                guard let kind = importKind else { return }
                importKind = nil
                do {
                    let url = try result.get().first!
                    let access = url.startAccessingSecurityScopedResource()
                    defer { if access { url.stopAccessingSecurityScopedResource() } }
                    let text = try String(contentsOf: url, encoding: .utf8)
                    importReport = kind == .workouts
                        ? OlympiaNoteImporter.importWorkouts(text, into: store)
                        : OlympiaNoteImporter.importWeights(text, into: store)
                    let report = importReport!
                    alertMessage = "Imported \(report.sessions) workouts, \(report.sets) sets, and \(report.weights) weights. \(report.skipped) lines were skipped.\(kind == .workouts && report.sessions > 0 ? " Your logged workouts are now available as quick adds in Program." : "")"
                } catch { alertMessage = error.localizedDescription }
            }
            .alert("Import / export", isPresented: Binding(get: { alertMessage != nil }, set: { if !$0 { alertMessage = nil } })) {
                Button("OK") { alertMessage = nil }
            } message: { Text(alertMessage ?? "") }
        }
        .tint(colors.accent)
        .overlay {
            OlympiaConfetti(
                palette: OlympiaConfettiPalette(rawValue: confettiPalette) ?? .multicolor,
                trigger: confettiPreviewToken
            )
        }
    }

    private func settingsSection<Content: View>(_ title: String? = nil, @ViewBuilder content: () -> Content) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            if let title { Text(title).font(.system(size: 17, weight: .heavy)).foregroundStyle(visualTheme.text).padding(.leading, 4).padding(.top, 8) }
            OlympiaCard {
                VStack(alignment: .leading, spacing: 16, content: content)
                    .frame(maxWidth: .infinity, alignment: .leading)
            }
        }
    }

    private var themePicker: some View {
        LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 12), count: 3), spacing: 14) {
            ForEach(OlympiaTheme.all) { option in
                Button {
                    if hapticsEnabled { UISelectionFeedbackGenerator().selectionChanged() }
                    withAnimation(reduceMotion ? nil : .smooth(duration: 0.45)) { visualThemeID = option.id }
                } label: {
                    VStack(alignment: .leading, spacing: 7) {
                        ZStack(alignment: .topLeading) {
                            themePreview(option)
                            Capsule().fill(option.accent).frame(width: 30, height: 8).padding(10)
                            RoundedRectangle(cornerRadius: 15, style: .continuous)
                                .fill(option.glassFill)
                                .overlay(RoundedRectangle(cornerRadius: 15).stroke(option.glassStroke, lineWidth: 1))
                                .frame(height: 40).padding(10).frame(maxHeight: .infinity, alignment: .bottom)
                        }
                        .frame(height: 104).clipShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
                        .overlay(RoundedRectangle(cornerRadius: 22, style: .continuous)
                            .stroke(.white.opacity(visualThemeID == option.id ? 1 : 0.25), lineWidth: visualThemeID == option.id ? 3 : 1))
                        HStack(spacing: 2) {
                            Text(option.name).font(.caption.weight(.bold))
                            if option.id == "aurora" { Text("· Default").font(.system(size: 10)).foregroundStyle(colors.muted) }
                        }.lineLimit(1).minimumScaleFactor(0.75)
                    }
                }
                .buttonStyle(.plain)
                .accessibilityLabel("\(option.name) theme\(option.id == "aurora" ? ", default" : "")")
                .accessibilityAddTraits(visualThemeID == option.id ? .isSelected : [])
            }
        }
    }

    @ViewBuilder private func themePreview(_ option: OlympiaTheme) -> some View {
        switch option.background {
        case .image(let asset): Image(asset).resizable().scaledToFill()
        case .mesh: Image("BgAurora").resizable().scaledToFill()
        }
    }

    private func exportBackup() {
        do {
            let encoder = JSONEncoder()
            encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
            encoder.dateEncodingStrategy = .iso8601
            let data = try encoder.encode(OlympiaBackup(store: store))
            let url = FileManager.default.temporaryDirectory.appendingPathComponent("Olympia-Backup.json")
            try data.write(to: url, options: .atomic)
            backupURL = url
        } catch { alertMessage = error.localizedDescription }
    }
}

private struct SettingsPillField: ViewModifier {
    @Environment(\.olympiaColors) private var colors
    func body(content: Content) -> some View {
        content.font(.subheadline).padding(.horizontal, 14).frame(minHeight: 44)
            .background(colors.secondarySurface, in: Capsule())
    }
}
