import SwiftUI

/// Reveals the greeting once per app launch without shifting the content below it.
struct OlympiaTypewriterGreeting: View {
    let text: String
    let color: Color
    @Binding var hasAnimatedThisLaunch: Bool

    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var animatedText: String?
    @State private var revealedCharacters = 0
    @State private var cursorVisible = true

    private struct AnimationKey: Hashable {
        let text: String
        let reduceMotion: Bool
    }

    private var displayedText: String {
        if reduceMotion { return text }
        guard animatedText == text else { return hasAnimatedThisLaunch ? text : "" }
        return String(text.prefix(revealedCharacters))
    }

    var body: some View {
        ZStack(alignment: .topLeading) {
            Text(text + "▏").hidden()
            Text(displayedText + (reduceMotion || !cursorVisible ? " " : "▏"))
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .font(.title2.bold())
        .foregroundStyle(color)
        .lineLimit(2)
        .minimumScaleFactor(0.8)
        .accessibilityElement(children: .ignore)
        .accessibilityLabel(text)
        .task(id: AnimationKey(text: text, reduceMotion: reduceMotion)) {
            animatedText = text
            guard !reduceMotion, !hasAnimatedThisLaunch else {
                revealedCharacters = text.count
                return
            }
            hasAnimatedThisLaunch = true
            revealedCharacters = 0
            guard !text.isEmpty else { return }

            for characterCount in 1...text.count {
                do {
                    try await Task.sleep(nanoseconds: 49_400_000)
                } catch {
                    return
                }
                guard !Task.isCancelled else { return }
                revealedCharacters = characterCount
            }
        }
        .task {
            guard !reduceMotion else { return }
            while !Task.isCancelled {
                do { try await Task.sleep(for: .milliseconds(550)) }
                catch { return }
                cursorVisible.toggle()
            }
        }
    }
}
