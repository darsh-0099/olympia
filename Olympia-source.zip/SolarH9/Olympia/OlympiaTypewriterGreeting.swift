import SwiftUI

/// Reveals a greeting once per text change without shifting the content below it.
struct OlympiaTypewriterGreeting: View {
    let text: String
    let color: Color

    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var animatedText: String?
    @State private var revealedCharacters = 0

    private struct AnimationKey: Hashable {
        let text: String
        let reduceMotion: Bool
    }

    private var displayedText: String {
        if reduceMotion { return text }
        guard animatedText == text else { return "" }
        return String(text.prefix(revealedCharacters))
    }

    var body: some View {
        ZStack(alignment: .topLeading) {
            Text(text).hidden()
            Text(displayedText)
        }
        .font(.title2.bold())
        .foregroundStyle(color)
        .lineLimit(2)
        .minimumScaleFactor(0.8)
        .accessibilityElement(children: .ignore)
        .accessibilityLabel(text)
        .task(id: AnimationKey(text: text, reduceMotion: reduceMotion)) {
            animatedText = text
            revealedCharacters = 0
            guard !reduceMotion else {
                revealedCharacters = text.count
                return
            }
            guard !text.isEmpty else { return }

            for characterCount in 1...text.count {
                do {
                    try await Task.sleep(nanoseconds: 38_000_000)
                } catch {
                    return
                }
                guard !Task.isCancelled else { return }
                revealedCharacters = characterCount
            }
        }
    }
}
