import Charts
import SwiftUI
import UniformTypeIdentifiers

extension Color {
    init(olympiaHex: String) {
        let value = Int(olympiaHex.trimmingCharacters(in: CharacterSet(charactersIn: "#")), radix: 16) ?? 0x63C7FF
        self.init(red: Double((value >> 16) & 255) / 255,
                  green: Double((value >> 8) & 255) / 255,
                  blue: Double(value & 255) / 255)
    }
}

struct OlympiaColors {
    let isLight: Bool
    let accent: Color
    var highContrast = false
    var background: Color { isLight ? Color(olympiaHex: "#F5F5F5") : Color(olympiaHex: "#080808") }
    var surface: Color { isLight ? .white : Color(olympiaHex: "#171717") }
    var secondarySurface: Color { isLight ? Color(olympiaHex: "#EAEAEA") : Color(olympiaHex: "#242424") }
    var text: Color { isLight ? Color(olympiaHex: "#202020") : .white }
    var muted: Color { highContrast ? (isLight ? Color(olympiaHex: "#454545") : Color(olympiaHex: "#C8C8C8")) : (isLight ? Color(olympiaHex: "#686868") : Color(olympiaHex: "#939393")) }
    var border: Color { highContrast ? (isLight ? Color(olympiaHex: "#929292") : Color(olympiaHex: "#626262")) : (isLight ? Color(olympiaHex: "#DEDEDE") : Color(olympiaHex: "#292929")) }
    static let blue = Color(olympiaHex: "#2697FF")
    static let ember = Color(olympiaHex: "#FF6B2C")
    static let cream = Color(olympiaHex: "#F5F0E7")
}

private struct OlympiaColorsKey: EnvironmentKey {
    static let defaultValue = OlympiaColors(isLight: false, accent: OlympiaColors.blue)
}

extension EnvironmentValues {
    var olympiaColors: OlympiaColors {
        get { self[OlympiaColorsKey.self] }
        set { self[OlympiaColorsKey.self] = newValue }
    }
}

struct OlympiaCard<Content: View>: View {
    @Environment(\.olympiaColors) private var colors
    @ViewBuilder var content: Content
    var body: some View {
        content.padding(18).frame(maxWidth: .infinity, alignment: .leading)
            .background(colors.surface, in: RoundedRectangle(cornerRadius: 18))
            .overlay(RoundedRectangle(cornerRadius: 18).stroke(colors.border, lineWidth: 0.75))
    }
}

/// A brief, interruptible response shared by the compact blueprint controls.
struct OlympiaPressStyle: ButtonStyle {
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .opacity(configuration.isPressed ? 0.78 : 1)
            .scaleEffect(configuration.isPressed && !reduceMotion ? 0.98 : 1)
            .animation(reduceMotion ? nil : .easeOut(duration: 0.16), value: configuration.isPressed)
    }
}

struct OlympiaRootView: View {
    private enum QuickSheet: String, Identifiable {
        case workout, weight, sensor
        var id: String { rawValue }
    }
    @ObservedObject var store: OlympiaTrainingStore
    @StateObject private var engine: OlympiaWorkoutEngine
    @Environment(\.colorScheme) private var systemScheme
    @AppStorage("olympia.theme") private var theme = "dark"
    @AppStorage("olympia.accent") private var accent = "sky"
    @AppStorage("olympia.highContrast") private var highContrast = false
    // Keep the existing storage keys so previous celebration preferences migrate intact.
    @AppStorage("olympia.completionGlowEnabled") private var completionConfettiEnabled = true
    @AppStorage("olympia.completionGlowPreset") private var confettiPalette = OlympiaConfettiPalette.multicolor.rawValue
    @Environment(\.scenePhase) private var scenePhase
    @Environment(\.dynamicTypeSize) private var dynamicTypeSize
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @Environment(\.accessibilityReduceTransparency) private var reduceTransparency
    @EnvironmentObject private var widgetSensor: SensorCoordinator
    @State private var selection = 0
    @State private var progressCategory = "Push"
    @State private var showQuickAction = false
    @State private var quickSheet: QuickSheet?
    @State private var completionConfettiToken = 0
    @State private var completionTask: Task<Void, Never>?
    @State private var completionHapticsTask: Task<Void, Never>?
    @State private var completionSummary: OlympiaCompletionSummary?
    @State private var greetingAnimatedThisLaunch = false
    @State private var greetingTime = Date()
    @Namespace private var dockSelection

    init(store: OlympiaTrainingStore) {
        self.store = store
        _engine = StateObject(wrappedValue: OlympiaWorkoutEngine(store: store))
    }

    private var colors: OlympiaColors {
        let isLight = theme == "light" || (theme == "system" && systemScheme == .light)
        let accents = ["ember": "#FF6B2C", "sky": "#2697FF", "emerald": "#63DF86", "violet": "#AD8CFF", "sunset": "#FF9D72",
                       "rose": "#FF6FAE", "ocean": "#31C7C6", "lime": "#B7E844", "gold": "#E8B54D"]
        return OlympiaColors(isLight: isLight, accent: Color(olympiaHex: accents[accent] ?? "#2697FF"),
                             highContrast: highContrast)
    }

    var body: some View {
        TabView(selection: $selection) {
            OlympiaHomeView(store: store, engine: engine,
                            onOpenProgram: { selection = 1 }, onOpenWeightProgress: {
                                progressCategory = "Weight"
                                selection = 3
                            }, onCreateWorkout: { quickSheet = .workout },
                            greetingAnimatedThisLaunch: $greetingAnimatedThisLaunch,
                            greetingTime: greetingTime)
                .tabItem { Label("Home", systemImage: "house") }.tag(0)
                .toolbar(.hidden, for: .tabBar)
            OlympiaProgramView(store: store, engine: engine).tabItem { Label("Program", systemImage: "list.bullet.rectangle") }.tag(1)
                .toolbar(.hidden, for: .tabBar)
            OlympiaProgressView(store: store, category: $progressCategory).tabItem { Label("Progress", systemImage: "chart.line.uptrend.xyaxis") }.tag(3)
                .toolbar(.hidden, for: .tabBar)
            OlympiaSettingsView(store: store).tabItem { Label("Settings", systemImage: "gearshape") }.tag(4)
                .toolbar(.hidden, for: .tabBar)
        }
        .toolbar(.hidden, for: .tabBar)
        // Reserve the dock's height in the content safe area without shortening
        // the TabView's backdrop; scrolling content can pass behind the glass.
        .safeAreaPadding(.bottom, 88)
        .background(colors.background.ignoresSafeArea())
        .overlay(alignment: .bottom) { navigationDock }
        .tint(colors.accent)
        .overlay {
            if showQuickAction { quickActionsPanel }
        }
        .overlay {
            if let completionSummary {
                completionSummaryView(completionSummary)
            }
        }
        .overlay {
            OlympiaConfetti(palette: OlympiaConfettiPalette(rawValue: confettiPalette) ?? .multicolor,
                            trigger: completionConfettiToken, active: completionSummary != nil)
        }
        .onChange(of: engine.session?.id) { previousID, currentID in
            completionTask?.cancel()
            guard let previousID, currentID == nil,
                  let saved = store.sessions.first(where: { $0.id == previousID }),
                  saved.status == "completed" else { return }
            let summary = OlympiaCompletionSummary(session: saved)
            // Allow the full-screen workout cover to dismiss before presenting the summary.
            completionTask = Task { @MainActor in
                try? await Task.sleep(for: .milliseconds(750))
                guard !Task.isCancelled else { return }
                completionSummary = summary
                if scenePhase == .active { playCompletionHaptics() }
                if completionConfettiEnabled && scenePhase == .active && !reduceMotion {
                    completionConfettiToken += 1
                }
            }
        }
        .onChange(of: scenePhase) { _, phase in
            if phase != .active { completionHapticsTask?.cancel() }
            if phase == .active { store.refresh() }
        }
        .onChange(of: widgetSensor.latestRealHeartRateSampleAt) { _, sampleDate in
            guard let sampleDate, widgetSensor.selectedSource != .simulator,
                  let bpm = widgetSensor.currentHeartRate else { return }
            store.publishWidgetSnapshot(heartRate: bpm,
                                        zone: widgetSensor.currentZone(for: bpm),
                                        sensorSampleChanged: true, sampleDate: sampleDate)
        }
        .onChange(of: widgetSensor.currentHeartRate) { _, bpm in
            if bpm == nil {
                store.publishWidgetSnapshot(heartRate: nil, zone: nil, sensorSampleChanged: true)
            }
        }
        .onChange(of: widgetSensor.selectedSource) { _, source in
            if source == .simulator {
                store.publishWidgetSnapshot(heartRate: nil, zone: nil, sensorSampleChanged: true)
            }
        }
        .onOpenURL { url in
            guard url.scheme == "olympia", url.host == "home" || url.host == "workout" else { return }
            selection = 0
        }
        .sheet(item: $quickSheet) { choice in
            switch choice {
            case .workout: OlympiaWorkoutEditor(store: store, workout: nil)
            case .weight: OlympiaWeightEntryView(store: store)
            case .sensor: LiveView()
            }
        }
        .environment(\.olympiaColors, colors)
        .preferredColorScheme(theme == "system" ? nil : (colors.isLight ? .light : .dark))
        .fullScreenCover(isPresented: Binding(get: { engine.isActive }, set: { _ in })) {
            OlympiaActiveWorkoutView(store: store, engine: engine)
                .environment(\.olympiaColors, colors)
                .preferredColorScheme(theme == "system" ? nil : (colors.isLight ? .light : .dark))
                .interactiveDismissDisabled()
        }
        .alert("Olympia", isPresented: Binding(get: { store.errorMessage != nil }, set: { if !$0 { store.errorMessage = nil } })) {
            Button("OK") { store.errorMessage = nil }
        } message: { Text(store.errorMessage ?? "") }
    }

    private func completionSummaryView(_ summary: OlympiaCompletionSummary) -> some View {
        ZStack {
            colors.background.ignoresSafeArea()
            ScrollView {
                VStack(spacing: 24) {
                    Image(systemName: "checkmark.circle.fill")
                        .font(.system(size: 64)).foregroundStyle(colors.accent)
                        .accessibilityHidden(true)
                    VStack(spacing: 8) {
                        Text("Workout complete").font(.largeTitle.bold())
                        Text(summary.name).font(.title3).foregroundStyle(colors.muted)
                    }
                    HStack(spacing: 12) {
                        completionStat("Duration", value: "\(summary.minutes) min")
                        completionStat("Sets", value: "\(summary.sets)")
                        completionStat("Exercises", value: "\(summary.exercises)")
                    }
                    Button {
                        completionHapticsTask?.cancel()
                        OlympiaHaptics.acceptedAction()
                        completionSummary = nil
                    } label: {
                        Text("Done").font(.headline)
                            .frame(maxWidth: .infinity, minHeight: 54)
                            .foregroundStyle(.white)
                            .background(colors.accent, in: RoundedRectangle(cornerRadius: 16))
                            .contentShape(Rectangle())
                    }
                    .buttonStyle(.borderless)
                    .accessibilityHint("Close workout summary")
                }
                .frame(maxWidth: 500)
                .padding(24)
                .frame(maxWidth: .infinity, minHeight: 600)
            }
        }
        .foregroundStyle(colors.text)
    }

    private func completionStat(_ title: String, value: String) -> some View {
        VStack(spacing: 6) {
            Text(value).font(.title3.bold())
            Text(title).font(.caption).foregroundStyle(colors.muted)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 18)
        .background(colors.surface, in: RoundedRectangle(cornerRadius: 16))
    }

    private func playCompletionHaptics() {
        completionHapticsTask?.cancel()
        OlympiaHaptics.workoutCompleted()
        completionHapticsTask = Task { @MainActor in
            try? await Task.sleep(for: .milliseconds(650))
            guard !Task.isCancelled, scenePhase == .active, completionSummary != nil else { return }
            OlympiaHaptics.acceptedAction()
            try? await Task.sleep(for: .milliseconds(400))
            guard !Task.isCancelled, scenePhase == .active, completionSummary != nil else { return }
            OlympiaHaptics.acceptedAction()
        }
    }

    private var navigationDock: some View {
        HStack(spacing: 2) {
            dockTab("Home", icon: "house.fill", tag: 0)
            dockTab("Program", icon: "calendar", tag: 1)
            Button { showQuickAction = true } label: {
                Image(systemName: "plus")
                    .font(.system(size: 22, weight: .medium)).foregroundStyle(colors.text)
                    .frame(maxWidth: .infinity).frame(height: 58)
                    .background(colors.text.opacity(colors.isLight ? 0.09 : 0.13), in: Capsule())
            }
            .buttonStyle(OlympiaPressStyle())
            .accessibilityLabel("Quick actions")
            dockTab("Progress", icon: "chart.bar.fill", tag: 3)
            dockTab("Settings", icon: "gearshape", tag: 4)
        }
        .padding(7)
        .background {
            if reduceTransparency {
                Capsule().fill(colors.surface)
            } else if #available(iOS 26.0, *) {
                Capsule().fill(.clear).glassEffect(.regular.interactive(), in: Capsule())
            } else {
                Capsule().fill(.ultraThinMaterial)
            }
        }
        .overlay {
            if reduceTransparency {
                Capsule().strokeBorder(colors.border, lineWidth: 1)
            }
        }
        .shadow(color: .black.opacity(colors.isLight ? 0.14 : 0.4), radius: 20, y: 8)
        .padding(.horizontal, 16).padding(.top, 8).padding(.bottom, 8)
    }

    private func dockTab(_ title: String, icon: String, tag: Int) -> some View {
        Button {
            if reduceMotion {
                selection = tag
            } else {
                withAnimation(.spring(response: 0.28, dampingFraction: 0.78)) { selection = tag }
            }
        } label: {
            VStack(spacing: 4) {
                Image(systemName: icon).font(.system(size: 19, weight: .semibold))
                if !dynamicTypeSize.isAccessibilitySize {
                    Text(title).font(.system(size: 9, weight: .medium)).lineLimit(1)
                }
            }
            .foregroundStyle(selection == tag ? colors.text : colors.muted)
            .frame(maxWidth: .infinity).frame(height: 58)
            .background {
                if selection == tag {
                    Capsule()
                        .fill(reduceTransparency ? colors.secondarySurface :
                              (colors.isLight ? Color.white.opacity(0.72) : Color.white.opacity(0.17)))
                        .overlay {
                            if reduceTransparency {
                                Capsule().strokeBorder(colors.border, lineWidth: 0.8)
                            }
                        }
                        .matchedGeometryEffect(id: "dockSelection", in: dockSelection)
                }
            }
        }
        .buttonStyle(OlympiaPressStyle())
        .accessibilityLabel(title)
        .accessibilityAddTraits(selection == tag ? .isSelected : [])
    }

    private var quickActionsPanel: some View {
        ZStack(alignment: .bottom) {
            Color.black.opacity(0.55)
                .ignoresSafeArea()
                .onTapGesture { showQuickAction = false }
            VStack(alignment: .leading, spacing: 12) {
                HStack {
                    Text("Start workout").font(.title3.bold()).foregroundStyle(colors.text)
                    Spacer()
                    Button { showQuickAction = false } label: {
                        Image(systemName: "xmark").font(.caption.bold())
                            .frame(width: 36, height: 36)
                            .background(colors.secondarySurface, in: Circle())
                    }
                    .accessibilityLabel("Close quick actions")
                }
                Text(store.workouts.isEmpty ? "Create a workout to begin." : "Choose a workout to begin your session.")
                    .font(.subheadline).foregroundStyle(colors.muted)
                if store.workouts.isEmpty {
                    quickActionRow("Create workout", icon: "plus") {
                        openQuickSheet(.workout)
                    }
                } else {
                    ScrollView {
                        VStack(spacing: 8) {
                            ForEach(store.workouts) { workout in
                                quickActionRow(workout.name, icon: "play.fill") {
                                    showQuickAction = false
                                    engine.start(workout)
                                }
                            }
                        }
                    }
                    .frame(maxHeight: 220)
                }
                quickActionRow("Log body weight", icon: "scalemass") {
                    openQuickSheet(.weight)
                }
                quickActionRow("Connect heart-rate sensor", icon: "heart") {
                    openQuickSheet(.sensor)
                }
            }
            .padding(20)
            .background(colors.surface, in: RoundedRectangle(cornerRadius: 26))
            .overlay(RoundedRectangle(cornerRadius: 26).stroke(colors.border, lineWidth: 1))
            .padding(.horizontal, 16)
            .padding(.bottom, 12)
        }
        .tint(colors.accent)
    }

    private func quickActionRow(_ title: String, icon: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            HStack(spacing: 14) {
                Image(systemName: icon).font(.system(size: 16, weight: .semibold))
                    .frame(width: 24)
                    .foregroundStyle(colors.accent)
                Text(title).font(.subheadline.bold()).foregroundStyle(colors.text)
                Spacer()
                Image(systemName: "chevron.right").font(.caption.bold()).foregroundStyle(colors.muted)
            }
            .padding(.horizontal, 16).frame(minHeight: 52)
            .background(colors.secondarySurface, in: RoundedRectangle(cornerRadius: 15))
            .contentShape(RoundedRectangle(cornerRadius: 15))
        }
        .buttonStyle(OlympiaPressStyle())
    }

    private func openQuickSheet(_ choice: QuickSheet) {
        showQuickAction = false
        DispatchQueue.main.async { quickSheet = choice }
    }
}

struct OlympiaHomeView: View {
    @ObservedObject var store: OlympiaTrainingStore
    @ObservedObject var engine: OlympiaWorkoutEngine
    let onOpenProgram: () -> Void
    let onOpenWeightProgress: () -> Void
    let onCreateWorkout: () -> Void
    @Binding var greetingAnimatedThisLaunch: Bool
    let greetingTime: Date
    @Environment(\.olympiaColors) private var colors
    @AppStorage("olympia.units") private var units = "lb"
    @AppStorage("olympia.displayName") private var displayName = ""
    @State private var showCalendar = false
    @State private var showWeightEntry = false
    @State private var showHistory = false
    @State private var selectedDate = Date()
    @State private var month = Date()
    @State private var selectedSession: OlympiaTrainingSession?
    @State private var editingWorkout: OlympiaWorkoutTemplate?
    @Environment(\.dynamicTypeSize) private var dynamicTypeSize

    private var todayWorkouts: [OlympiaWorkoutTemplate] { store.scheduledWorkouts(on: .now) }
    private var completedTodaySessions: [OlympiaTrainingSession] {
        store.sessions.filter {
            ["completed", "partial", "imported"].contains($0.status) &&
            Calendar.current.isDate($0.endedAt ?? $0.startedAt, inSameDayAs: .now)
        }
    }
    private var remainingTodayWorkouts: [OlympiaWorkoutTemplate] {
        todayWorkouts.filter { workout in
            !store.sessions.contains { session in
                ["completed", "partial", "imported"].contains(session.status) &&
                Calendar.current.isDate(session.endedAt ?? session.startedAt, inSameDayAs: .now) &&
                (session.workoutID == workout.id ||
                 (session.workoutID == nil && session.name.localizedCaseInsensitiveCompare(workout.name) == .orderedSame))
            }
        }
    }
    private var lastSession: OlympiaTrainingSession? { store.sessions.first { ["completed", "partial", "imported"].contains($0.status) } }
    private var latestWeight: OlympiaBodyWeight? { store.weights.last }
    private var completedDays: Set<Date> {
        Set(store.sessions.filter { ["completed", "partial", "imported"].contains($0.status) }
            .map { Calendar.current.startOfDay(for: $0.startedAt) })
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    homeHeader
                        VStack(alignment: .leading, spacing: 14) {
                            weekStrip
                            workoutHero
                            HStack {
                                Label(streak == 0 ? "No streak yet" : "\(streak) day streak", systemImage: "arrow.up.right")
                                    .font(.caption).foregroundStyle(colors.muted)
                                Spacer()
                                Text("Best: \(bestStreak) days").font(.caption).foregroundStyle(colors.muted)
                            }
                            Button {
                                selectedDate = .now
                                month = .now
                                showCalendar.toggle()
                            } label: {
                                Label(showCalendar ? "Hide monthly plan" : "View monthly plan",
                                      systemImage: showCalendar ? "chevron.up" : "chevron.down")
                                    .font(.caption.bold())
                                    .frame(maxWidth: .infinity, minHeight: 44)
                                    .contentShape(Rectangle())
                            }
                            .buttonStyle(OlympiaPressStyle())
                            .foregroundStyle(colors.muted)
                        }

                    if showCalendar {
                        OlympiaMonthCalendar(store: store, month: $month, selectedDate: $selectedDate,
                                            selectedSession: $selectedSession)
                    }

                    workoutGrid

                    HStack(alignment: .firstTextBaseline) {
                        VStack(alignment: .leading, spacing: 4) {
                            Text("BODY WEIGHT").font(.system(size: 10, weight: .bold)).tracking(1.7).foregroundStyle(colors.muted)
                            Text(weightLabel).font(.system(size: 30, weight: .heavy)).fontWidth(.condensed).foregroundStyle(colors.text)
                        }
                        Spacer()
                        Button { showWeightEntry = true } label: {
                            Label("Log", systemImage: "plus").font(.subheadline)
                                .padding(.horizontal, 18).padding(.vertical, 13)
                                .background(colors.secondarySurface, in: Capsule())
                                .overlay(Capsule().stroke(colors.border, lineWidth: 1))
                        }.buttonStyle(.plain).foregroundStyle(colors.text).accessibilityLabel("Log body weight")
                    }.padding(.top, 18)

                    Button(action: onOpenWeightProgress) { OlympiaCard {
                        if store.weights.count > 1 {
                            Chart(store.weights) { entry in
                                LineMark(x: .value("Date", entry.measuredAt),
                                         y: .value("Weight", units == "kg" ? entry.pounds / 2.2046226218 : entry.pounds))
                                    .foregroundStyle(colors.accent).interpolationMethod(.catmullRom)
                            }
                            .chartYScale(domain: weightChartDomain)
                            .chartYAxis { AxisMarks(position: .leading) }
                            .frame(height: 130)
                        } else {
                            Text("Your weight trend appears here after two entries.")
                                .font(.caption).foregroundStyle(colors.muted).frame(height: 100)
                        }
                    } }
                    .buttonStyle(.plain)
                    .accessibilityLabel("View body weight progress")

                    HStack {
                        Text("Last workout").font(.headline).foregroundStyle(colors.text)
                        Spacer()
                        Button("View all") { showHistory = true }
                            .font(.caption.bold()).foregroundStyle(colors.accent)
                            .frame(minHeight: 44)
                    }.padding(.top, 12)
                    if let lastSession {
                        Button { selectedSession = lastSession } label: {
                            OlympiaCard {
                                HStack {
                                    Image(systemName: "figure.strengthtraining.traditional")
                                        .frame(width: 38, height: 38).background(colors.accent.opacity(0.18), in: RoundedRectangle(cornerRadius: 11))
                                    VStack(alignment: .leading, spacing: 3) {
                                        Text(lastSession.name).font(.subheadline.bold())
                                        Text(lastSession.startedAt.formatted(date: .abbreviated, time: .omitted))
                                            .font(.caption).foregroundStyle(colors.muted)
                                    }
                                    Spacer()
                                    Text("\(lastSession.completedSets.count) sets").font(.caption).foregroundStyle(colors.muted)
                                }.foregroundStyle(colors.text)
                            }
                        }.buttonStyle(.plain)
                        OlympiaCard {
                            VStack(alignment: .leading, spacing: 5) {
                                Label("TRAINING OVERVIEW", systemImage: "sparkles")
                                    .font(.caption.bold()).foregroundStyle(colors.accent)
                                Text("\(lastSession.completedSets.count) sets recorded in your last workout. Review your top sets in Progress and aim to improve one set at a time.")
                                    .font(.caption).foregroundStyle(colors.muted)
                            }
                        }
                    } else {
                        OlympiaCard { Text("Complete or import a workout to build your history.").font(.caption).foregroundStyle(colors.muted) }
                    }
                }.padding(.horizontal, 20).padding(.top, 18).padding(.bottom, 32)
            }
            .scrollIndicators(.hidden)
            .background(colors.background)
            .toolbar(.hidden, for: .navigationBar)
            .sheet(isPresented: $showWeightEntry) { OlympiaWeightEntryView(store: store) }
            .sheet(isPresented: $showHistory) { OlympiaHistoryView(store: store) }
            .sheet(item: $selectedSession) { OlympiaSessionDetailView(store: store, session: $0) }
            .sheet(item: $editingWorkout) { OlympiaWorkoutEditor(store: store, workout: $0) }
        }
    }

    private var homeHeader: some View {
        VStack(alignment: .leading, spacing: 5) {
            Text("OLYMPIA").font(.system(size: 10, weight: .bold)).tracking(2.5)
                .foregroundStyle(colors.muted)
            OlympiaTypewriterGreeting(
                text: "\(greeting(for: greetingTime)), \(displayName.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? "athlete" : displayName.trimmingCharacters(in: .whitespacesAndNewlines)).",
                color: colors.text,
                hasAnimatedThisLaunch: $greetingAnimatedThisLaunch
            )
            .frame(maxWidth: .infinity, alignment: .leading)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(.bottom, 4)
    }

    private func greeting(for date: Date) -> String {
        switch Calendar.current.component(.hour, from: date) {
        case 0..<12: return "Good morning"
        case 12..<17: return "Good afternoon"
        default: return "Good evening"
        }
    }

    private var workoutHero: some View {
        let isRestDay = todayWorkouts.isEmpty
        let isComplete = !isRestDay && remainingTodayWorkouts.isEmpty
        return HStack(spacing: 12) {
            VStack(alignment: .leading, spacing: 6) {
                Text(isRestDay ? "Rest day" : isComplete ? "Training complete" : "Training day").font(.headline)
                Text(isRestDay ? "No workout planned today" : isComplete ? "Today's workout is done" : remainingTodayWorkouts.map(\.name).joined(separator: " · "))
                    .font(.caption).lineLimit(2)
            }
            Spacer(minLength: 0)
            Button {
                if let workout = remainingTodayWorkouts.first { engine.start(workout) }
                else if isComplete {
                    if completedTodaySessions.count == 1 { selectedSession = completedTodaySessions.first }
                    else { selectedDate = .now; month = .now; showCalendar = true }
                }
                else { onOpenProgram() }
            } label: {
                Label(isRestDay ? "Plan" : isComplete ? "View" : "Start", systemImage: isRestDay ? "plus.circle.fill" : isComplete ? "checkmark.circle.fill" : "play.circle.fill")
                    .font(.caption.bold())
                    .padding(.horizontal, 14).frame(minHeight: 44)
                    .background(.black.opacity(0.18), in: Capsule())
            }
            .buttonStyle(OlympiaPressStyle())
            .accessibilityLabel(isRestDay ? "Open your program" : isComplete ? "View today's completed workout" : "Start today's workout")
            .contextMenu {
                if !isRestDay && !isComplete {
                    Button("Postpone plan one day", systemImage: "calendar.badge.clock") { store.postponeRotationOneDay() }
                }
            }
        }
        .foregroundStyle(isRestDay ? Color.white : Color(olympiaHex: "#382618"))
        .padding(16)
        .frame(maxWidth: .infinity, minHeight: 84, alignment: .leading)
        .background(LinearGradient(
            colors: isRestDay ? [Color(olympiaHex: "#666CE3"), Color(olympiaHex: "#9690EC")] :
                [Color(olympiaHex: "#F4BD68"), Color(olympiaHex: "#E995A0")],
            startPoint: .leading, endPoint: .trailing), in: RoundedRectangle(cornerRadius: 17))
    }

    private var workoutGrid: some View {
        VStack(alignment: .leading, spacing: 14) {
            Rectangle().fill(colors.border).frame(height: 0.5).padding(.vertical, 4)
            HStack {
                Text("Workouts").font(.headline).foregroundStyle(colors.text)
                Spacer()
                Button("Manage", action: onOpenProgram).font(.caption.bold()).foregroundStyle(colors.muted)
                    .frame(minHeight: 44)
            }
            if store.workouts.isEmpty {
                OlympiaCard {
                    VStack(alignment: .leading, spacing: 12) {
                        Text("Make room for your first workout.").font(.subheadline.bold()).foregroundStyle(colors.text)
                        Text("Create a routine, plan your week, and track every set.").font(.caption).foregroundStyle(colors.muted)
                        Button("Create workout", action: onCreateWorkout).font(.subheadline.bold()).foregroundStyle(colors.accent)
                            .frame(minHeight: 44)
                    }
                }
            } else {
                LazyVGrid(columns: [GridItem(.flexible())], spacing: 10) {
                    ForEach(store.workouts) { workout in
                        workoutTile(workout)
                    }
                }
            }
        }
    }

    private func workoutTile(_ workout: OlympiaWorkoutTemplate) -> some View {
        let tint = Color(olympiaHex: workout.colorHex)
        let session = store.sessions.first { $0.workoutID == workout.id && ["completed", "partial", "imported"].contains($0.status) }
        let sets = session?.completedSets ?? []
        let highlight = sets.last { $0.effectiveReps != nil || $0.weightPounds != nil }
        return Button { editingWorkout = workout } label: {
            VStack(alignment: .leading, spacing: 7) {
                HStack {
                    Text(workout.name).font(.subheadline.bold()).foregroundStyle(tint)
                    Spacer(minLength: 8)
                    Image(systemName: "chevron.right").font(.caption).foregroundStyle(colors.muted)
                }
                if let session {
                    Text("Last: \(session.startedAt.formatted(.dateTime.month(.abbreviated).day())) · \(sets.isEmpty ? "No sets recorded" : "\(sets.count) sets")")
                        .font(.caption).foregroundStyle(colors.muted)
                    if let highlight {
                        let weight = highlight.weightPounds.map { String(format: "%g %@", units == "kg" ? $0 / 2.2046226218 : $0, units) }
                        let reps = highlight.effectiveReps.map { String(format: "%g reps", $0) }
                        Text([highlight.exerciseName, [weight, reps].compactMap { $0 }.joined(separator: " × ")].filter { !$0.isEmpty }.joined(separator: " · "))
                            .font(.caption).foregroundStyle(colors.text).lineLimit(2)
                    }
                } else {
                    Text("Not started yet").font(.caption).foregroundStyle(colors.muted)
                    if !workout.exercises.isEmpty && workout.exercises.contains(where: { $0.sets > 0 }) {
                        Text("\(workout.exercises.count) exercises · \(workout.exercises.reduce(0) { $0 + $1.sets }) planned sets")
                            .font(.caption).foregroundStyle(colors.muted)
                    }
                }
            }
            .padding(14).frame(maxWidth: .infinity, minHeight: 104, alignment: .topLeading)
            .background(colors.surface, in: RoundedRectangle(cornerRadius: 17))
            .overlay(RoundedRectangle(cornerRadius: 17).stroke(colors.border, lineWidth: 0.75))
            .contentShape(RoundedRectangle(cornerRadius: 17))
        }
        .buttonStyle(OlympiaPressStyle())
        .accessibilityLabel("\(workout.name). \(sets.count) sets in last session. Edit workout.")
        .contextMenu {
            Button("Start workout", systemImage: "play.fill") { engine.start(workout) }
            Button("Edit workout", systemImage: "pencil") { editingWorkout = workout }
            if let session {
                Button("View last session", systemImage: "clock") { selectedSession = session }
            }
        }
    }

    private var weightChartDomain: ClosedRange<Double> {
        let values = store.weights.map(\.pounds)
        let lower = (values.min() ?? 0) - 10
        let upper = (values.max() ?? 0) + 10
        let divisor = units == "kg" ? 2.2046226218 : 1
        return (lower / divisor)...(upper / divisor)
    }

    private var weightLabel: String {
        guard let latestWeight else { return "Not logged" }
        return String(format: "%.1f %@", units == "kg" ? latestWeight.pounds / 2.2046226218 : latestWeight.pounds, units)
    }

    private var weekStrip: some View {
        let calendar = Calendar.current
        let today = calendar.startOfDay(for: .now)
        let mondayOffset = (calendar.component(.weekday, from: today) + 5) % 7
        let monday = calendar.date(byAdding: .day, value: -mondayOffset, to: today) ?? today
        return HStack(spacing: 6) {
            ForEach(0..<7, id: \.self) { offset in
                let date = calendar.date(byAdding: .day, value: offset, to: monday) ?? today
                Button {
                    selectedDate = date
                    month = date
                    showCalendar = true
                } label: {
                    VStack(spacing: 4) {
                        Text("\(calendar.component(.day, from: date))")
                            .font(.system(size: 14, weight: .bold))
                            .foregroundStyle(calendar.isDateInToday(date) ? colors.text : colors.muted)
                        Text(date.formatted(.dateTime.weekday(.abbreviated)).uppercased())
                            .font(.system(size: 8, weight: .medium)).foregroundStyle(colors.muted)
                        Circle().fill(completedDays.contains(date) ? colors.accent :
                                      (store.scheduledWorkouts(on: date).first.map { Color(olympiaHex: $0.colorHex) } ?? .clear))
                            .frame(width: 4, height: 4)
                    }
                    .frame(maxWidth: .infinity).frame(height: 54)
                    .background(calendar.isDateInToday(date) ? colors.secondarySurface : .clear,
                                in: RoundedRectangle(cornerRadius: 12))
                }
                .buttonStyle(OlympiaPressStyle())
                .accessibilityElement(children: .ignore)
                .accessibilityLabel(date.formatted(date: .complete, time: .omitted))
                .accessibilityValue((calendar.isDateInToday(date) ? "Today. " : "") + (completedDays.contains(date) ? "Workout completed" : ""))
            }
        }
    }

    private var streak: Int {
        var day = Calendar.current.startOfDay(for: .now)
        if !completedDays.contains(day) { day = Calendar.current.date(byAdding: .day, value: -1, to: day) ?? day }
        var count = 0
        while completedDays.contains(day) {
            count += 1
            day = Calendar.current.date(byAdding: .day, value: -1, to: day) ?? day.addingTimeInterval(-86400)
        }
        return count
    }

    private var bestStreak: Int {
        let dates = completedDays.sorted()
        var best = 0, run = 0
        var previous: Date?
        for date in dates {
            if let previous, let next = Calendar.current.date(byAdding: .day, value: 1, to: previous),
               Calendar.current.isDate(date, inSameDayAs: next) { run += 1 }
            else { run = 1 }
            best = max(best, run); previous = date
        }
        return best
    }
}

private struct OlympiaCompletionSummary {
    let name: String
    let minutes: Int
    let sets: Int
    let exercises: Int

    init(session: OlympiaTrainingSession) {
        name = session.name
        minutes = max(0, Int((session.duration / 60).rounded()))
        let completedSets = session.completedSets
        sets = completedSets.count
        exercises = Set(completedSets.map(\.exercisePosition)).count
    }
}

enum OlympiaConfettiPalette: String, CaseIterable, Identifiable {
    case multicolor, oceanBlue, purplePink, green

    var id: String { rawValue }
    var title: String {
        switch self {
        case .multicolor: "Multicolor"
        case .oceanBlue: "Ocean Blue"
        case .purplePink: "Purple / Pink"
        case .green: "Green"
        }
    }

    var colors: [Color] {
        switch self {
        case .multicolor:
            [Color(olympiaHex: "#31B9FF"), Color(olympiaHex: "#956BFF"),
             Color(olympiaHex: "#FF68B4"), Color(olympiaHex: "#FFD070"),
             Color(olympiaHex: "#4CDD87")]
        case .oceanBlue:
            [Color(olympiaHex: "#146DFF"), Color(olympiaHex: "#47D7FF"),
             Color(olympiaHex: "#5B9BFF"), Color(olympiaHex: "#C6E9FF")]
        case .purplePink:
            [Color(olympiaHex: "#7445FF"), Color(olympiaHex: "#EB64D7"),
             Color(olympiaHex: "#FF85BD"), Color(olympiaHex: "#FBC5FF")]
        case .green:
            [Color(olympiaHex: "#28B97D"), Color(olympiaHex: "#A4EF73"),
             Color(olympiaHex: "#36D9B9"), Color(olympiaHex: "#DDF58C")]
        }
    }
}

/// A deterministic four-second shower. TimelineView exists only during playback.
struct OlympiaConfetti: View {
    let palette: OlympiaConfettiPalette
    let trigger: Int
    var active = true

    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @Environment(\.scenePhase) private var scenePhase
    @State private var startedAt: Date?
    @State private var playback: Task<Void, Never>?

    var body: some View {
        Group {
            if active, scenePhase == .active, !reduceMotion, let startedAt {
                TimelineView(.animation(minimumInterval: 1.0 / 30.0)) { timeline in
                    Canvas { context, size in
                        draw(in: context, size: size,
                             elapsed: max(0, timeline.date.timeIntervalSince(startedAt)))
                    }
                }
            }
        }
        .ignoresSafeArea()
        .allowsHitTesting(false)
        .accessibilityHidden(true)
        .onChange(of: trigger) { _, _ in play() }
        .onChange(of: active) { _, isActive in
            if !isActive { playback?.cancel(); startedAt = nil }
        }
        .onChange(of: scenePhase) { _, phase in
            if phase != .active { playback?.cancel(); startedAt = nil }
        }
        .onDisappear { playback?.cancel() }
    }

    private func play() {
        playback?.cancel()
        guard active, scenePhase == .active, !reduceMotion else { startedAt = nil; return }
        startedAt = .now
        playback = Task { @MainActor in
            try? await Task.sleep(for: .seconds(4))
            guard !Task.isCancelled else { return }
            startedAt = nil
        }
    }

    private func draw(in context: GraphicsContext, size: CGSize, elapsed: TimeInterval) {
        let progress = min(elapsed / 4, 1)
        guard progress < 1 else { return }
        let colors = palette.colors
        for index in 0..<170 {
            let drift: Double = seed(index, 1)
            let speed: Double = 0.85 + seed(index, 2) * 0.55
            let phase: Double = seed(index, 3) * 2 * .pi
            let horizontalPosition: Double = Double(size.width) * (0.03 + seed(index, 4) * 0.94)
            let oscillation: Double = sin(elapsed * (2.5 + drift * 2) + phase) * (9 + drift * 19)
            let x = CGFloat(horizontalPosition + oscillation)
            let verticalPosition: Double = Double(size.height) * (-0.22 - seed(index, 5) * 0.7 + progress * 1.8 * speed)
            let y = CGFloat(verticalPosition)
            guard y > -20, y < size.height + 20 else { continue }
            let width = CGFloat(5 + seed(index, 6) * 5)
            let height = CGFloat(8 + seed(index, 7) * 7)
            let flutter = CGFloat(max(0.15, abs(cos(elapsed * (5 + drift * 4) + phase))))
            var piece = context
            piece.translateBy(x: x, y: y)
            piece.rotate(by: .radians(elapsed * (2 + drift * 4) + phase))
            piece.opacity = (progress > 0.82 ? (1 - progress) / 0.18 : 1) * 0.94
            piece.fill(Path(roundedRect: CGRect(x: -width * flutter / 2, y: -height / 2,
                                                width: width * flutter, height: height), cornerRadius: 1),
                       with: .color(colors[index % colors.count]))
        }
    }

    private func seed(_ index: Int, _ salt: Int) -> Double {
        let indexTerm: Int = index * 173
        let saltTerm: Int = salt * 397
        let interactionTerm: Int = index * salt * 83
        let remainder: Int = (indexTerm + saltTerm + interactionTerm) % 997
        return Double(remainder) / 997.0
    }
}
