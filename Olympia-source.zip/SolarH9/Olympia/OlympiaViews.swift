import Charts
import SwiftUI
import UniformTypeIdentifiers

extension Color {
    init(olympiaHex: String) {
        let value = Int(olympiaHex.trimmingCharacters(in: CharacterSet(charactersIn: "#")), radix: 16) ?? 0x63C7FF
        self.init(red: Double((value >> 16) & 255) / 255,
                  green: Double((value >> 8) & 255) / 255,
                  blue: Double(value & 255) / 255)
    }
}

struct OlympiaColors {
    let isLight: Bool
    let accent: Color
    var highContrast = false
    var theme: OlympiaTheme = .aurora
    var background: Color { theme.backgroundFallbackBottom }
    var surface: Color { theme.glassFill }
    var secondarySurface: Color { theme.glassFill.opacity(0.8) }
    var text: Color { theme.text }
    var muted: Color { highContrast ? theme.text.opacity(0.88) : theme.muted }
    var border: Color { theme.glassStroke }
    static let blue = Color(olympiaHex: "#2697FF")
    static let ember = Color(olympiaHex: "#FF6B2C")
    static let cream = Color(olympiaHex: "#F5F0E7")
}

private struct OlympiaColorsKey: EnvironmentKey {
    static let defaultValue = OlympiaColors(isLight: false, accent: OlympiaColors.blue)
}

extension EnvironmentValues {
    var olympiaColors: OlympiaColors {
        get { self[OlympiaColorsKey.self] }
        set { self[OlympiaColorsKey.self] = newValue }
    }
}

struct OlympiaCard<Content: View>: View {
    @Environment(\.olympiaColors) private var colors
    @ViewBuilder var content: Content
    var body: some View {
        content.padding(18).frame(maxWidth: .infinity, alignment: .leading)
            .glassSurface(radius: 28)
    }
}

/// A brief, interruptible response shared by the compact blueprint controls.
struct OlympiaPressStyle: ButtonStyle {
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .opacity(configuration.isPressed ? 0.78 : 1)
            .scaleEffect(configuration.isPressed && !reduceMotion ? 0.98 : 1)
            .animation(reduceMotion ? nil : .easeOut(duration: 0.16), value: configuration.isPressed)
    }
}

struct OlympiaRootView: View {
    private enum QuickSheet: String, Identifiable {
        case workout, weight, sensor
        var id: String { rawValue }
    }
    @ObservedObject var store: OlympiaTrainingStore
    @StateObject private var engine: OlympiaWorkoutEngine
    @Environment(\.colorScheme) private var systemScheme
    @AppStorage("olympia.theme") private var theme = "dark"
    @AppStorage("olympia.visualTheme") private var visualThemeID = "aurora"
    @AppStorage("olympia.accent") private var accent = "theme"
    @AppStorage("olympia.highContrast") private var highContrast = false
    // Keep the existing storage keys so previous celebration preferences migrate intact.
    @AppStorage("olympia.completionGlowEnabled") private var completionConfettiEnabled = true
    @AppStorage("olympia.completionGlowPreset") private var confettiPalette = OlympiaConfettiPalette.multicolor.rawValue
    @Environment(\.scenePhase) private var scenePhase
    @Environment(\.dynamicTypeSize) private var dynamicTypeSize
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @Environment(\.accessibilityReduceTransparency) private var reduceTransparency
    @Environment(\.colorSchemeContrast) private var systemContrast
    @EnvironmentObject private var widgetSensor: SensorCoordinator
    @State private var selection = 0
    @State private var progressCategory = "Push"
    @State private var showQuickAction = false
    @State private var quickSheet: QuickSheet?
    @State private var completionConfettiToken = 0
    @State private var completionTask: Task<Void, Never>?
    @State private var completionHapticsTask: Task<Void, Never>?
    @State private var completionSummary: OlympiaCompletionSummary?
    @State private var greetingAnimatedThisLaunch = false
    @State private var greetingTime = Date()
    @Namespace private var dockSelection

    init(store: OlympiaTrainingStore) {
        self.store = store
        _engine = StateObject(wrappedValue: OlympiaWorkoutEngine(store: store))
    }

    private var colors: OlympiaColors {
        let accents = ["ember": "#FF6B2C", "sky": "#2697FF", "emerald": "#63DF86", "violet": "#AD8CFF", "sunset": "#FF9D72",
                       "rose": "#FF6FAE", "ocean": "#31C7C6", "lime": "#B7E844", "gold": "#E8B54D"]
        return OlympiaColors(isLight: false,
                             accent: accents[accent].map { Color(olympiaHex: $0) } ?? visualTheme.accent,
                             highContrast: highContrast, theme: visualTheme)
    }

    private var visualTheme: OlympiaTheme {
        var value = OlympiaTheme.named(visualThemeID)
        if highContrast || systemContrast == .increased {
            value.muted = value.text.opacity(0.88)
            value.glassFill = Color.white.opacity(0.25)
            value.glassStroke = Color.white.opacity(0.65)
        }
        return value
    }

    private var quickWorkouts: [OlympiaWorkoutTemplate] {
        let planned = Set(store.scheduledWorkouts(on: .now).map(\.id))
        return store.workouts.enumerated().sorted { left, right in
            let leftPlanned = planned.contains(left.element.id)
            let rightPlanned = planned.contains(right.element.id)
            return leftPlanned == rightPlanned ? left.offset < right.offset : leftPlanned
        }.map(\.element)
    }

    var body: some View {
        TabView(selection: $selection) {
            OlympiaHomeView(store: store, engine: engine,
                            onOpenProgram: { selection = 1 }, onOpenWeightProgress: {
                                progressCategory = "Weight"
                                selection = 3
                            }, onCreateWorkout: { quickSheet = .workout },
                            greetingAnimatedThisLaunch: $greetingAnimatedThisLaunch,
                            greetingTime: greetingTime)
                .tabItem { Label("Home", systemImage: "house") }.tag(0)
                .toolbar(.hidden, for: .tabBar)
            OlympiaProgramView(store: store, engine: engine).tabItem { Label("Program", systemImage: "list.bullet.rectangle") }.tag(1)
                .toolbar(.hidden, for: .tabBar)
            OlympiaProgressView(store: store, category: $progressCategory).tabItem { Label("Progress", systemImage: "chart.line.uptrend.xyaxis") }.tag(3)
                .toolbar(.hidden, for: .tabBar)
            OlympiaSettingsView(store: store).tabItem { Label("Settings", systemImage: "gearshape") }.tag(4)
                .toolbar(.hidden, for: .tabBar)
        }
        .toolbar(.hidden, for: .tabBar)
        // Reserve the dock's height in the content safe area without shortening
        // the TabView's backdrop; scrolling content can pass behind the glass.
        .safeAreaPadding(.bottom, 110)
        .background { ThemeBackgroundView() }
        .overlay(alignment: .bottom) { navigationDock }
        .tint(colors.accent)
        .sheet(isPresented: $showQuickAction) { quickActionsPanel
            .presentationDetents([.medium, .large])
            .presentationDragIndicator(.visible)
        }
        .overlay {
            if let completionSummary {
                completionSummaryView(completionSummary)
            }
        }
        .overlay {
            OlympiaConfetti(palette: OlympiaConfettiPalette(rawValue: confettiPalette) ?? .multicolor,
                            trigger: completionConfettiToken, active: completionSummary != nil)
        }
        .onChange(of: engine.session?.id) { previousID, currentID in
            completionTask?.cancel()
            guard let previousID, currentID == nil,
                  let saved = store.sessions.first(where: { $0.id == previousID }),
                  saved.status == "completed" else { return }
            let summary = OlympiaCompletionSummary(session: saved)
            // Allow the full-screen workout cover to dismiss before presenting the summary.
            completionTask = Task { @MainActor in
                try? await Task.sleep(for: .milliseconds(750))
                guard !Task.isCancelled else { return }
                completionSummary = summary
                if scenePhase == .active { playCompletionHaptics() }
                if completionConfettiEnabled && scenePhase == .active && !reduceMotion {
                    completionConfettiToken += 1
                }
            }
        }
        .onChange(of: scenePhase) { _, phase in
            if phase != .active { completionHapticsTask?.cancel() }
            if phase == .active { store.refresh() }
        }
        .onChange(of: widgetSensor.latestRealHeartRateSampleAt) { _, sampleDate in
            guard let sampleDate, widgetSensor.selectedSource != .simulator,
                  let bpm = widgetSensor.currentHeartRate else { return }
            store.publishWidgetSnapshot(heartRate: bpm,
                                        zone: widgetSensor.currentZone(for: bpm),
                                        sensorSampleChanged: true, sampleDate: sampleDate)
        }
        .onChange(of: widgetSensor.currentHeartRate) { _, bpm in
            if bpm == nil {
                store.publishWidgetSnapshot(heartRate: nil, zone: nil, sensorSampleChanged: true)
            }
        }
        .onChange(of: widgetSensor.selectedSource) { _, source in
            if source == .simulator {
                store.publishWidgetSnapshot(heartRate: nil, zone: nil, sensorSampleChanged: true)
            }
        }
        .onOpenURL { url in
            guard url.scheme == "olympia", url.host == "home" || url.host == "workout" else { return }
            selection = 0
        }
        .sheet(item: $quickSheet) { choice in
            switch choice {
            case .workout: OlympiaWorkoutEditor(store: store, workout: nil)
            case .weight: OlympiaWeightEntryView(store: store)
            case .sensor: LiveView().environment(\.solarTheme, SolarThemePalette(olympia: visualTheme))
            }
        }
        .environment(\.olympiaTheme, visualTheme)
        .environment(\.olympiaColors, colors)
        .preferredColorScheme(.dark)
        .animation(reduceMotion ? nil : .smooth(duration: 0.45), value: visualThemeID)
        .fullScreenCover(isPresented: Binding(get: { engine.isActive }, set: { _ in })) {
            OlympiaActiveWorkoutView(store: store, engine: engine)
                .environment(\.olympiaTheme, visualTheme)
                .environment(\.olympiaColors, colors)
                .preferredColorScheme(.dark)
                .interactiveDismissDisabled()
        }
        .alert("Olympia", isPresented: Binding(get: { store.errorMessage != nil }, set: { if !$0 { store.errorMessage = nil } })) {
            Button("OK") { store.errorMessage = nil }
        } message: { Text(store.errorMessage ?? "") }
    }

    private func completionSummaryView(_ summary: OlympiaCompletionSummary) -> some View {
        ZStack {
            ThemeBackgroundView()
            ScrollView {
                VStack(spacing: 24) {
                    Image(systemName: "checkmark")
                        .font(.system(size: 34, weight: .heavy))
                        .foregroundStyle(visualTheme.buttonText)
                        .frame(width: 84, height: 84)
                        .background(visualTheme.ringGradient, in: Circle())
                        .shadow(color: visualTheme.ringEnd.opacity(0.5), radius: 20)
                        .accessibilityHidden(true)
                    VStack(spacing: 8) {
                        Text("Workout complete").font(.largeTitle.bold())
                        Text(summary.name).font(.title3).foregroundStyle(colors.muted)
                    }
                    HStack(spacing: 12) {
                        completionStat("Duration", value: "\(summary.minutes) min")
                        completionStat("Sets", value: "\(summary.sets)")
                        completionStat("Exercises", value: "\(summary.exercises)")
                    }
                    OlympiaPrimaryButton(title: "Done") {
                        completionHapticsTask?.cancel()
                        OlympiaHaptics.acceptedAction()
                        completionSummary = nil
                    }
                    .accessibilityHint("Close workout summary")
                }
                .frame(maxWidth: 500)
                .padding(24)
                .frame(maxWidth: .infinity, minHeight: 600)
            }
        }
        .foregroundStyle(colors.text)
    }

    private func completionStat(_ title: String, value: String) -> some View {
        VStack(spacing: 6) {
            Text(value).font(.title3.bold())
            Text(title).font(.caption).foregroundStyle(colors.muted)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 18)
        .glassSurface(radius: 24)
    }

    private func playCompletionHaptics() {
        completionHapticsTask?.cancel()
        OlympiaHaptics.workoutCompleted()
        completionHapticsTask = Task { @MainActor in
            try? await Task.sleep(for: .milliseconds(650))
            guard !Task.isCancelled, scenePhase == .active, completionSummary != nil else { return }
            OlympiaHaptics.acceptedAction()
            try? await Task.sleep(for: .milliseconds(400))
            guard !Task.isCancelled, scenePhase == .active, completionSummary != nil else { return }
            OlympiaHaptics.acceptedAction()
        }
    }

    private var navigationDock: some View {
        OlympiaGlassGroup(content: HStack(spacing: 2) {
            dockTab("Home", icon: "house.fill", tag: 0)
            dockTab("Program", icon: "calendar", tag: 1)
            Button {
                OlympiaHaptics.acceptedAction()
                showQuickAction = true
            } label: {
                Image(systemName: "plus")
                    .font(.system(size: 25, weight: .semibold)).foregroundStyle(.white)
                    .frame(width: 50, height: 50)
                    .background(visualTheme.tabAccentGradient, in: Circle())
                    .overlay(Circle().strokeBorder(.white.opacity(0.45), lineWidth: 1))
                    .shadow(color: visualTheme.shadowColor, radius: 10, y: 6)
            }
            .buttonStyle(OlympiaPressStyle())
            .frame(maxWidth: .infinity)
            .accessibilityLabel("Start workout")
            dockTab("Progress", icon: "chart.bar.fill", tag: 3)
            dockTab("Settings", icon: "gearshape", tag: 4)
        })
        .padding(7).frame(height: 66)
        .animation(reduceMotion ? nil : .spring(response: 0.28, dampingFraction: 0.78), value: selection)
        .glassSurface(radius: 33)
        .padding(.horizontal, 16).padding(.top, 8).padding(.bottom, 20)
    }

    private func dockTab(_ title: String, icon: String, tag: Int) -> some View {
        Button {
            selection = tag
            OlympiaHaptics.acceptedAction()
        } label: {
            VStack(spacing: 4) {
                Image(systemName: icon).font(.system(size: 19, weight: .semibold))
                if !dynamicTypeSize.isAccessibilitySize {
                    Text(title).font(.system(size: 9, weight: .medium)).lineLimit(1)
                }
            }
            .foregroundStyle(selection == tag ? colors.text : colors.muted)
            .frame(maxWidth: .infinity).frame(height: 58)
            .contentShape(Rectangle())
            .background {
                if selection == tag {
                    Capsule()
                        .fill(Color.white.opacity(0.22))
                        .overlay {
                            if reduceTransparency {
                                Capsule().strokeBorder(colors.border, lineWidth: 0.8)
                            }
                        }
                        .matchedGeometryEffect(id: "dockSelection", in: dockSelection)
                }
            }
        }
        .buttonStyle(.plain)
        .accessibilityLabel(title)
        .accessibilityAddTraits(selection == tag ? .isSelected : [])
    }

    private var quickActionsPanel: some View {
        NavigationStack {
            ScrollView {
              VStack(alignment: .leading, spacing: 12) {
                HStack {
                    Text("Start workout").font(.title3.bold()).foregroundStyle(colors.text)
                    Spacer()
                    Button { showQuickAction = false } label: {
                        Image(systemName: "xmark").font(.caption.bold())
                            .frame(width: 44, height: 44)
                            .glassSurface(radius: 22)
                    }
                    .accessibilityLabel("Close start workout")
                }
                Text(store.workouts.isEmpty ? "Create a workout to begin." : "Choose a workout to begin your session.")
                    .font(.subheadline).foregroundStyle(colors.muted)
                if store.workouts.isEmpty {
                    quickActionRow("Create workout", icon: "plus") {
                        openQuickSheet(.workout)
                    }
                } else {
                    OlympiaGlassGroup(content: VStack(spacing: 8) {
                        ForEach(quickWorkouts) { workout in
                            quickActionRow(workout.name, icon: "play.fill", tint: store.scheduledWorkouts(on: .now).contains(where: { $0.id == workout.id }) ? visualTheme.accent.opacity(0.15) : nil) {
                                showQuickAction = false
                                DispatchQueue.main.asyncAfter(deadline: .now() + 0.35) { engine.start(workout) }
                            }
                        }
                    })
                }
                quickActionRow("Log body weight", icon: "scalemass") {
                    openQuickSheet(.weight)
                }
                quickActionRow("Connect heart-rate sensor", icon: "heart") {
                    openQuickSheet(.sensor)
                }
              }.padding(20)
            }
            .scrollIndicators(.hidden)
            .background { ThemeBackgroundView() }
        }
        .tint(colors.accent)
    }

    private func quickActionRow(_ title: String, icon: String, tint: Color? = nil, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            HStack(spacing: 14) {
                Image(systemName: icon).font(.system(size: 16, weight: .semibold))
                    .frame(width: 24)
                    .foregroundStyle(colors.accent)
                Text(title).font(.subheadline.bold()).foregroundStyle(colors.text)
                Spacer()
                Image(systemName: "chevron.right").font(.caption.bold()).foregroundStyle(colors.muted)
            }
            .padding(.horizontal, 16).frame(minHeight: 58)
            .glassSurface(radius: 24, tint: tint, interactive: true)
            .contentShape(RoundedRectangle(cornerRadius: 24))
        }
        .buttonStyle(OlympiaPressStyle())
    }

    private func openQuickSheet(_ choice: QuickSheet) {
        showQuickAction = false
        DispatchQueue.main.async { quickSheet = choice }
    }
}

struct OlympiaHomeView: View {
    @ObservedObject var store: OlympiaTrainingStore
    @ObservedObject var engine: OlympiaWorkoutEngine
    let onOpenProgram: () -> Void
    let onOpenWeightProgress: () -> Void
    let onCreateWorkout: () -> Void
    @Binding var greetingAnimatedThisLaunch: Bool
    let greetingTime: Date
    @Environment(\.olympiaColors) private var colors
    @Environment(\.olympiaTheme) private var theme
    @AppStorage("olympia.units") private var units = "lb"
    @AppStorage("olympia.displayName") private var displayName = ""
    @State private var showCalendar = false
    @State private var showWeightEntry = false
    @State private var showHistory = false
    @State private var selectedDate = Date()
    @State private var month = Date()
    @State private var selectedSession: OlympiaTrainingSession?
    @State private var editingWorkout: OlympiaWorkoutTemplate?
    @State private var showSubstituteChooser = false
    @State private var substituteDate = Date()
    @Environment(\.dynamicTypeSize) private var dynamicTypeSize

    private var todayWorkouts: [OlympiaWorkoutTemplate] { store.scheduledWorkouts(on: .now) }
    private var completedTodaySessions: [OlympiaTrainingSession] {
        store.sessions.filter {
            ["completed", "partial", "imported"].contains($0.status) &&
            Calendar.current.isDate($0.endedAt ?? $0.startedAt, inSameDayAs: .now)
        }
    }
    private var remainingTodayWorkouts: [OlympiaWorkoutTemplate] {
        todayWorkouts.filter { workout in
            !store.sessions.contains { session in
                ["completed", "partial", "imported"].contains(session.status) &&
                Calendar.current.isDate(session.endedAt ?? session.startedAt, inSameDayAs: .now) &&
                (session.workoutID == workout.id ||
                 (session.workoutID == nil && session.name.localizedCaseInsensitiveCompare(workout.name) == .orderedSame))
            }
        }
    }
    private var lastSession: OlympiaTrainingSession? { store.sessions.first { ["completed", "partial", "imported"].contains($0.status) } }
    private var latestWeight: OlympiaBodyWeight? { store.weights.last }
    private var completedDays: Set<Date> {
        Set(store.sessions.filter { ["completed", "partial", "imported"].contains($0.status) }
            .map { Calendar.current.startOfDay(for: $0.startedAt) })
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 14) {
                    homeHeader
                        VStack(alignment: .leading, spacing: 14) {
                            weekStrip
                            workoutHero
                            Button {
                                selectedDate = .now
                                month = .now
                                showCalendar.toggle()
                            } label: {
                                Label(showCalendar ? "Hide monthly plan" : "View monthly plan",
                                      systemImage: showCalendar ? "chevron.up" : "chevron.down")
                                    .font(.system(size: 14, weight: .bold))
                                    .padding(.horizontal, 20).frame(minHeight: 42)
                                    .glassSurface(radius: 21, interactive: true)
                            }
                            .buttonStyle(OlympiaPressStyle())
                            .foregroundStyle(colors.text)
                            .frame(maxWidth: .infinity)
                        }

                    if showCalendar {
                        OlympiaMonthCalendar(store: store, month: $month, selectedDate: $selectedDate,
                                            selectedSession: $selectedSession,
                                            onSubstitute: { date in
                                                substituteDate = date
                                                showSubstituteChooser = true
                                            })
                    }

                    workoutGrid

                    Text("Body weight").font(.system(size: 22, weight: .heavy)).foregroundStyle(colors.text)
                        .padding(.top, 16)

                    OlympiaCard {
                        HStack {
                            Text(weightLabel).font(.system(size: 38, weight: .heavy)).foregroundStyle(colors.text)
                                .minimumScaleFactor(0.7).lineLimit(1)
                            Spacer()
                            Button { showWeightEntry = true } label: {
                                Label("Log", systemImage: "plus").font(.subheadline.bold())
                                    .padding(.horizontal, 17).frame(minHeight: 44)
                                    .glassSurface(radius: 22, interactive: true)
                            }.buttonStyle(.plain).foregroundStyle(colors.text).accessibilityLabel("Log body weight")
                        }
                        if store.weights.count > 1 {
                            Chart(store.weights) { entry in
                                AreaMark(x: .value("Date", entry.measuredAt),
                                         y: .value("Weight", units == "kg" ? entry.pounds / 2.2046226218 : entry.pounds))
                                    .foregroundStyle(LinearGradient(colors: [theme.chart.opacity(0.4), theme.chart.opacity(0.01)], startPoint: .top, endPoint: .bottom))
                                LineMark(x: .value("Date", entry.measuredAt),
                                         y: .value("Weight", units == "kg" ? entry.pounds / 2.2046226218 : entry.pounds))
                                    .foregroundStyle(theme.chart).lineStyle(StrokeStyle(lineWidth: 3))
                                    .interpolationMethod(.catmullRom)
                            }
                            .chartYScale(domain: weightChartDomain)
                            .chartYAxis { AxisMarks(position: .leading) }
                            .frame(height: 130)
                        } else {
                            Text("Your weight trend appears here after two entries.")
                                .font(.caption).foregroundStyle(colors.muted).frame(height: 100)
                        }
                    }

                    HStack {
                        Text("Last workout").font(.system(size: 22, weight: .heavy)).foregroundStyle(colors.text)
                        Spacer()
                        Button("View all") { showHistory = true }
                            .font(.caption.bold()).foregroundStyle(colors.accent)
                            .frame(minHeight: 44)
                    }.padding(.top, 12)
                    if let lastSession {
                        Button { selectedSession = lastSession } label: {
                            OlympiaCard {
                                HStack {
                                    Image(systemName: "figure.strengthtraining.traditional")
                                        .frame(width: 38, height: 38).background(colors.accent.opacity(0.18), in: RoundedRectangle(cornerRadius: 11))
                                    VStack(alignment: .leading, spacing: 3) {
                                        Text(lastSession.name).font(.subheadline.bold())
                                        Text(lastSession.startedAt.formatted(date: .abbreviated, time: .omitted))
                                            .font(.caption).foregroundStyle(colors.muted)
                                    }
                                    Spacer()
                                    Text("\(lastSession.completedSets.count) sets").font(.caption).foregroundStyle(colors.muted)
                                }.foregroundStyle(colors.text)
                            }
                        }.buttonStyle(.plain)
                        OlympiaCard {
                            VStack(alignment: .leading, spacing: 5) {
                                Label("TRAINING OVERVIEW", systemImage: "sparkles")
                                    .font(.caption.bold()).foregroundStyle(colors.accent)
                                Text("\(lastSession.completedSets.count) sets recorded in your last workout. Review your top sets in Progress and aim to improve one set at a time.")
                                    .font(.subheadline).foregroundStyle(colors.text)
                            }
                        }
                    } else {
                        OlympiaCard { Text("Complete or import a workout to build your history.").font(.caption).foregroundStyle(colors.muted) }
                    }
                }.padding(.horizontal, 20).padding(.top, 28).padding(.bottom, 20)
            }
            .scrollIndicators(.hidden)
            .background(Color.clear)
            .toolbar(.hidden, for: .navigationBar)
            .sheet(isPresented: $showWeightEntry) { OlympiaWeightEntryView(store: store) }
            .sheet(isPresented: $showHistory) { OlympiaHistoryView(store: store) }
            .sheet(item: $selectedSession) { OlympiaSessionDetailView(store: store, session: $0) }
            .sheet(item: $editingWorkout) { OlympiaWorkoutEditor(store: store, workout: $0) }
            .sheet(isPresented: $showSubstituteChooser) {
                NavigationStack {
                    List(store.workouts) { workout in
                        Button {
                            if store.substituteWorkout(workout, on: substituteDate) {
                                showSubstituteChooser = false
                                if Calendar.current.isDateInToday(substituteDate) { engine.start(workout) }
                            }
                        } label: {
                            Label(workout.name, systemImage: "arrow.triangle.2.circlepath")
                                .foregroundStyle(colors.text)
                        }
                    }
                    .navigationTitle("Substitute on \(substituteDate.formatted(.dateTime.month(.abbreviated).day()))")
                    .navigationBarTitleDisplayMode(.inline)
                    .toolbar { ToolbarItem(placement: .cancellationAction) {
                        Button("Cancel") { showSubstituteChooser = false }
                    } }
                }
            }
        }
    }

    private var homeHeader: some View {
        VStack(alignment: .leading, spacing: 5) {
            Text("OLYMPIA").font(.system(size: 10, weight: .bold)).tracking(2.5)
                .foregroundStyle(colors.muted)
            OlympiaTypewriterGreeting(
                text: "\(greeting(for: greetingTime)), \(displayName.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? "athlete" : displayName.trimmingCharacters(in: .whitespacesAndNewlines)).",
                color: colors.text,
                hasAnimatedThisLaunch: $greetingAnimatedThisLaunch
            )
            .frame(maxWidth: .infinity, alignment: .leading)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(.bottom, 4)
    }

    private func greeting(for date: Date) -> String {
        switch Calendar.current.component(.hour, from: date) {
        case 0..<12: return "Good morning"
        case 12..<17: return "Good afternoon"
        default: return "Good evening"
        }
    }

    private var workoutHero: some View {
        let isRestDay = todayWorkouts.isEmpty
        let isSkipped = store.isSkipped(on: .now)
        let isComplete = !isRestDay && remainingTodayWorkouts.isEmpty
        return HStack(spacing: 18) {
            ZStack {
                OlympiaProgressRing(progress: bestStreak == 0 ? 0 : Double(streak) / Double(bestStreak))
                VStack(spacing: 1) {
                    Text("\(streak)").font(.system(size: 44, weight: .heavy))
                        .contentTransition(.numericText())
                    Text("day streak").font(.system(size: 10, weight: .medium)).foregroundStyle(colors.muted)
                }
            }.frame(width: 124, height: 124)
            VStack(alignment: .leading, spacing: 6) {
                HStack(spacing: 7) {
                    Image(systemName: isComplete ? "checkmark" : "figure.strengthtraining.traditional")
                        .font(.system(size: 13, weight: .bold))
                        .foregroundStyle(theme.buttonText)
                        .frame(width: 26, height: 26)
                        .background(theme.ringGradient, in: Circle())
                    Text(Date.now.formatted(.dateTime.weekday(.abbreviated).day()).uppercased())
                        .font(.system(size: 11, weight: .bold)).tracking(1)
                        .foregroundStyle(colors.muted)
                }
                Text(isSkipped ? "Workout skipped" : isRestDay ? "Rest day" : isComplete ? "Training complete" : remainingTodayWorkouts.first?.name ?? "Training day")
                    .font(.system(size: 21, weight: .heavy)).lineLimit(2)
                    .minimumScaleFactor(0.8)
                Text(isSkipped ? "Your plan continues tomorrow" : isRestDay ? "No workout planned today" : isComplete ? "Today's workout is done" : "Ready when you are")
                    .font(.system(size: 12)).foregroundStyle(colors.muted).lineLimit(2)
                Button {
                if isSkipped { onOpenProgram() }
                else if let workout = remainingTodayWorkouts.first { engine.start(workout) }
                else if isComplete {
                    if completedTodaySessions.count == 1 { selectedSession = completedTodaySessions.first }
                    else { selectedDate = .now; month = .now; showCalendar = true }
                }
                else { onOpenProgram() }
                } label: {
                    Label(isSkipped ? "Program" : isRestDay ? "Plan" : isComplete ? "View" : "Start", systemImage: isSkipped ? "calendar" : isRestDay ? "plus" : isComplete ? "checkmark" : "play.fill")
                        .font(.system(size: 14, weight: .heavy))
                        .foregroundStyle(theme.buttonText)
                        .padding(.horizontal, 17).frame(minHeight: 44)
                        .background(theme.buttonFill, in: Capsule())
                }
                .buttonStyle(OlympiaPressStyle())
                .accessibilityLabel(isSkipped ? "Workout skipped today. Open your program" : isRestDay ? "Open your program" : isComplete ? "View today's completed workout" : "Start today's workout")
                Text("Best: \(bestStreak) days").font(.system(size: 12)).foregroundStyle(colors.muted)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
        }
        .contextMenu {
                if store.activeProgram != nil && !store.workouts.isEmpty {
                    Button("Substitute workout", systemImage: "arrow.triangle.2.circlepath") {
                        substituteDate = .now
                        showSubstituteChooser = true
                    }
                }
                if !isRestDay && !isComplete && !isSkipped {
                    Button("Skip today's workout", systemImage: "forward.end") { store.skipPlannedWorkout() }
                    Button("Postpone plan one day", systemImage: "calendar.badge.clock") { store.postponeRotationOneDay() }
                }
        }
        .foregroundStyle(theme.text)
        .padding(20)
        .frame(maxWidth: .infinity, minHeight: 172, alignment: .leading)
        .glassSurface(radius: 38, tint: theme.ringEnd.opacity(0.16))
    }

    private var workoutGrid: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack {
                Text("Workouts").font(.system(size: 22, weight: .heavy)).foregroundStyle(colors.text)
                Spacer()
                Button("Manage", action: onOpenProgram).font(.caption.bold()).foregroundStyle(colors.muted)
                    .frame(minHeight: 44)
            }
            if store.workouts.isEmpty {
                OlympiaCard {
                    VStack(alignment: .leading, spacing: 12) {
                        Text("Make room for your first workout.").font(.subheadline.bold()).foregroundStyle(colors.text)
                        Text("Create a routine, plan your week, and track every set.").font(.caption).foregroundStyle(colors.muted)
                        Button("Create workout", action: onCreateWorkout).font(.subheadline.bold()).foregroundStyle(colors.accent)
                            .frame(minHeight: 44)
                    }
                }
            } else {
                OlympiaGlassGroup(content: LazyVGrid(columns: [GridItem(.flexible())], spacing: 10) {
                    ForEach(store.workouts) { workout in
                        workoutTile(workout)
                    }
                })
            }
        }
    }

    private func workoutTile(_ workout: OlympiaWorkoutTemplate) -> some View {
        let tint = Color(olympiaHex: workout.colorHex)
        let session = store.sessions.first { $0.workoutID == workout.id && ["completed", "partial", "imported"].contains($0.status) }
        let sets = session?.completedSets ?? []
        let highlight = sets.last { $0.effectiveReps != nil || $0.weightPounds != nil }
        return Button { editingWorkout = workout } label: {
            HStack(spacing: 12) {
                OlympiaWorkoutTile(letter: ["A", "B", "C", "D"][(store.workouts.firstIndex(where: { $0.id == workout.id }) ?? 0) % 4], color: tint)
                VStack(alignment: .leading, spacing: 3) {
                Text(workout.name).font(.system(size: 15, weight: .bold)).foregroundStyle(colors.text).lineLimit(2)
                if let session {
                    Text("Last: \(session.startedAt.formatted(.dateTime.month(.abbreviated).day())) · \(sets.isEmpty ? "No sets recorded" : "\(sets.count) sets")")
                        .font(.caption).foregroundStyle(colors.muted)
                    if let highlight {
                        let weight = highlight.weightPounds.map { String(format: "%g %@", units == "kg" ? $0 / 2.2046226218 : $0, units) }
                        let reps = highlight.effectiveReps.map { String(format: "%g reps", $0) }
                        Text([highlight.exerciseName, [weight, reps].compactMap { $0 }.joined(separator: " × ")].filter { !$0.isEmpty }.joined(separator: " · "))
                            .font(.caption).foregroundStyle(colors.text).lineLimit(2)
                    }
                } else {
                    Text("Not started yet").font(.caption).foregroundStyle(colors.muted)
                    if !workout.exercises.isEmpty && workout.exercises.contains(where: { $0.sets > 0 }) {
                        Text("\(workout.exercises.count) exercises · \(workout.exercises.reduce(0) { $0 + $1.sets }) planned sets")
                            .font(.caption).foregroundStyle(colors.muted)
                    }
                }
                }
                Spacer(minLength: 0)
                Image(systemName: "chevron.right").font(.caption.bold()).foregroundStyle(colors.muted)
            }
            .padding(16).frame(maxWidth: .infinity, minHeight: 84, alignment: .leading)
            .glassSurface(radius: 28, interactive: true)
            .contentShape(RoundedRectangle(cornerRadius: 28))
        }
        .buttonStyle(OlympiaPressStyle())
        .accessibilityLabel("\(workout.name). \(sets.count) sets in last session. Edit workout.")
        .contextMenu {
            Button("Start workout", systemImage: "play.fill") { engine.start(workout) }
            Button("Edit workout", systemImage: "pencil") { editingWorkout = workout }
            if let session {
                Button("View last session", systemImage: "clock") { selectedSession = session }
            }
        }
    }

    private var weightChartDomain: ClosedRange<Double> {
        let values = store.weights.map(\.pounds)
        let lower = (values.min() ?? 0) - 10
        let upper = (values.max() ?? 0) + 10
        let divisor = units == "kg" ? 2.2046226218 : 1
        return (lower / divisor)...(upper / divisor)
    }

    private var weightLabel: String {
        guard let latestWeight else { return "Not logged" }
        return String(format: "%.1f %@", units == "kg" ? latestWeight.pounds / 2.2046226218 : latestWeight.pounds, units)
    }

    private var weekStrip: some View {
        let calendar = Calendar.current
        let today = calendar.startOfDay(for: .now)
        let mondayOffset = (calendar.component(.weekday, from: today) + 5) % 7
        let monday = calendar.date(byAdding: .day, value: -mondayOffset, to: today) ?? today
        return HStack(spacing: 0) {
            ForEach(0..<7, id: \.self) { offset in
                let date = calendar.date(byAdding: .day, value: offset, to: monday) ?? today
                Button {
                    selectedDate = date
                    month = date
                    showCalendar = true
                } label: {
                    VStack(spacing: 4) {
                        Text(date.formatted(.dateTime.weekday(.abbreviated)).uppercased())
                            .font(.system(size: 9, weight: .bold)).foregroundStyle(colors.muted)
                        Text("\(calendar.component(.day, from: date))")
                            .font(.system(size: 18, weight: .heavy))
                            .foregroundStyle(colors.text)
                        Circle().fill(store.isSkipped(on: date) ? colors.muted : completedDays.contains(date) ? theme.ringStart :
                                      (store.scheduledWorkouts(on: date).first.map { Color(olympiaHex: $0.colorHex) } ?? .clear))
                            .frame(width: 8, height: 8)
                    }
                    .frame(maxWidth: .infinity).frame(height: 70)
                    .background(calendar.isDateInToday(date) ? Color.white.opacity(0.24) : .clear,
                                in: RoundedRectangle(cornerRadius: 22))
                }
                .buttonStyle(OlympiaPressStyle())
                .accessibilityElement(children: .ignore)
                .accessibilityLabel(date.formatted(date: .complete, time: .omitted))
                .accessibilityValue((calendar.isDateInToday(date) ? "Today. " : "") + (store.isSkipped(on: date) ? "Workout skipped" : completedDays.contains(date) ? "Workout completed" : ""))
            }
        }.padding(6).glassSurface(radius: 32)
    }

    private var streak: Int {
        var day = Calendar.current.startOfDay(for: .now)
        if !completedDays.contains(day) { day = Calendar.current.date(byAdding: .day, value: -1, to: day) ?? day }
        var count = 0
        while completedDays.contains(day) {
            count += 1
            day = Calendar.current.date(byAdding: .day, value: -1, to: day) ?? day.addingTimeInterval(-86400)
        }
        return count
    }

    private var bestStreak: Int {
        let dates = completedDays.sorted()
        var best = 0, run = 0
        var previous: Date?
        for date in dates {
            if let previous, let next = Calendar.current.date(byAdding: .day, value: 1, to: previous),
               Calendar.current.isDate(date, inSameDayAs: next) { run += 1 }
            else { run = 1 }
            best = max(best, run); previous = date
        }
        return best
    }
}

private struct OlympiaCompletionSummary {
    let name: String
    let minutes: Int
    let sets: Int
    let exercises: Int

    init(session: OlympiaTrainingSession) {
        name = session.name
        minutes = max(0, Int((session.duration / 60).rounded()))
        let completedSets = session.completedSets
        sets = completedSets.count
        exercises = Set(completedSets.map(\.exercisePosition)).count
    }
}

enum OlympiaConfettiPalette: String, CaseIterable, Identifiable {
    case multicolor, oceanBlue, purplePink, green

    var id: String { rawValue }
    var title: String {
        switch self {
        case .multicolor: "Multicolor"
        case .oceanBlue: "Ocean Blue"
        case .purplePink: "Purple / Pink"
        case .green: "Green"
        }
    }

    var colors: [Color] {
        switch self {
        case .multicolor:
            [Color(olympiaHex: "#31B9FF"), Color(olympiaHex: "#956BFF"),
             Color(olympiaHex: "#FF68B4"), Color(olympiaHex: "#FFD070"),
             Color(olympiaHex: "#4CDD87")]
        case .oceanBlue:
            [Color(olympiaHex: "#146DFF"), Color(olympiaHex: "#47D7FF"),
             Color(olympiaHex: "#5B9BFF"), Color(olympiaHex: "#C6E9FF")]
        case .purplePink:
            [Color(olympiaHex: "#7445FF"), Color(olympiaHex: "#EB64D7"),
             Color(olympiaHex: "#FF85BD"), Color(olympiaHex: "#FBC5FF")]
        case .green:
            [Color(olympiaHex: "#28B97D"), Color(olympiaHex: "#A4EF73"),
             Color(olympiaHex: "#36D9B9"), Color(olympiaHex: "#DDF58C")]
        }
    }
}

/// A deterministic four-second shower. TimelineView exists only during playback.
struct OlympiaConfetti: View {
    let palette: OlympiaConfettiPalette
    let trigger: Int
    var active = true

    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @Environment(\.scenePhase) private var scenePhase
    @State private var startedAt: Date?
    @State private var playback: Task<Void, Never>?

    var body: some View {
        Group {
            if active, scenePhase == .active, !reduceMotion, let startedAt {
                TimelineView(.animation(minimumInterval: 1.0 / 30.0)) { timeline in
                    Canvas { context, size in
                        draw(in: context, size: size,
                             elapsed: max(0, timeline.date.timeIntervalSince(startedAt)))
                    }
                }
            }
        }
        .ignoresSafeArea()
        .allowsHitTesting(false)
        .accessibilityHidden(true)
        .onChange(of: trigger) { _, _ in play() }
        .onChange(of: active) { _, isActive in
            if !isActive { playback?.cancel(); startedAt = nil }
        }
        .onChange(of: scenePhase) { _, phase in
            if phase != .active { playback?.cancel(); startedAt = nil }
        }
        .onDisappear { playback?.cancel() }
    }

    private func play() {
        playback?.cancel()
        guard active, scenePhase == .active, !reduceMotion else { startedAt = nil; return }
        startedAt = .now
        playback = Task { @MainActor in
            try? await Task.sleep(for: .seconds(4))
            guard !Task.isCancelled else { return }
            startedAt = nil
        }
    }

    private func draw(in context: GraphicsContext, size: CGSize, elapsed: TimeInterval) {
        let progress = min(elapsed / 4, 1)
        guard progress < 1 else { return }
        let colors = palette.colors
        for index in 0..<170 {
            let drift: Double = seed(index, 1)
            let speed: Double = 0.85 + seed(index, 2) * 0.55
            let phase: Double = seed(index, 3) * 2 * .pi
            let horizontalPosition: Double = Double(size.width) * (0.03 + seed(index, 4) * 0.94)
            let oscillation: Double = sin(elapsed * (2.5 + drift * 2) + phase) * (9 + drift * 19)
            let x = CGFloat(horizontalPosition + oscillation)
            let verticalPosition: Double = Double(size.height) * (-0.22 - seed(index, 5) * 0.7 + progress * 1.8 * speed)
            let y = CGFloat(verticalPosition)
            guard y > -20, y < size.height + 20 else { continue }
            let width = CGFloat(5 + seed(index, 6) * 5)
            let height = CGFloat(8 + seed(index, 7) * 7)
            let flutter = CGFloat(max(0.15, abs(cos(elapsed * (5 + drift * 4) + phase))))
            var piece = context
            piece.translateBy(x: x, y: y)
            piece.rotate(by: .radians(elapsed * (2 + drift * 4) + phase))
            piece.opacity = (progress > 0.82 ? (1 - progress) / 0.18 : 1) * 0.94
            piece.fill(Path(roundedRect: CGRect(x: -width * flutter / 2, y: -height / 2,
                                                width: width * flutter, height: height), cornerRadius: 1),
                       with: .color(colors[index % colors.count]))
        }
    }

    private func seed(_ index: Int, _ salt: Int) -> Double {
        let indexTerm: Int = index * 173
        let saltTerm: Int = salt * 397
        let interactionTerm: Int = index * salt * 83
        let remainder: Int = (indexTerm + saltTerm + interactionTerm) % 997
        return Double(remainder) / 997.0
    }
}
