import Foundation
import SwiftData
import Combine
import WidgetKit

func olympiaExerciseKey(_ name: String) -> String {
    var key = name.folding(options: [.diacriticInsensitive, .caseInsensitive], locale: .current)
        .filter(\.isLetter)
    if key.hasSuffix("s"), !key.hasSuffix("ss") { key.removeLast() }
    // A known imported-note alias; other parenthetical variants remain distinct.
    if key == "cablestraightbarbicepcurl" || key == "cablestraightbarcurlsmithbarunderarmpit" {
        return "cablestraightbarcurl"
    }
    return key
}

struct OlympiaExercise: Codable, Identifiable, Hashable {
    var id: UUID = UUID()
    var name: String
    var sets: Int
    var restSeconds: Int
    var targetWeightPounds: Double? = nil
}

struct OlympiaWorkoutSuggestion: Identifiable {
    let id: UUID
    let name: String
    let exercises: [OlympiaExercise]
    let lastPerformedAt: Date
}

struct OlympiaProgramSlot: Codable, Identifiable, Hashable {
    var id: UUID = UUID()
    var workoutID: UUID
    var weekdays: [Int] // Calendar weekday: Sunday = 1.
    var colorHex: String
    var isRest: Bool = false

    static func rest() -> Self {
        Self(workoutID: UUID(), weekdays: [], colorHex: "#000000", isRest: true)
    }

    private enum CodingKeys: String, CodingKey { case id, workoutID, weekdays, colorHex, isRest }

    init(id: UUID = UUID(), workoutID: UUID, weekdays: [Int], colorHex: String, isRest: Bool = false) {
        self.id = id; self.workoutID = workoutID; self.weekdays = weekdays
        self.colorHex = colorHex; self.isRest = isRest
    }

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        id = try values.decode(UUID.self, forKey: .id)
        workoutID = try values.decode(UUID.self, forKey: .workoutID)
        weekdays = try values.decode([Int].self, forKey: .weekdays)
        colorHex = try values.decode(String.self, forKey: .colorHex)
        isRest = try values.decodeIfPresent(Bool.self, forKey: .isRest) ?? false
    }
}

/// Stored inside the existing slotsData column so installed databases need no schema migration.
struct OlympiaSchedulePayload: Codable {
    var slots: [OlympiaProgramSlot]
    var checkedThrough: Date?
    var missedDates: [Date]
    var skippedDates: [Date] = []

    private enum CodingKeys: String, CodingKey { case slots, checkedThrough, missedDates, skippedDates }

    init(slots: [OlympiaProgramSlot], checkedThrough: Date?, missedDates: [Date], skippedDates: [Date] = []) {
        self.slots = slots; self.checkedThrough = checkedThrough
        self.missedDates = missedDates; self.skippedDates = skippedDates
    }

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        slots = try values.decode([OlympiaProgramSlot].self, forKey: .slots)
        checkedThrough = try values.decodeIfPresent(Date.self, forKey: .checkedThrough)
        missedDates = try values.decodeIfPresent([Date].self, forKey: .missedDates) ?? []
        skippedDates = try values.decodeIfPresent([Date].self, forKey: .skippedDates) ?? []
    }
}

struct OlympiaCompletedSet: Codable, Identifiable, Hashable {
    var id: UUID = UUID()
    var exerciseName: String
    var exercisePosition: Int
    var setNumber: Int
    var weightPounds: Double?
    var reps: Int?
    var preciseReps: Double? = nil
    var restSeconds: Int
    var completedAt: Date

    var effectiveReps: Double? { preciseReps ?? reps.map(Double.init) }
    var displayReps: String {
        guard let value = effectiveReps else { return "—" }
        return String(format: "%g", value)
    }
}

@Model final class OlympiaWorkoutTemplate {
    @Attribute(.unique) var id: UUID
    var name: String
    var colorHex: String
    var exercisesData: Data
    var createdAt: Date
    var updatedAt: Date

    init(id: UUID = UUID(), name: String, colorHex: String = "#63C7FF", exercises: [OlympiaExercise]) {
        self.id = id; self.name = name; self.colorHex = colorHex
        self.exercisesData = (try? JSONEncoder().encode(exercises)) ?? Data()
        self.createdAt = .now; self.updatedAt = .now
    }

    var exercises: [OlympiaExercise] {
        get { (try? JSONDecoder().decode([OlympiaExercise].self, from: exercisesData)) ?? [] }
        set { exercisesData = (try? JSONEncoder().encode(newValue)) ?? Data(); updatedAt = .now }
    }
}

@Model final class OlympiaProgram {
    @Attribute(.unique) var id: UUID
    var name: String
    var scheduleType: String
    var rotationRestDays: Int
    var rotationAnchor: Date
    var scheduleShiftDays: Int
    var slotsData: Data
    var isActive: Bool
    var updatedAt: Date

    init(id: UUID = UUID(), name: String, scheduleType: String = "weekly", rotationRestDays: Int = 0,
         rotationAnchor: Date = .now, scheduleShiftDays: Int = 0,
         slots: [OlympiaProgramSlot], isActive: Bool = true) {
        self.id = id; self.name = name; self.scheduleType = scheduleType
        self.rotationRestDays = max(0, min(7, rotationRestDays))
        self.rotationAnchor = rotationAnchor
        self.scheduleShiftDays = scheduleShiftDays
        self.slotsData = (try? JSONEncoder().encode(slots)) ?? Data()
        self.isActive = isActive; self.updatedAt = .now
    }

    var slots: [OlympiaProgramSlot] {
        get { schedulePayload.slots }
        set {
            var payload = schedulePayload
            payload.slots = newValue
            schedulePayload = payload
            updatedAt = .now
        }
    }

    var schedulePayload: OlympiaSchedulePayload {
        get {
            if let payload = try? JSONDecoder().decode(OlympiaSchedulePayload.self, from: slotsData) {
                return payload
            }
            let oldSlots = (try? JSONDecoder().decode([OlympiaProgramSlot].self, from: slotsData)) ?? []
            return OlympiaSchedulePayload(slots: oldSlots, checkedThrough: nil, missedDates: [])
        }
        set { slotsData = (try? JSONEncoder().encode(newValue)) ?? slotsData }
    }
}

@Model final class OlympiaTrainingSession {
    @Attribute(.unique) var id: UUID
    var workoutID: UUID?
    var name: String
    var heartRateSessionID: UUID?
    var averageHeartRate: Double?
    var startedAt: Date
    var endedAt: Date?
    var status: String // preparing, working, resting, paused, completed, partial, imported
    var plannedExercisesData: Data
    var completedSetsData: Data
    var exerciseIndex: Int
    var setNumber: Int
    var phaseDeadline: Date?
    var pausedRemaining: TimeInterval
    var pausedAt: Date?
    var pausedPhase: String?
    var totalPausedSeconds: TimeInterval

    init(id: UUID = UUID(), workoutID: UUID? = nil, name: String, startedAt: Date = .now,
         plannedExercises: [OlympiaExercise] = [],
         status: String = "preparing", sets: [OlympiaCompletedSet] = []) {
        self.id = id; self.workoutID = workoutID; self.name = name
        self.heartRateSessionID = nil; self.averageHeartRate = nil; self.startedAt = startedAt
        self.plannedExercisesData = (try? JSONEncoder().encode(plannedExercises)) ?? Data()
        self.status = status; self.completedSetsData = (try? JSONEncoder().encode(sets)) ?? Data()
        self.exerciseIndex = 0; self.setNumber = 1
        self.phaseDeadline = nil; self.pausedRemaining = 0; self.pausedAt = nil; self.pausedPhase = nil
        self.totalPausedSeconds = 0
    }

    var completedSets: [OlympiaCompletedSet] {
        get { (try? JSONDecoder().decode([OlympiaCompletedSet].self, from: completedSetsData)) ?? [] }
        set { completedSetsData = (try? JSONEncoder().encode(newValue)) ?? Data() }
    }

    var plannedExercises: [OlympiaExercise] {
        (try? JSONDecoder().decode([OlympiaExercise].self, from: plannedExercisesData)) ?? []
    }

    var duration: TimeInterval {
        (endedAt ?? pausedAt ?? .now).timeIntervalSince(startedAt) - totalPausedSeconds
    }
}

@Model final class OlympiaBodyWeight {
    @Attribute(.unique) var id: UUID
    var measuredAt: Date
    var pounds: Double

    init(id: UUID = UUID(), measuredAt: Date = .now, pounds: Double) {
        self.id = id; self.measuredAt = measuredAt; self.pounds = pounds
    }
}

private enum OlympiaBackupApplyError: LocalizedError {
    case duplicateID(String)

    var errorDescription: String? {
        switch self {
        case .duplicateID(let collection):
            return "The backup contains duplicate IDs in \(collection)."
        }
    }
}

@MainActor
final class OlympiaTrainingStore: ObservableObject {
    let container: ModelContainer
    private let context: ModelContext
    @Published private(set) var workouts: [OlympiaWorkoutTemplate] = []
    @Published private(set) var programs: [OlympiaProgram] = []
    @Published private(set) var sessions: [OlympiaTrainingSession] = []
    @Published private(set) var weights: [OlympiaBodyWeight] = []
    @Published var errorMessage: String?
    private var lastSensorSnapshotAt: Date?
    private var lastSensorReloadAt: Date?

    init(inMemory: Bool = false) throws {
        container = try ModelContainer(for: OlympiaWorkoutTemplate.self, OlympiaProgram.self,
                                       OlympiaTrainingSession.self, OlympiaBodyWeight.self,
                                       configurations: ModelConfiguration(isStoredInMemoryOnly: inMemory))
        context = container.mainContext
        refresh()
    }

    func refresh(now: Date = .now, calendar: Calendar = .current) {
        do {
            workouts = try context.fetch(FetchDescriptor<OlympiaWorkoutTemplate>())
                .sorted { $0.createdAt < $1.createdAt }
            programs = try context.fetch(FetchDescriptor<OlympiaProgram>())
                .sorted { $0.updatedAt > $1.updatedAt }
            sessions = try context.fetch(FetchDescriptor<OlympiaTrainingSession>())
                .sorted { $0.startedAt > $1.startedAt }
            weights = try context.fetch(FetchDescriptor<OlympiaBodyWeight>())
                .sorted { $0.measuredAt < $1.measuredAt }
            try reconcileMissedSchedule(now: now, calendar: calendar)
            errorMessage = nil
            publishWidgetSnapshot()
        } catch {
            context.rollback()
            errorMessage = error.localizedDescription
        }
    }

    func publishWidgetSnapshot(heartRate: Int? = nil, zone: Int? = nil,
                               sensorSampleChanged: Bool = false, sampleDate: Date? = nil) {
        let now = Date()
        let previousSnapshot = OlympiaWidgetSnapshot.read()
        if sensorSampleChanged,
           !sessions.contains(where: { ["preparing", "working", "resting", "paused"].contains($0.status) }) {
            return
        }
        // Sensor ingress can be faster than WidgetKit's refresh budget. Persist at
        // most every 15 seconds, and request a new active timeline at most once a minute.
        if sensorSampleChanged, heartRate != nil,
           let lastSensorSnapshotAt, now.timeIntervalSince(lastSensorSnapshotAt) < 15 { return }
        let calendar = Calendar.current
        let today = calendar.startOfDay(for: now)
        let weekdayOffset = (calendar.component(.weekday, from: today) - calendar.firstWeekday + 7) % 7
        let weekStart = calendar.date(byAdding: .day, value: -weekdayOffset, to: today) ?? today
        // Keep the current week and eight future weeks so the widget can cross
        // midnight/week boundaries even when the app has not been reopened.
        let days: [OlympiaWidgetSnapshot.Day]
        if sensorSampleChanged, let previousSnapshot {
            days = previousSnapshot.days
        } else {
            days = (0..<63).compactMap { offset -> OlympiaWidgetSnapshot.Day? in
                guard let date = calendar.date(byAdding: .day, value: offset, to: weekStart) else { return nil }
                let planned = scheduledWorkouts(on: date, calendar: calendar)
                let completed = sessions.filter {
                    ["completed", "partial", "imported"].contains($0.status) &&
                        calendar.isDate($0.endedAt ?? $0.startedAt, inSameDayAs: date)
                }.count
                return .init(date: date, plannedNames: planned.map(\.name), completedCount: completed,
                             colorHex: planned.first?.colorHex)
            }
        }
        let previous = previousSnapshot?.active
        let draft = sessions.first { ["preparing", "working", "resting", "paused"].contains($0.status) }
        let active: OlympiaWidgetSnapshot.Active? = draft.map { session in
            let retained = previous?.id == session.id ? previous : nil
            let sampleDate = sensorSampleChanged && heartRate != nil ? (sampleDate ?? now) : retained?.heartRateUpdatedAt
            let bpm = sensorSampleChanged ? heartRate : retained?.heartRate
            let currentZone = sensorSampleChanged ? zone : retained?.heartRateZone
            let exercise = session.plannedExercises.indices.contains(session.exerciseIndex)
                ? session.plannedExercises[session.exerciseIndex].name : nil
            return .init(id: session.id, name: session.name, phase: session.status,
                         exercise: exercise, setNumber: session.setNumber,
                         exerciseTotalSets: session.plannedExercises.indices.contains(session.exerciseIndex)
                            ? session.plannedExercises[session.exerciseIndex].sets : nil,
                         totalSets: session.plannedExercises.reduce(0) { $0 + $1.sets },
                         completedSets: session.completedSets.count,
                         deadline: session.phaseDeadline,
                         pausedRemaining: session.pausedRemaining,
                         heartRate: bpm, heartRateZone: currentZone, heartRateUpdatedAt: sampleDate)
        }
        if OlympiaWidgetSnapshot(generatedAt: now, weekStart: weekStart, days: days, active: active).write() {
            if !sensorSampleChanged {
                if previousSnapshot?.weekStart != weekStart || previousSnapshot?.days != days {
                    WidgetCenter.shared.reloadTimelines(ofKind: "OlympiaWeekWidget")
                }
                WidgetCenter.shared.reloadTimelines(ofKind: "OlympiaActiveWidget")
            } else {
                lastSensorSnapshotAt = now
                if heartRate == nil || lastSensorReloadAt.map({ now.timeIntervalSince($0) >= 60 }) != false {
                    WidgetCenter.shared.reloadTimelines(ofKind: "OlympiaActiveWidget")
                    lastSensorReloadAt = now
                }
            }
        }
    }

    @discardableResult
    private func save() -> Bool {
        do {
            errorMessage = nil
            try context.save()
            refresh()
            return true
        } catch {
            context.rollback()
            errorMessage = error.localizedDescription
            return false
        }
    }

    @discardableResult
    func upsertWorkout(id: UUID? = nil, name: String, colorHex: String, exercises: [OlympiaExercise]) -> Bool {
        let clean = exercises.filter { !$0.name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }
        guard !name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty, !clean.isEmpty else { return false }
        if let existing = workouts.first(where: { $0.id == id }) {
            existing.name = name.trimmingCharacters(in: .whitespacesAndNewlines)
            existing.colorHex = colorHex; existing.exercises = clean
        } else { context.insert(OlympiaWorkoutTemplate(name: name, colorHex: colorHex, exercises: clean)) }
        return save()
    }

    func deleteWorkout(_ workout: OlympiaWorkoutTemplate) {
        for program in programs {
            program.slots = program.slots.filter { $0.workoutID != workout.id }
        }
        context.delete(workout)
        save() // Historical sessions retain their exercise and set details.
    }

    @discardableResult
    func upsertProgram(id: UUID? = nil, name: String, scheduleType: String,
                       rotationRestDays: Int, rotationStartDate: Date = .now,
                       slots: [OlympiaProgramSlot]) -> Bool {
        guard !slots.isEmpty else { return false }
        for program in programs { program.isActive = false }
        if let existing = programs.first(where: { $0.id == id }) {
            existing.name = name; existing.scheduleType = scheduleType
            existing.rotationRestDays = max(0, min(7, rotationRestDays))
            existing.rotationAnchor = rotationStartDate
            existing.slots = slots; existing.isActive = true; existing.updatedAt = .now
            existing.schedulePayload = OlympiaSchedulePayload(slots: slots,
                checkedThrough: Calendar.current.date(byAdding: .day, value: -1,
                    to: max(Calendar.current.startOfDay(for: rotationStartDate),
                            Calendar.current.startOfDay(for: .now))), missedDates: [])
        } else {
            let program = OlympiaProgram(name: name, scheduleType: scheduleType,
                                          rotationRestDays: rotationRestDays,
                                          rotationAnchor: rotationStartDate, slots: slots)
            program.schedulePayload = OlympiaSchedulePayload(slots: slots,
                checkedThrough: Calendar.current.date(byAdding: .day, value: -1,
                    to: max(Calendar.current.startOfDay(for: rotationStartDate),
                            Calendar.current.startOfDay(for: .now))), missedDates: [])
            context.insert(program)
        }
        return save()
    }

    var activeProgram: OlympiaProgram? { programs.first(where: { $0.isActive }) }

    func isSkipped(on date: Date, calendar: Calendar = .current) -> Bool {
        guard let program = activeProgram else { return false }
        let day = calendar.startOfDay(for: date)
        return program.schedulePayload.skippedDates.contains { calendar.isDate($0, inSameDayAs: day) }
    }

    @discardableResult
    func skipPlannedWorkout(on date: Date = .now, calendar: Calendar = .current) -> Bool {
        guard let program = activeProgram, !scheduledWorkouts(on: date, calendar: calendar).isEmpty,
              !isSkipped(on: date, calendar: calendar) else { return false }
        let day = calendar.startOfDay(for: date)
        guard !sessions.contains(where: {
            ["preparing", "working", "resting", "paused"].contains($0.status) &&
                calendar.isDate($0.startedAt, inSameDayAs: day)
        }) else { return false }
        var payload = program.schedulePayload
        payload.skippedDates.append(day)
        program.schedulePayload = payload
        program.updatedAt = .now
        return save()
    }

    func scheduledWorkouts(on date: Date, calendar: Calendar = .current) -> [OlympiaWorkoutTemplate] {
        guard let program = activeProgram else { return [] }
        let slots = program.slots
        guard !slots.isEmpty else { return [] }
        let day = calendar.startOfDay(for: date)
        let additionalShift = program.schedulePayload.missedDates.filter { $0 < day }.count
        let selected: [OlympiaProgramSlot]
        if program.scheduleType == "rotation" {
            let days = (calendar.dateComponents([.day], from: calendar.startOfDay(for: program.rotationAnchor),
                                               to: day).day ?? 0) - additionalShift
            guard days >= 0 else { return [] }
            let cycle = slots.count + max(0, min(7, program.rotationRestDays))
            guard cycle > 0 else { return [] }
            let index = days % cycle
            selected = index < slots.count ? [slots[index]] : []
        } else {
            let shiftedDate = calendar.date(byAdding: .day,
                value: -program.scheduleShiftDays - additionalShift, to: date) ?? date
            let weekday = calendar.component(.weekday, from: shiftedDate)
            selected = slots.filter { $0.weekdays.contains(weekday) }
        }
        return selected.compactMap { slot in
            slot.isRest ? nil : workouts.first(where: { $0.id == slot.workoutID })
        }
    }

    /// Replays closed local days in order. A missed workout moves the remaining plan
    /// one day, including every subsequent rest day, without stacking two slots.
    private func reconcileMissedSchedule(now: Date, calendar: Calendar) throws {
        guard let program = activeProgram, !program.slots.isEmpty else { return }
        let today = calendar.startOfDay(for: now)
        let firstDay = calendar.startOfDay(for: program.rotationAnchor)
        var payload = program.schedulePayload
        // An installed legacy plan has no cursor. Start tracking when the new app
        // first opens rather than retroactively postponing months of old workouts.
        let initial = max(firstDay, today)
        var changed = false
        if payload.checkedThrough == nil {
            payload.checkedThrough = calendar.date(byAdding: .day, value: -1, to: initial)
            changed = true
        }
        var day = calendar.date(byAdding: .day, value: 1, to: payload.checkedThrough ?? initial) ?? today
        while day < today {
            let active = sessions.contains {
                ["preparing", "working", "resting", "paused"].contains($0.status) &&
                    calendar.isDate($0.startedAt, inSameDayAs: day)
            }
            if active { break }
            let planned = scheduledWorkouts(on: day, calendar: calendar)
            let logged = sessions.contains {
                ["completed", "partial", "imported"].contains($0.status) &&
                    calendar.isDate($0.startedAt, inSameDayAs: day)
            }
            if !planned.isEmpty && !logged && !payload.skippedDates.contains(where: { calendar.isDate($0, inSameDayAs: day) }) {
                payload.missedDates.append(day)
            }
            payload.checkedThrough = day
            program.schedulePayload = payload
            changed = true
            guard let next = calendar.date(byAdding: .day, value: 1, to: day) else { break }
            day = next
        }
        if changed {
            program.schedulePayload = payload
            try context.save()
        }
    }

    func postponeRotationOneDay() {
        guard let program = activeProgram else { return }
        if program.scheduleType == "rotation" {
            program.rotationAnchor = Calendar.current.date(byAdding: .day, value: 1, to: program.rotationAnchor) ?? program.rotationAnchor
        } else {
            program.scheduleShiftDays += 1
        }
        program.updatedAt = .now
        save()
    }

    func createSession(for workout: OlympiaWorkoutTemplate) -> OlympiaTrainingSession? {
        let session = OlympiaTrainingSession(workoutID: workout.id, name: workout.name,
                                             plannedExercises: workout.exercises)
        session.phaseDeadline = .now.addingTimeInterval(120)
        context.insert(session)
        guard save() else { return nil }
        return session
    }

    @discardableResult
    func persistSession(_ session: OlympiaTrainingSession) -> Bool { save() }

    func deleteSession(_ session: OlympiaTrainingSession) { context.delete(session); save() }

    func deleteExercise(_ name: String, from session: OlympiaTrainingSession) {
        session.completedSets = session.completedSets.filter { $0.exerciseName != name }
        save()
    }

    @discardableResult
    func logWeight(_ value: Double, kilograms: Bool, at date: Date = .now) -> Bool {
        let pounds = kilograms ? value * 2.2046226218 : value
        guard pounds.isFinite, pounds >= 50, pounds <= 500 else {
            errorMessage = "Enter a weight between 50 and 500 lb."
            return false
        }
        context.insert(OlympiaBodyWeight(measuredAt: date, pounds: pounds))
        return save()
    }

    func deleteWeight(_ entry: OlympiaBodyWeight) { context.delete(entry); save() }

    func previousSet(exercise: String, setNumber: Int) -> OlympiaCompletedSet? {
        let key = olympiaExerciseKey(exercise)
        return sessions.flatMap { $0.completedSets }
            .filter { olympiaExerciseKey($0.exerciseName) == key && $0.setNumber == setNumber }
            .sorted { $0.completedAt > $1.completedAt }.first
    }

    func historyExercises() -> [String] {
        var byKey: [String: String] = [:]
        for name in sessions.flatMap({ $0.completedSets.map(\.exerciseName) }) +
                    workouts.flatMap({ $0.exercises.map(\.name) }) {
            let key = olympiaExerciseKey(name)
            if byKey[key] == nil { byKey[key] = name }
        }
        return byKey.values.sorted()
    }

    func historyWorkoutSuggestions() -> [OlympiaWorkoutSuggestion] {
        var seenRoutines = Set<String>()
        return sessions.compactMap { session in
            let sets = session.completedSets
            guard !sets.isEmpty else { return nil }
            let nameKey = session.name.trimmingCharacters(in: .whitespacesAndNewlines)
                .folding(options: [.diacriticInsensitive, .caseInsensitive], locale: .current)
            guard !nameKey.isEmpty else { return nil }

            var orderedKeys: [String] = []
            var grouped: [String: [OlympiaCompletedSet]] = [:]
            for set in sets.sorted(by: { $0.exercisePosition < $1.exercisePosition }) {
                let nameKey = olympiaExerciseKey(set.exerciseName)
                guard !nameKey.isEmpty else { continue }
                let key = "\(set.exercisePosition):\(nameKey)"
                if grouped[key] == nil { orderedKeys.append(key) }
                grouped[key, default: []].append(set)
            }
            let exercises = orderedKeys.compactMap { key -> OlympiaExercise? in
                guard let recorded = grouped[key], let first = recorded.first else { return nil }
                return OlympiaExercise(name: first.exerciseName,
                                       sets: max(1, min(12, Set(recorded.map(\.setNumber)).count)),
                                       restSeconds: first.restSeconds > 0 ? first.restSeconds : 90,
                                       targetWeightPounds: recorded.compactMap(\.weightPounds).last)
            }
            guard !exercises.isEmpty else { return nil }
            let signature = nameKey + "|" + exercises.map { olympiaExerciseKey($0.name) }.joined(separator: "|")
            guard seenRoutines.insert(signature).inserted else { return nil }
            return OlympiaWorkoutSuggestion(id: session.id, name: session.name,
                                            exercises: exercises, lastPerformedAt: session.startedAt)
        }
    }

    func addImportedSession(name: String, date: Date, sets: [OlympiaCompletedSet]) {
        guard !sets.isEmpty else { return }
        if let existing = sessions.first(where: {
            $0.status == "imported" && $0.name == name &&
            Calendar.current.isDate($0.startedAt, inSameDayAs: date)
        }) {
            existing.completedSets = sets
        } else {
            let session = OlympiaTrainingSession(name: name, startedAt: date, status: "imported", sets: sets)
            session.endedAt = date
            context.insert(session)
        }
        save()
    }

    func importedWeightExists(on date: Date) -> Bool {
        weights.contains { Calendar.current.isDate($0.measuredAt, inSameDayAs: date) }
    }

    /// Replaces the local snapshot with a backup as one SwiftData transaction.
    /// The caller can surface a failure without leaving a partially applied backup.
    func applyBackup(_ backup: OlympiaBackup) throws {
        let wasAutosaveEnabled = context.autosaveEnabled
        context.autosaveEnabled = false
        defer { context.autosaveEnabled = wasAutosaveEnabled }
        do {
            func requireUniqueIDs<Item>(_ items: [Item], in collection: String,
                                        id: (Item) -> UUID) throws {
                guard Set(items.map(id)).count == items.count else {
                    throw OlympiaBackupApplyError.duplicateID(collection)
                }
            }
            try requireUniqueIDs(backup.workouts, in: "workouts", id: { $0.id })
            try requireUniqueIDs(backup.programs, in: "programs", id: { $0.id })
            try requireUniqueIDs(backup.sessions, in: "sessions", id: { $0.id })
            try requireUniqueIDs(backup.weights, in: "weights", id: { $0.id })

            let encoder = JSONEncoder()
            let encodedWorkouts = try backup.workouts.map { ($0, try encoder.encode($0.exercises)) }
            let encodedPrograms = try backup.programs.map {
                ($0, try encoder.encode(OlympiaSchedulePayload(slots: $0.slots,
                    checkedThrough: $0.checkedThrough, missedDates: $0.missedDates,
                    skippedDates: $0.skippedDates)))
            }
            let encodedSessions = try backup.sessions.map {
                ($0, try encoder.encode($0.plannedExercises), try encoder.encode($0.sets))
            }

            let localWorkouts = try context.fetch(FetchDescriptor<OlympiaWorkoutTemplate>())
            let localPrograms = try context.fetch(FetchDescriptor<OlympiaProgram>())
            let localSessions = try context.fetch(FetchDescriptor<OlympiaTrainingSession>())
            let localWeights = try context.fetch(FetchDescriptor<OlympiaBodyWeight>())

            let workoutIDs = Set(backup.workouts.map(\.id))
            let programIDs = Set(backup.programs.map(\.id))
            let sessionIDs = Set(backup.sessions.map(\.id))
            let weightIDs = Set(backup.weights.map(\.id))

            for item in localWorkouts where !workoutIDs.contains(item.id) { context.delete(item) }
            for item in localPrograms where !programIDs.contains(item.id) { context.delete(item) }
            for item in localSessions where !sessionIDs.contains(item.id) { context.delete(item) }
            for item in localWeights where !weightIDs.contains(item.id) { context.delete(item) }

            let workoutsByID = Dictionary(localWorkouts.map { ($0.id, $0) }, uniquingKeysWith: { first, _ in first })
            for (item, exercisesData) in encodedWorkouts {
                if let existing = workoutsByID[item.id] {
                    existing.name = item.name
                    existing.colorHex = item.colorHex
                    existing.exercisesData = exercisesData
                    existing.updatedAt = .now
                } else {
                    let workout = OlympiaWorkoutTemplate(id: item.id, name: item.name,
                                                         colorHex: item.colorHex, exercises: item.exercises)
                    workout.exercisesData = exercisesData
                    context.insert(workout)
                }
            }

            let programsByID = Dictionary(localPrograms.map { ($0.id, $0) }, uniquingKeysWith: { first, _ in first })
            for (item, slotsData) in encodedPrograms {
                if let existing = programsByID[item.id] {
                    existing.name = item.name
                    existing.scheduleType = item.scheduleType
                    existing.rotationRestDays = item.rotationRestDays
                    existing.rotationAnchor = item.rotationAnchor
                    existing.scheduleShiftDays = item.scheduleShiftDays
                    existing.slotsData = slotsData
                    existing.isActive = item.isActive
                    existing.updatedAt = .now
                } else {
                    let program = OlympiaProgram(id: item.id, name: item.name,
                                                 scheduleType: item.scheduleType,
                                                 rotationRestDays: item.rotationRestDays,
                                                 rotationAnchor: item.rotationAnchor,
                                                 scheduleShiftDays: item.scheduleShiftDays,
                                                 slots: item.slots, isActive: item.isActive)
                    program.slotsData = slotsData
                    context.insert(program)
                }
            }

            let sessionsByID = Dictionary(localSessions.map { ($0.id, $0) }, uniquingKeysWith: { first, _ in first })
            for (item, plannedExercisesData, completedSetsData) in encodedSessions {
                let session: OlympiaTrainingSession
                if let existing = sessionsByID[item.id] {
                    session = existing
                } else {
                    session = OlympiaTrainingSession(id: item.id, workoutID: item.workoutID,
                                                     name: item.name, startedAt: item.startedAt,
                                                     plannedExercises: item.plannedExercises,
                                                     status: item.status, sets: item.sets)
                    context.insert(session)
                }
                session.workoutID = item.workoutID
                session.name = item.name
                session.heartRateSessionID = item.heartRateSessionID
                session.averageHeartRate = item.averageHeartRate
                session.startedAt = item.startedAt
                session.endedAt = item.endedAt
                session.status = item.status
                session.plannedExercisesData = plannedExercisesData
                session.completedSetsData = completedSetsData
                session.exerciseIndex = item.exerciseIndex
                session.setNumber = item.setNumber
                session.phaseDeadline = item.phaseDeadline
                session.pausedRemaining = item.pausedRemaining
                session.pausedAt = item.pausedAt
                session.pausedPhase = item.pausedPhase
                session.totalPausedSeconds = item.totalPausedSeconds
            }

            let weightsByID = Dictionary(localWeights.map { ($0.id, $0) }, uniquingKeysWith: { first, _ in first })
            for item in backup.weights {
                if let existing = weightsByID[item.id] {
                    existing.measuredAt = item.measuredAt
                    existing.pounds = item.pounds
                } else {
                    context.insert(OlympiaBodyWeight(id: item.id, measuredAt: item.measuredAt,
                                                     pounds: item.pounds))
                }
            }

            try context.save()
            refresh()
        } catch {
            context.rollback()
            refresh()
            throw error
        }
    }
}
