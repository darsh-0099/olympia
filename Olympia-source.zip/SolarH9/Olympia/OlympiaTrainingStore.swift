import Foundation
import SwiftData
import Combine

func olympiaExerciseKey(_ name: String) -> String {
    var key = name.folding(options: [.diacriticInsensitive, .caseInsensitive], locale: .current)
        .filter(\.isLetter)
    if key.hasSuffix("s"), !key.hasSuffix("ss") { key.removeLast() }
    // A known imported-note alias; other parenthetical variants remain distinct.
    if key == "cablestraightbarbicepcurl" || key == "cablestraightbarcurlsmithbarunderarmpit" {
        return "cablestraightbarcurl"
    }
    return key
}

struct OlympiaExercise: Codable, Identifiable, Hashable {
    var id: UUID = UUID()
    var name: String
    var sets: Int
    var restSeconds: Int
    var targetWeightPounds: Double? = nil
}

struct OlympiaWorkoutSuggestion: Identifiable {
    let id: UUID
    let name: String
    let exercises: [OlympiaExercise]
    let lastPerformedAt: Date
}

struct OlympiaProgramSlot: Codable, Identifiable, Hashable {
    var id: UUID = UUID()
    var workoutID: UUID
    var weekdays: [Int] // Calendar weekday: Sunday = 1.
    var colorHex: String
}

struct OlympiaCompletedSet: Codable, Identifiable, Hashable {
    var id: UUID = UUID()
    var exerciseName: String
    var exercisePosition: Int
    var setNumber: Int
    var weightPounds: Double?
    var reps: Int?
    var preciseReps: Double? = nil
    var restSeconds: Int
    var completedAt: Date

    var effectiveReps: Double? { preciseReps ?? reps.map(Double.init) }
    var displayReps: String {
        guard let value = effectiveReps else { return "—" }
        return String(format: "%g", value)
    }
}

@Model final class OlympiaWorkoutTemplate {
    @Attribute(.unique) var id: UUID
    var name: String
    var colorHex: String
    var exercisesData: Data
    var createdAt: Date
    var updatedAt: Date

    init(id: UUID = UUID(), name: String, colorHex: String = "#63C7FF", exercises: [OlympiaExercise]) {
        self.id = id; self.name = name; self.colorHex = colorHex
        self.exercisesData = (try? JSONEncoder().encode(exercises)) ?? Data()
        self.createdAt = .now; self.updatedAt = .now
    }

    var exercises: [OlympiaExercise] {
        get { (try? JSONDecoder().decode([OlympiaExercise].self, from: exercisesData)) ?? [] }
        set { exercisesData = (try? JSONEncoder().encode(newValue)) ?? Data(); updatedAt = .now }
    }
}

@Model final class OlympiaProgram {
    @Attribute(.unique) var id: UUID
    var name: String
    var scheduleType: String
    var rotationRestDays: Int
    var rotationAnchor: Date
    var scheduleShiftDays: Int
    var slotsData: Data
    var isActive: Bool
    var updatedAt: Date

    init(id: UUID = UUID(), name: String, scheduleType: String = "weekly", rotationRestDays: Int = 0,
         rotationAnchor: Date = .now, scheduleShiftDays: Int = 0,
         slots: [OlympiaProgramSlot], isActive: Bool = true) {
        self.id = id; self.name = name; self.scheduleType = scheduleType
        self.rotationRestDays = max(0, min(7, rotationRestDays))
        self.rotationAnchor = rotationAnchor
        self.scheduleShiftDays = scheduleShiftDays
        self.slotsData = (try? JSONEncoder().encode(slots)) ?? Data()
        self.isActive = isActive; self.updatedAt = .now
    }

    var slots: [OlympiaProgramSlot] {
        get { (try? JSONDecoder().decode([OlympiaProgramSlot].self, from: slotsData)) ?? [] }
        set { slotsData = (try? JSONEncoder().encode(newValue)) ?? Data(); updatedAt = .now }
    }
}

@Model final class OlympiaTrainingSession {
    @Attribute(.unique) var id: UUID
    var workoutID: UUID?
    var name: String
    var heartRateSessionID: UUID?
    var averageHeartRate: Double?
    var startedAt: Date
    var endedAt: Date?
    var status: String // preparing, working, resting, paused, completed, partial, imported
    var plannedExercisesData: Data
    var completedSetsData: Data
    var exerciseIndex: Int
    var setNumber: Int
    var phaseDeadline: Date?
    var pausedRemaining: TimeInterval
    var pausedAt: Date?
    var pausedPhase: String?
    var totalPausedSeconds: TimeInterval

    init(id: UUID = UUID(), workoutID: UUID? = nil, name: String, startedAt: Date = .now,
         plannedExercises: [OlympiaExercise] = [],
         status: String = "preparing", sets: [OlympiaCompletedSet] = []) {
        self.id = id; self.workoutID = workoutID; self.name = name
        self.heartRateSessionID = nil; self.averageHeartRate = nil; self.startedAt = startedAt
        self.plannedExercisesData = (try? JSONEncoder().encode(plannedExercises)) ?? Data()
        self.status = status; self.completedSetsData = (try? JSONEncoder().encode(sets)) ?? Data()
        self.exerciseIndex = 0; self.setNumber = 1
        self.phaseDeadline = nil; self.pausedRemaining = 0; self.pausedAt = nil; self.pausedPhase = nil
        self.totalPausedSeconds = 0
    }

    var completedSets: [OlympiaCompletedSet] {
        get { (try? JSONDecoder().decode([OlympiaCompletedSet].self, from: completedSetsData)) ?? [] }
        set { completedSetsData = (try? JSONEncoder().encode(newValue)) ?? Data() }
    }

    var plannedExercises: [OlympiaExercise] {
        (try? JSONDecoder().decode([OlympiaExercise].self, from: plannedExercisesData)) ?? []
    }

    var duration: TimeInterval {
        (endedAt ?? pausedAt ?? .now).timeIntervalSince(startedAt) - totalPausedSeconds
    }
}

@Model final class OlympiaBodyWeight {
    @Attribute(.unique) var id: UUID
    var measuredAt: Date
    var pounds: Double

    init(id: UUID = UUID(), measuredAt: Date = .now, pounds: Double) {
        self.id = id; self.measuredAt = measuredAt; self.pounds = pounds
    }
}

private enum OlympiaBackupApplyError: LocalizedError {
    case duplicateID(String)

    var errorDescription: String? {
        switch self {
        case .duplicateID(let collection):
            return "The backup contains duplicate IDs in \(collection)."
        }
    }
}

@MainActor
final class OlympiaTrainingStore: ObservableObject {
    let container: ModelContainer
    private let context: ModelContext
    @Published private(set) var workouts: [OlympiaWorkoutTemplate] = []
    @Published private(set) var programs: [OlympiaProgram] = []
    @Published private(set) var sessions: [OlympiaTrainingSession] = []
    @Published private(set) var weights: [OlympiaBodyWeight] = []
    @Published var errorMessage: String?

    init(inMemory: Bool = false) throws {
        container = try ModelContainer(for: OlympiaWorkoutTemplate.self, OlympiaProgram.self,
                                       OlympiaTrainingSession.self, OlympiaBodyWeight.self,
                                       configurations: ModelConfiguration(isStoredInMemoryOnly: inMemory))
        context = container.mainContext
        refresh()
    }

    func refresh() {
        do {
            workouts = try context.fetch(FetchDescriptor<OlympiaWorkoutTemplate>())
                .sorted { $0.createdAt < $1.createdAt }
            programs = try context.fetch(FetchDescriptor<OlympiaProgram>())
                .sorted { $0.updatedAt > $1.updatedAt }
            sessions = try context.fetch(FetchDescriptor<OlympiaTrainingSession>())
                .sorted { $0.startedAt > $1.startedAt }
            weights = try context.fetch(FetchDescriptor<OlympiaBodyWeight>())
                .sorted { $0.measuredAt < $1.measuredAt }
            errorMessage = nil
        } catch { errorMessage = error.localizedDescription }
    }

    private func save() {
        do { try context.save(); refresh() }
        catch { errorMessage = error.localizedDescription }
    }

    func upsertWorkout(id: UUID? = nil, name: String, colorHex: String, exercises: [OlympiaExercise]) {
        let clean = exercises.filter { !$0.name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }
        guard !name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty, !clean.isEmpty else { return }
        if let existing = workouts.first(where: { $0.id == id }) {
            existing.name = name.trimmingCharacters(in: .whitespacesAndNewlines)
            existing.colorHex = colorHex; existing.exercises = clean
        } else { context.insert(OlympiaWorkoutTemplate(name: name, colorHex: colorHex, exercises: clean)) }
        save()
    }

    func deleteWorkout(_ workout: OlympiaWorkoutTemplate) {
        for program in programs {
            program.slots = program.slots.filter { $0.workoutID != workout.id }
        }
        context.delete(workout)
        save() // Historical sessions retain their exercise and set details.
    }

    func upsertProgram(id: UUID? = nil, name: String, scheduleType: String,
                       rotationRestDays: Int, rotationStartDate: Date = .now,
                       slots: [OlympiaProgramSlot]) {
        guard !slots.isEmpty else { return }
        for program in programs { program.isActive = false }
        if let existing = programs.first(where: { $0.id == id }) {
            existing.name = name; existing.scheduleType = scheduleType
            existing.rotationRestDays = max(0, min(7, rotationRestDays))
            existing.rotationAnchor = rotationStartDate
            existing.slots = slots; existing.isActive = true; existing.updatedAt = .now
        } else {
            context.insert(OlympiaProgram(name: name, scheduleType: scheduleType,
                                          rotationRestDays: rotationRestDays,
                                          rotationAnchor: rotationStartDate, slots: slots))
        }
        save()
    }

    var activeProgram: OlympiaProgram? { programs.first(where: { $0.isActive }) }

    func scheduledWorkouts(on date: Date, calendar: Calendar = .current) -> [OlympiaWorkoutTemplate] {
        guard let program = activeProgram else { return [] }
        let slots = program.slots
        guard !slots.isEmpty else { return [] }
        let selected: [OlympiaProgramSlot]
        if program.scheduleType == "rotation" {
            let days = calendar.dateComponents([.day], from: calendar.startOfDay(for: program.rotationAnchor),
                                               to: calendar.startOfDay(for: date)).day ?? 0
            guard days >= 0 else { return [] }
            let cycle = slots.count + max(0, min(7, program.rotationRestDays))
            let index = days % cycle
            selected = index < slots.count ? [slots[index]] : []
        } else {
            let shiftedDate = calendar.date(byAdding: .day, value: -program.scheduleShiftDays, to: date) ?? date
            let weekday = calendar.component(.weekday, from: shiftedDate)
            selected = slots.filter { $0.weekdays.contains(weekday) }
        }
        return selected.compactMap { slot in workouts.first(where: { $0.id == slot.workoutID }) }
    }

    func postponeRotationOneDay() {
        guard let program = activeProgram else { return }
        if program.scheduleType == "rotation" {
            program.rotationAnchor = Calendar.current.date(byAdding: .day, value: 1, to: program.rotationAnchor) ?? program.rotationAnchor
        } else {
            program.scheduleShiftDays += 1
        }
        program.updatedAt = .now
        save()
    }

    @discardableResult
    func createSession(for workout: OlympiaWorkoutTemplate) -> OlympiaTrainingSession {
        let session = OlympiaTrainingSession(workoutID: workout.id, name: workout.name,
                                             plannedExercises: workout.exercises)
        context.insert(session); save(); return session
    }

    func persistSession(_ session: OlympiaTrainingSession) { save() }

    func deleteSession(_ session: OlympiaTrainingSession) { context.delete(session); save() }

    func deleteExercise(_ name: String, from session: OlympiaTrainingSession) {
        session.completedSets = session.completedSets.filter { $0.exerciseName != name }
        save()
    }

    func logWeight(_ value: Double, kilograms: Bool, at date: Date = .now) {
        let pounds = kilograms ? value * 2.2046226218 : value
        guard pounds >= 50, pounds <= 500 else { errorMessage = "Enter a weight between 50 and 500 lb."; return }
        context.insert(OlympiaBodyWeight(measuredAt: date, pounds: pounds))
        save()
    }

    func deleteWeight(_ entry: OlympiaBodyWeight) { context.delete(entry); save() }

    func previousSet(exercise: String, setNumber: Int) -> OlympiaCompletedSet? {
        let key = olympiaExerciseKey(exercise)
        return sessions.flatMap { $0.completedSets }
            .filter { olympiaExerciseKey($0.exerciseName) == key && $0.setNumber == setNumber }
            .sorted { $0.completedAt > $1.completedAt }.first
    }

    func historyExercises() -> [String] {
        var byKey: [String: String] = [:]
        for name in sessions.flatMap({ $0.completedSets.map(\.exerciseName) }) +
                    workouts.flatMap({ $0.exercises.map(\.name) }) {
            let key = olympiaExerciseKey(name)
            if byKey[key] == nil { byKey[key] = name }
        }
        return byKey.values.sorted()
    }

    func historyWorkoutSuggestions() -> [OlympiaWorkoutSuggestion] {
        var seenRoutines = Set<String>()
        return sessions.compactMap { session in
            let sets = session.completedSets
            guard !sets.isEmpty else { return nil }
            let nameKey = session.name.trimmingCharacters(in: .whitespacesAndNewlines)
                .folding(options: [.diacriticInsensitive, .caseInsensitive], locale: .current)
            guard !nameKey.isEmpty else { return nil }

            var orderedKeys: [String] = []
            var grouped: [String: [OlympiaCompletedSet]] = [:]
            for set in sets.sorted(by: { $0.exercisePosition < $1.exercisePosition }) {
                let nameKey = olympiaExerciseKey(set.exerciseName)
                guard !nameKey.isEmpty else { continue }
                let key = "\(set.exercisePosition):\(nameKey)"
                if grouped[key] == nil { orderedKeys.append(key) }
                grouped[key, default: []].append(set)
            }
            let exercises = orderedKeys.compactMap { key -> OlympiaExercise? in
                guard let recorded = grouped[key], let first = recorded.first else { return nil }
                return OlympiaExercise(name: first.exerciseName,
                                       sets: max(1, min(12, Set(recorded.map(\.setNumber)).count)),
                                       restSeconds: first.restSeconds > 0 ? first.restSeconds : 90,
                                       targetWeightPounds: recorded.compactMap(\.weightPounds).last)
            }
            guard !exercises.isEmpty else { return nil }
            let signature = nameKey + "|" + exercises.map { olympiaExerciseKey($0.name) }.joined(separator: "|")
            guard seenRoutines.insert(signature).inserted else { return nil }
            return OlympiaWorkoutSuggestion(id: session.id, name: session.name,
                                            exercises: exercises, lastPerformedAt: session.startedAt)
        }
    }

    func addImportedSession(name: String, date: Date, sets: [OlympiaCompletedSet]) {
        guard !sets.isEmpty else { return }
        if let existing = sessions.first(where: {
            $0.status == "imported" && $0.name == name &&
            Calendar.current.isDate($0.startedAt, inSameDayAs: date)
        }) {
            existing.completedSets = sets
        } else {
            let session = OlympiaTrainingSession(name: name, startedAt: date, status: "imported", sets: sets)
            session.endedAt = date
            context.insert(session)
        }
        save()
    }

    func importedWeightExists(on date: Date) -> Bool {
        weights.contains { Calendar.current.isDate($0.measuredAt, inSameDayAs: date) }
    }

    /// Replaces the local snapshot with a backup as one SwiftData transaction.
    /// The caller can surface a failure without leaving a partially applied backup.
    func applyBackup(_ backup: OlympiaBackup) throws {
        let wasAutosaveEnabled = context.autosaveEnabled
        context.autosaveEnabled = false
        defer { context.autosaveEnabled = wasAutosaveEnabled }
        do {
            func requireUniqueIDs<Item>(_ items: [Item], in collection: String,
                                        id: (Item) -> UUID) throws {
                guard Set(items.map(id)).count == items.count else {
                    throw OlympiaBackupApplyError.duplicateID(collection)
                }
            }
            try requireUniqueIDs(backup.workouts, in: "workouts", id: { $0.id })
            try requireUniqueIDs(backup.programs, in: "programs", id: { $0.id })
            try requireUniqueIDs(backup.sessions, in: "sessions", id: { $0.id })
            try requireUniqueIDs(backup.weights, in: "weights", id: { $0.id })

            let encoder = JSONEncoder()
            let encodedWorkouts = try backup.workouts.map { ($0, try encoder.encode($0.exercises)) }
            let encodedPrograms = try backup.programs.map { ($0, try encoder.encode($0.slots)) }
            let encodedSessions = try backup.sessions.map {
                ($0, try encoder.encode($0.plannedExercises), try encoder.encode($0.sets))
            }

            let localWorkouts = try context.fetch(FetchDescriptor<OlympiaWorkoutTemplate>())
            let localPrograms = try context.fetch(FetchDescriptor<OlympiaProgram>())
            let localSessions = try context.fetch(FetchDescriptor<OlympiaTrainingSession>())
            let localWeights = try context.fetch(FetchDescriptor<OlympiaBodyWeight>())

            let workoutIDs = Set(backup.workouts.map(\.id))
            let programIDs = Set(backup.programs.map(\.id))
            let sessionIDs = Set(backup.sessions.map(\.id))
            let weightIDs = Set(backup.weights.map(\.id))

            for item in localWorkouts where !workoutIDs.contains(item.id) { context.delete(item) }
            for item in localPrograms where !programIDs.contains(item.id) { context.delete(item) }
            for item in localSessions where !sessionIDs.contains(item.id) { context.delete(item) }
            for item in localWeights where !weightIDs.contains(item.id) { context.delete(item) }

            let workoutsByID = Dictionary(localWorkouts.map { ($0.id, $0) }, uniquingKeysWith: { first, _ in first })
            for (item, exercisesData) in encodedWorkouts {
                if let existing = workoutsByID[item.id] {
                    existing.name = item.name
                    existing.colorHex = item.colorHex
                    existing.exercisesData = exercisesData
                    existing.updatedAt = .now
                } else {
                    let workout = OlympiaWorkoutTemplate(id: item.id, name: item.name,
                                                         colorHex: item.colorHex, exercises: item.exercises)
                    workout.exercisesData = exercisesData
                    context.insert(workout)
                }
            }

            let programsByID = Dictionary(localPrograms.map { ($0.id, $0) }, uniquingKeysWith: { first, _ in first })
            for (item, slotsData) in encodedPrograms {
                if let existing = programsByID[item.id] {
                    existing.name = item.name
                    existing.scheduleType = item.scheduleType
                    existing.rotationRestDays = item.rotationRestDays
                    existing.rotationAnchor = item.rotationAnchor
                    existing.scheduleShiftDays = item.scheduleShiftDays
                    existing.slotsData = slotsData
                    existing.isActive = item.isActive
                    existing.updatedAt = .now
                } else {
                    let program = OlympiaProgram(id: item.id, name: item.name,
                                                 scheduleType: item.scheduleType,
                                                 rotationRestDays: item.rotationRestDays,
                                                 rotationAnchor: item.rotationAnchor,
                                                 scheduleShiftDays: item.scheduleShiftDays,
                                                 slots: item.slots, isActive: item.isActive)
                    program.slotsData = slotsData
                    context.insert(program)
                }
            }

            let sessionsByID = Dictionary(localSessions.map { ($0.id, $0) }, uniquingKeysWith: { first, _ in first })
            for (item, plannedExercisesData, completedSetsData) in encodedSessions {
                let session: OlympiaTrainingSession
                if let existing = sessionsByID[item.id] {
                    session = existing
                } else {
                    session = OlympiaTrainingSession(id: item.id, workoutID: item.workoutID,
                                                     name: item.name, startedAt: item.startedAt,
                                                     plannedExercises: item.plannedExercises,
                                                     status: item.status, sets: item.sets)
                    context.insert(session)
                }
                session.workoutID = item.workoutID
                session.name = item.name
                session.heartRateSessionID = item.heartRateSessionID
                session.averageHeartRate = item.averageHeartRate
                session.startedAt = item.startedAt
                session.endedAt = item.endedAt
                session.status = item.status
                session.plannedExercisesData = plannedExercisesData
                session.completedSetsData = completedSetsData
                session.exerciseIndex = item.exerciseIndex
                session.setNumber = item.setNumber
                session.phaseDeadline = item.phaseDeadline
                session.pausedRemaining = item.pausedRemaining
                session.pausedAt = item.pausedAt
                session.pausedPhase = item.pausedPhase
                session.totalPausedSeconds = item.totalPausedSeconds
            }

            let weightsByID = Dictionary(localWeights.map { ($0.id, $0) }, uniquingKeysWith: { first, _ in first })
            for item in backup.weights {
                if let existing = weightsByID[item.id] {
                    existing.measuredAt = item.measuredAt
                    existing.pounds = item.pounds
                } else {
                    context.insert(OlympiaBodyWeight(id: item.id, measuredAt: item.measuredAt,
                                                     pounds: item.pounds))
                }
            }

            try context.save()
            refresh()
        } catch {
            context.rollback()
            refresh()
            throw error
        }
    }
}
