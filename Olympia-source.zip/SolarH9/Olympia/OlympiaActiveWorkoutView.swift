import SwiftUI
import UIKit

struct OlympiaActiveWorkoutView: View {
    private enum EntryField: Hashable { case weight, reps }
    private enum HapticCue { case light, success }
    @ObservedObject var store: OlympiaTrainingStore
    @ObservedObject var engine: OlympiaWorkoutEngine
    @EnvironmentObject private var sensor: SensorCoordinator
    @EnvironmentObject private var productStore: ProductStore
    @Environment(\.olympiaColors) private var colors
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @FocusState private var entryFocused: EntryField?
    @AppStorage("olympia.units") private var units = "lb"
    @AppStorage("olympia.hapticsEnabled") private var hapticsEnabled = true
    @State private var weight = ""
    @State private var reps = ""
    @State private var showEnd = false
    @State private var sensorSessionStarted = false
    @State private var sensorStartTask: Task<Void, Never>?
    @State private var lastSensorStartAttempt: Date?
    @State private var isEnding = false
    @State private var lastCountdownCue: Int?
    @State private var restBaselineSeconds = 90

    var body: some View {
        GeometryReader { geometry in
            ScrollView {
                VStack(spacing: 20) {
                    header
                    if engine.phase == "preparing" { preparation }
                    else if engine.phase == "resting" { rest }
                    else if engine.phase == "paused" { paused }
                    else { working }
                }
                .frame(maxWidth: 600)
                .frame(maxWidth: .infinity)
                .frame(minHeight: max(0, geometry.size.height - 40), alignment: .top)
                .padding(20)
            }
            .scrollIndicators(.hidden).scrollDismissesKeyboard(.interactively)
            .background(colors.background.ignoresSafeArea())
        }
        .safeAreaInset(edge: .bottom, spacing: 0) { actionFooter }
        .foregroundStyle(colors.text)
        .animation(reduceMotion ? nil : .easeInOut(duration: 0.2), value: engine.phase)
        .toolbar {
            ToolbarItemGroup(placement: .keyboard) {
                Spacer()
                Button("Done") { entryFocused = nil }
            }
        }
        .onChange(of: engine.phase) { previousPhase, phase in
            if phase != "working" { entryFocused = nil }
            if phase == "working" { beginSensorSessionIfReady() }
            // Resuming the same set must not replace unsaved field edits.
            if phase == "working", previousPhase != "paused" { prefill() }
            if phase == "resting" {
                if previousPhase != "paused" { restBaselineSeconds = max(1, engine.secondsRemaining) }
                haptic(.success)
            }
            else if previousPhase == "resting", phase == "working" { haptic(.success) }
            lastCountdownCue = nil
        }
        .onChange(of: engine.secondsRemaining) { _, seconds in
            guard engine.phase == "resting", (1...3).contains(seconds),
                  lastCountdownCue != seconds else { return }
            lastCountdownCue = seconds
            haptic(.light)
        }
        .onChange(of: sensor.currentHeartRate) { _, _ in beginSensorSessionIfReady() }
        .onAppear {
            beginSensorSessionIfReady()
            prefill()
            if engine.phase == "resting" {
                restBaselineSeconds = max(1, max(engine.session?.completedSets.last?.restSeconds ?? 0,
                                                 engine.secondsRemaining))
            }
        }
        .disabled(isEnding)
        .confirmationDialog("End workout?", isPresented: $showEnd) {
            Button("Finish and save", role: .destructive) { endWorkout(cancel: false) }
            Button("Discard workout", role: .destructive) { endWorkout(cancel: true) }
        } message: { Text("Completed sets are saved if you finish.") }
    }

    private var header: some View {
        HStack(spacing: 12) {
            Button("End") { haptic(.light); showEnd = true }
                .font(.subheadline.bold())
                .frame(minWidth: 56, minHeight: 44)
                .background(colors.secondarySurface, in: Capsule())
            Spacer(minLength: 0)
            Text(engine.session?.name ?? "Workout")
                .font(.subheadline.weight(.semibold))
                .lineLimit(1).minimumScaleFactor(0.75)
                .accessibilityAddTraits(.isHeader)
            Spacer(minLength: 0)
            Button {
                haptic(.light)
                if engine.phase == "paused" { engine.resume(); pauseOrResumeHeartRate() }
                else if engine.phase == "working" || engine.phase == "resting" {
                    engine.pause(); pauseOrResumeHeartRate()
                }
            } label: {
                Image(systemName: engine.phase == "paused" ? "play.fill" : "pause.fill")
                    .font(.subheadline.bold()).frame(width: 44, height: 44)
                    .background(colors.secondarySurface, in: Circle())
            }
            .accessibilityLabel(engine.phase == "paused" ? "Resume workout" : "Pause workout")
            .disabled(engine.phase == "preparing")
        }
        .buttonStyle(OlympiaPressStyle())
        .foregroundStyle(colors.text)
    }

    private var preparation: some View {
        VStack(spacing: 20) {
            countdown(seconds: engine.secondsRemaining, total: 120)
            Text("Set up before the clock starts").font(.title3.bold())
            Text("Your workout timer begins when prep ends. Previous-session weights are below.")
                .font(.subheadline).foregroundStyle(colors.muted).multilineTextAlignment(.center)
            ForEach(engine.exercises.indices, id: \.self) { index in
                let exercise = engine.exercises[index]
                OlympiaCard {
                    HStack {
                        Text("\(index + 1)").foregroundStyle(colors.accent)
                        Text(exercise.name).lineLimit(2)
                        Spacer()
                        if let set = store.previousSet(exercise: exercise.name, setNumber: 1),
                           let pounds = set.weightPounds {
                            Text(String(format: "%.0f %@", units == "kg" ? pounds / 2.2046226218 : pounds, units))
                                .font(.caption.bold()).foregroundStyle(colors.accent)
                        }
                    }
                }
            }
        }
    }

    private var working: some View {
        VStack(spacing: 22) {
            elapsedClock
            heartRateStrip
            exerciseProgress
            VStack(alignment: .leading, spacing: 17) {
                Text(engine.currentExercise?.name ?? "Workout complete")
                    .font(.system(size: 31, weight: .bold, design: .rounded))
                    .minimumScaleFactor(0.7).lineLimit(2)
                    .frame(maxWidth: .infinity, alignment: .leading)
                Rectangle().fill(colors.border).frame(height: 1)
                Text("SET \(engine.session?.setNumber ?? 1) OF \(engine.currentExercise?.sets ?? 1)")
                    .font(.caption.weight(.semibold)).tracking(1.6)
                previousSetRow
                Rectangle().fill(colors.border).frame(height: 1)
                HStack(spacing: 0) {
                    setEntry(title: "REPS", value: $reps, field: .reps, step: 1, keyboard: .numberPad)
                    Rectangle().fill(colors.border).frame(width: 1).padding(.vertical, 8)
                    setEntry(title: units.uppercased(), value: $weight, field: .weight,
                             step: units == "kg" ? 1 : 2.5, keyboard: .decimalPad)
                }
                .padding(.top, 4)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
        }
    }

    private var rest: some View {
        VStack(spacing: 22) {
            Text("RECOVERY")
                .font(.caption.weight(.bold)).tracking(3).foregroundStyle(colors.muted)
                .padding(.top, 12)
            animatedRestCountdown
            heartRateStrip
            exerciseProgress
            VStack(spacing: 7) {
                Text("UP NEXT").font(.caption2.weight(.semibold)).tracking(1.8).foregroundStyle(colors.muted)
                Text(engine.currentExercise?.name ?? "Exercise")
                    .font(.title2.bold()).multilineTextAlignment(.center)
                Text("Set \(engine.session?.setNumber ?? 1) of \(engine.currentExercise?.sets ?? 1)")
                    .font(.subheadline).foregroundStyle(colors.muted)
            }
            .frame(maxWidth: .infinity)
            HStack(spacing: 16) {
                restAdjustment("−15 sec", seconds: -15)
                restAdjustment("+15 sec", seconds: 15)
            }
        }
    }

    private var elapsedClock: some View {
        Text(String(format: "%02d:%02d", engine.elapsedSeconds / 60, engine.elapsedSeconds % 60))
            .font(.system(size: 72, weight: .bold, design: .rounded))
            .monospacedDigit().minimumScaleFactor(0.65).lineLimit(1)
            .frame(maxWidth: .infinity)
            .accessibilityLabel("Total workout time")
            .accessibilityValue("\(engine.elapsedSeconds / 60) minutes, \(engine.elapsedSeconds % 60) seconds")
    }

    @ViewBuilder private var heartRateStrip: some View {
        if let bpm = sensor.currentHeartRate, sensor.selectedSource != .simulator {
            let zone = sensor.currentZone(for: bpm)
            HStack(spacing: 6) {
                Image(systemName: "heart.fill")
                    .foregroundStyle(Color.red)
                    .font(.title3)
                    .accessibilityHidden(true)
                Text("\(bpm)").font(.title3.bold()).monospacedDigit()
                Text("BPM").font(.caption.weight(.semibold))
                Rectangle().fill(colors.border).frame(width: 1, height: 24)
                Text(zone.map { "Zone \($0)" } ?? "HR")
                    .font(.subheadline).foregroundStyle(colors.muted)
                Spacer(minLength: 0)
                HStack(spacing: 4) {
                    ForEach(1...5, id: \.self) { index in
                        Capsule().fill(zoneColor(index).opacity(zone == nil || index == zone ? 1 : 0.5))
                            .frame(width: 12, height: 9)
                    }
                }
                .accessibilityHidden(true)
            }
            .padding(.horizontal, 13).padding(.vertical, 12)
            .background(colors.surface, in: RoundedRectangle(cornerRadius: 18))
            .overlay(RoundedRectangle(cornerRadius: 18).stroke(colors.border, lineWidth: 0.75))
            .accessibilityElement(children: .ignore)
            .accessibilityLabel("Heart rate \(bpm) beats per minute\(zone.map { ", zone \($0)" } ?? "")")
        }
    }

    private func zoneColor(_ zone: Int) -> Color {
        switch zone {
        case 1: return Color(olympiaHex: "#3974DB")
        case 2: return Color(olympiaHex: "#46DD94")
        case 3: return Color(olympiaHex: "#EBD766")
        case 4: return Color(olympiaHex: "#F39A51")
        default: return Color(olympiaHex: "#F35461")
        }
    }

    private var exerciseProgress: some View {
        VStack(spacing: 10) {
            HStack(spacing: 6) {
                ForEach(engine.exercises.indices, id: \.self) { index in
                    Capsule()
                        .fill(index <= (engine.session?.exerciseIndex ?? 0) ? colors.accent : colors.secondarySurface)
                        .frame(height: 8)
                }
            }
            Text("Exercise \((engine.session?.exerciseIndex ?? 0) + 1) of \(engine.exercises.count)")
                .font(.subheadline).foregroundStyle(colors.muted)
        }
        .accessibilityElement(children: .ignore)
        .accessibilityLabel("Exercise \((engine.session?.exerciseIndex ?? 0) + 1) of \(engine.exercises.count)")
    }

    @ViewBuilder private var previousSetRow: some View {
        if let exercise = engine.currentExercise,
           let previous = store.previousSet(exercise: exercise.name,
                                            setNumber: engine.session?.setNumber ?? 1) {
            HStack {
                Text("PREVIOUS")
                    .font(.caption.weight(.medium)).tracking(1.1).foregroundStyle(colors.muted)
                Spacer()
                Text("\(previous.weightPounds.map { String(format: "%.0f", units == "kg" ? $0 / 2.2046226218 : $0) } ?? "BW") \(units) × \(previous.displayReps) reps")
                    .font(.subheadline).foregroundStyle(colors.muted)
            }
        }
    }

    private func setEntry(title: String, value: Binding<String>, field: EntryField,
                          step: Double, keyboard: UIKeyboardType) -> some View {
        VStack(spacing: 7) {
            TextField("—", text: value)
                .keyboardType(keyboard)
                .focused($entryFocused, equals: field)
                .multilineTextAlignment(.center)
                .font(.system(size: 62, weight: .bold, design: .rounded))
                .minimumScaleFactor(0.7)
                .accessibilityLabel(field == .reps ? "Completed repetitions" : "Completed weight in \(units)")
            Text(title).font(.subheadline.weight(.semibold)).tracking(1.4)
            HStack(spacing: 14) {
                stepButton("minus", field: field, value: value, amount: -step)
                Rectangle().fill(colors.border).frame(width: 1, height: 22)
                stepButton("plus", field: field, value: value, amount: step)
            }
            .padding(.top, 8)
        }
        .frame(maxWidth: .infinity)
    }

    private func stepButton(_ symbol: String, field: EntryField,
                            value: Binding<String>, amount: Double) -> some View {
        Button {
            let current = Double(value.wrappedValue) ?? 0
            let updated = max(0, current + amount)
            value.wrappedValue = field == .reps ? String(Int(updated)) : String(format: updated.rounded() == updated ? "%.0f" : "%.1f", updated)
            haptic(.light)
        } label: {
            Image(systemName: symbol)
                .font(.title3.weight(.medium))
                .frame(width: 44, height: 44)
                .background(colors.secondarySurface, in: Circle())
        }
        .buttonStyle(OlympiaPressStyle())
        .accessibilityLabel("\(symbol == "plus" ? "Increase" : "Decrease") \(field == .reps ? "repetitions" : "weight")")
    }

    private func restAdjustment(_ title: String, seconds: Int) -> some View {
        Button(title) {
            let before = engine.secondsRemaining
            engine.adjustRest(by: seconds)
            restBaselineSeconds = max(1, max(engine.secondsRemaining,
                                             restBaselineSeconds + engine.secondsRemaining - before))
            haptic(.light)
        }
            .font(.subheadline.bold())
            .frame(maxWidth: .infinity, minHeight: 48)
            .background(colors.secondarySurface, in: Capsule())
            .buttonStyle(OlympiaPressStyle())
    }

    private var animatedRestCountdown: some View {
        TimelineView(.animation(minimumInterval: 1.0 / 30.0, paused: reduceMotion)) { context in
            let remaining = reduceMotion ? Double(engine.secondsRemaining) :
                max(0, engine.session?.phaseDeadline?.timeIntervalSince(context.date) ?? Double(engine.secondsRemaining))
            let progress = min(1, remaining / Double(max(1, restBaselineSeconds)))
            let breathe = reduceMotion ? 0.0 : (sin(context.date.timeIntervalSinceReferenceDate * 3.1) + 1) / 2
            ZStack {
                Circle().fill(colors.accent.opacity(0.05 + breathe * 0.07))
                    .padding(24)
                Circle().stroke(colors.border, lineWidth: 8)
                Circle()
                    .trim(from: 0, to: progress)
                    .stroke(AngularGradient(colors: [colors.accent.opacity(0.55), colors.accent, .white], center: .center),
                            style: StrokeStyle(lineWidth: 9, lineCap: .round))
                    .rotationEffect(.degrees(-90))
                    .shadow(color: colors.accent.opacity(0.35 + breathe * 0.25), radius: 12)
                if !reduceMotion {
                    Circle().fill(.white).frame(width: 13, height: 13)
                        .shadow(color: colors.accent, radius: 8)
                        .offset(y: -119).rotationEffect(.degrees(progress * 360))
                }
                VStack(spacing: 4) {
                    Text(String(format: "%d:%02d", engine.secondsRemaining / 60, engine.secondsRemaining % 60))
                        .font(.system(size: 61, weight: .bold, design: .rounded))
                        .monospacedDigit()
                    Text("REST TIMER")
                        .font(.caption2.weight(.semibold)).tracking(2).foregroundStyle(colors.muted)
                }
            }
            .frame(width: 242, height: 242)
            .accessibilityElement(children: .ignore)
            .accessibilityLabel("Rest timer")
            .accessibilityValue("\(engine.secondsRemaining) seconds remaining")
        }
    }

    private func haptic(_ cue: HapticCue) {
        guard hapticsEnabled else { return }
        switch cue {
        case .light: UIImpactFeedbackGenerator(style: .light).impactOccurred()
        case .success: UINotificationFeedbackGenerator().notificationOccurred(.success)
        }
    }

    private var paused: some View {
        VStack(spacing: 20) {
            Image(systemName: "pause.circle.fill").font(.system(size: 90)).foregroundStyle(colors.accent)
            Text("Workout paused").font(.title.bold())
            Text("Your workout and rest clocks are paused.").foregroundStyle(colors.muted)
        }.frame(maxWidth: .infinity).padding(.top, 45)
    }

    private func countdown(seconds: Int, total: Int) -> some View {
        ZStack {
            Circle().stroke(colors.border, lineWidth: 6)
            Circle().trim(from: 0, to: CGFloat(min(1, Double(seconds) / Double(max(1, total)))))
                .stroke(colors.accent, style: StrokeStyle(lineWidth: 6, lineCap: .round))
                .rotationEffect(.degrees(-90))
                .animation(reduceMotion ? nil : .easeOut(duration: 0.2), value: seconds)
            VStack(spacing: 0) {
                Text(String(format: "%d:%02d", seconds / 60, seconds % 60))
                    .font(.system(size: 44, weight: .bold, design: .rounded)).monospacedDigit()
                Text(engine.phase == "preparing" ? "GET READY" : "REST TIMER")
                    .font(.caption2).tracking(1.5).foregroundStyle(colors.muted)
            }
        }.frame(width: 170, height: 170).padding(.top, 20)
    }

    private var actionFooter: some View {
        Button {
            entryFocused = nil
            switch engine.phase {
            case "preparing": engine.beginNow(); haptic(.light)
            case "resting": engine.skipRest()
            case "paused": engine.resume(); pauseOrResumeHeartRate(); haptic(.light)
            default:
                let draft = engine.session
                let enteredWeight = Double(weight).map { units == "kg" ? $0 * 2.2046226218 : $0 }
                engine.completeSet(weightPounds: enteredWeight, reps: Int(reps))
                if !engine.isActive { haptic(.success) }
                prefill()
                if !engine.isActive { Task {
                    await sensorStartTask?.value
                    await finishHeartRate(for: draft, cancel: false)
                } }
            }
        } label: {
            HStack {
                Spacer()
                Text(engine.phase == "preparing" ? "Start now" :
                        engine.phase == "resting" ? "Skip rest" :
                        engine.phase == "paused" ? "Resume workout" : "Complete set \(engine.session?.setNumber ?? 1)")
                    .font(.headline)
                Spacer()
                Image(systemName: "arrow.right").font(.headline)
            }
            .foregroundStyle(.black)
            .padding(.horizontal, 24)
            .frame(maxWidth: .infinity, minHeight: 64)
            .background(colors.accent, in: RoundedRectangle(cornerRadius: 20))
        }.buttonStyle(OlympiaPressStyle())
            .disabled(engine.phase == "working" && Double(weight) == nil && Int(reps) == nil)
            .opacity(engine.phase == "working" && Double(weight) == nil && Int(reps) == nil ? 0.4 : 1)
            .frame(maxWidth: 600).frame(maxWidth: .infinity)
            .padding(.horizontal, 20).padding(.vertical, 12).background(colors.background)
    }

    private func prefill() {
        guard let exercise = engine.currentExercise else { return }
        let previous = store.previousSet(exercise: exercise.name, setNumber: engine.session?.setNumber ?? 1)
        // Logged weight is the best guide; the template target fills gaps in history.
        let suggestedPounds = previous?.weightPounds ?? exercise.targetWeightPounds
        weight = suggestedPounds.map { String(format: "%.1f", units == "kg" ? $0 / 2.2046226218 : $0) } ?? ""
        reps = previous?.reps.map(String.init) ?? ""
    }

    private func endWorkout(cancel: Bool) {
        guard !isEnding else { return }
        isEnding = true
        let draft = engine.session
        Task {
            // Starting a recording checkpoints asynchronously. Wait for its ID
            // before deleting the training draft or stopping the recording.
            await sensorStartTask?.value
            let heartRateSessionID = draft?.heartRateSessionID
            if cancel { engine.cancel() } else { engine.finish() }
            await finishHeartRate(for: cancel ? nil : draft, cancel: cancel,
                                  recordingID: heartRateSessionID)
        }
    }

    private func pauseOrResumeHeartRate() {
        guard let id = engine.session?.heartRateSessionID else { return }
        Task { await sensor.pauseOrResume(id: id) }
    }

    private func finishHeartRate(for draft: OlympiaTrainingSession?, cancel: Bool,
                                 recordingID: UUID? = nil) async {
        guard let id = recordingID ?? draft?.heartRateSessionID else { return }
        let ended = await sensor.endWorkout(id: id)
        if cancel {
            guard ended else {
                store.errorMessage = "Workout discarded. The heart-rate recording still needs to finish saving before it can be deleted."
                return
            }
            if !(await productStore.deleteSession(id: id)) {
                store.errorMessage = "Workout discarded, but its heart-rate recording could not be deleted."
            }
        } else {
            await productStore.refresh()
            attachHeartRate(to: draft)
        }
    }

    private func beginSensorSessionIfReady() {
        guard engine.phase == "working", !isEnding, !sensorSessionStarted,
              sensor.sourceIsReady, let session = engine.session else { return }
        // A restored workout already owns its saved ID. Never adopt an
        // unrelated active recording or overwrite the restored association.
        guard session.heartRateSessionID == nil, !sensor.hasActiveRecording else { return }
        let now = Date()
        // Retry only on a later workout/heart-rate event, not immediately after
        // a failed start. Frequent heart-rate updates must not spin on storage errors.
        if let lastSensorStartAttempt, now.timeIntervalSince(lastSensorStartAttempt) < 15 { return }
        lastSensorStartAttempt = now
        sensorSessionStarted = true
        sensorStartTask = Task {
            if let id = await sensor.startWorkout() {
                session.heartRateSessionID = id
                store.persistSession(session)
            } else {
                // RecordingController leaves a failed, draft-free start in
                // .failed; reset it so the next eligible event can retry.
                sensor.acknowledgeRecordingFailure()
                sensorSessionStarted = false
            }
        }
    }

    private func attachHeartRate(to session: OlympiaTrainingSession?) {
        guard let session, let id = session.heartRateSessionID,
              let measurement = productStore.allSessions.first(where: { $0.id == id }),
              let overview = ProductStore.makeOverview(measurement),
              let average = overview.averageHeartRate.value else { return }
        session.averageHeartRate = average
        store.persistSession(session)
    }
}
