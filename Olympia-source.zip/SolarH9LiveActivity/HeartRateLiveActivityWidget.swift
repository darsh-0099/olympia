import ActivityKit
import AppIntents
import SwiftUI
import WidgetKit

@main
struct SolarH9LiveActivityBundle: WidgetBundle {
    var body: some Widget {
        HeartRateLiveActivityWidget()
        OlympiaWorkoutLiveActivityWidget()
        OlympiaLaunchWidget()
        OlympiaWeekWidget()
        OlympiaActiveWidget()
    }
}

struct OlympiaLaunchWidget: Widget {
    let kind = "OlympiaLaunchWidget"
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: OlympiaLaunchProvider()) { entry in
            ZStack {
                Color(red: 0.06, green: 0.08, blue: 0.10)
                VStack(alignment: .leading, spacing: 7) {
                    Image(systemName: "figure.strengthtraining.traditional")
                        .font(.title2).foregroundStyle(Color(red: 0.39, green: 0.78, blue: 1))
                    Text("OLYMPIA").font(.caption2.bold()).tracking(2)
                    Text("Time to work").font(.headline)
                    Text("Open your workout →").font(.caption).foregroundStyle(.secondary)
                }.frame(maxWidth: .infinity, alignment: .leading).padding(16)
            }
            .foregroundStyle(.white)
            .containerBackground(for: .widget) { Color(red: 0.06, green: 0.08, blue: 0.10) }
            .widgetURL(URL(string: "olympia://home"))
        }
        .configurationDisplayName("Olympia")
        .description("Open your training plan and start a workout.")
        .supportedFamilies([.systemSmall, .systemMedium])
    }
}

private struct OlympiaLaunchEntry: TimelineEntry { let date: Date }
private struct OlympiaLaunchProvider: TimelineProvider {
    func placeholder(in context: Context) -> OlympiaLaunchEntry { OlympiaLaunchEntry(date: .now) }
    func getSnapshot(in context: Context, completion: @escaping (OlympiaLaunchEntry) -> Void) {
        completion(OlympiaLaunchEntry(date: .now))
    }
    func getTimeline(in context: Context, completion: @escaping (Timeline<OlympiaLaunchEntry>) -> Void) {
        completion(Timeline(entries: [OlympiaLaunchEntry(date: .now)], policy: .never))
    }
}

private let previewAttributes = HeartRateActivityAttributes(
    activityID: UUID(), startedAt: Date().addingTimeInterval(-425), mode: .monitoring, isSimulated: false
)
private let previewGoodState = HeartRateActivityAttributes.ContentState(
    beatsPerMinute: 132, averageBeatsPerMinute: nil, phase: .recording, updatedAt: .now,
    pulse: true, zone: 2, targetZone: nil, connectionQuality: .good
)
private let previewPoorState = HeartRateActivityAttributes.ContentState(
    beatsPerMinute: 132, averageBeatsPerMinute: nil, phase: .reconnecting, updatedAt: .now,
    pulse: false, zone: 2, targetZone: nil, connectionQuality: .poor
)
private let previewDisconnectedState = HeartRateActivityAttributes.ContentState(
    beatsPerMinute: nil, averageBeatsPerMinute: nil, phase: .reconnecting, updatedAt: .now,
    pulse: false, zone: nil, targetZone: nil, connectionQuality: .disconnected
)

#Preview("Lock Screen", as: .content, using: previewAttributes) {
    HeartRateLiveActivityWidget()
} contentStates: {
    previewGoodState
    previewPoorState
    previewDisconnectedState
}

#Preview("Dynamic Island Compact", as: .dynamicIsland(.compact), using: previewAttributes) {
    HeartRateLiveActivityWidget()
} contentStates: {
    previewGoodState
}

#Preview("Dynamic Island Expanded", as: .dynamicIsland(.expanded), using: previewAttributes) {
    HeartRateLiveActivityWidget()
} contentStates: {
    previewGoodState
    previewPoorState
}

struct HeartRateLiveActivityWidget: Widget {
    private let solarOrange = Color(red: 0.39, green: 0.78, blue: 1.0)
    private let solarCyan = Color(red: 0.275, green: 0.82, blue: 0.88)

    var body: some WidgetConfiguration {
        ActivityConfiguration(for: HeartRateActivityAttributes.self) { context in
            lockScreenView(context)
                .activityBackgroundTint(Color(red: 0.055, green: 0.059, blue: 0.071))
                .activitySystemActionForegroundColor(.white)
        } dynamicIsland: { context in
            DynamicIsland {
                DynamicIslandExpandedRegion(.leading) {
                    HStack(spacing: 7) {
                        pulseHeart(context.state)
                        Text(context.attributes.mode.title)
                            .font(.caption.weight(.semibold))
                            .lineLimit(1)
                    }
                }
                DynamicIslandExpandedRegion(.trailing) {
                    bpmView(context.state, size: 34)
                }
                DynamicIslandExpandedRegion(.bottom) {
                    VStack(spacing: 8) {
                        compactZoneStrip(context.state)
                        HStack {
                            Label(context.state.connectionQuality.label, systemImage: connectionSymbol(context.state.connectionQuality))
                                .font(.caption)
                                .foregroundStyle(context.state.connectionQuality == .good ? solarCyan : .secondary)
                            Spacer()
                            if let average = context.state.averageBeatsPerMinute {
                                Text("AVG \(average)")
                                    .font(.caption.monospacedDigit().weight(.semibold))
                                    .foregroundStyle(.secondary)
                            }
                            Text(timerInterval: context.attributes.startedAt...Date.distantFuture, countsDown: false)
                                .font(.caption.monospacedDigit())
                                .foregroundStyle(.secondary)
                        }
                        if let target = targetDescription(context.state) {
                            Text(target).font(.caption2.weight(.semibold)).foregroundStyle(.secondary)
                        }
                    }
                }
            } compactLeading: {
                pulseHeart(context.state)
            } compactTrailing: {
                HStack(spacing: 3) {
                    Text(context.state.beatsPerMinute.map(String.init) ?? "–")
                        .contentTransition(.numericText())
                    Text("bpm")
                        .font(.system(size: 9, weight: .semibold))
                        .foregroundStyle(.secondary)
                }
                .font(.caption.monospacedDigit().weight(.bold))
            } minimal: {
                pulseHeart(context.state)
            }
            .keylineTint(solarOrange)
        }
    }

    private func lockScreenView(_ context: ActivityViewContext<HeartRateActivityAttributes>) -> some View {
        VStack(spacing: 9) {
        HStack(spacing: 14) {
            ZStack {
                Circle()
                    .fill(solarOrange.opacity(0.14))
                    .frame(width: 48, height: 48)
                pulseHeart(context.state)
                    .font(.title2)
            }

            VStack(alignment: .leading, spacing: 4) {
                HStack(spacing: 6) {
                    Text(context.attributes.mode.title)
                        .font(.headline)
                    if context.attributes.isSimulated {
                        Text("DEMO")
                            .font(.system(size: 9, weight: .bold))
                            .padding(.horizontal, 5)
                            .padding(.vertical, 2)
                            .background(solarOrange.opacity(0.18), in: Capsule())
                    }
                }
                Label(phaseLabel(context.state.phase), systemImage: phaseSymbol(context.state.phase))
                    .font(.caption)
                    .foregroundStyle(context.state.phase == .recording ? solarCyan : .secondary)
            }

            Spacer(minLength: 8)

            VStack(alignment: .trailing, spacing: 3) {
                bpmView(context.state, size: 38)
                Text([context.state.zone.map { "Zone \($0)" }, context.state.connectionQuality.label]
                    .compactMap { $0 }.joined(separator: " • "))
                    .font(.caption.monospacedDigit())
                    .foregroundStyle(.secondary)
                if let target = targetDescription(context.state) {
                    Text(target).font(.caption2.weight(.semibold)).foregroundStyle(.secondary)
                }
            }
        }
        compactZoneStrip(context.state)
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 12)
    }

    private func compactZoneStrip(_ state: HeartRateActivityAttributes.ContentState) -> some View {
        HStack(spacing: 4) {
            ForEach(1...5, id: \.self) { zone in
                Capsule()
                    .fill(zoneColor(zone).opacity(state.zone == zone ? 1 : 0.22))
                    .frame(height: state.zone == zone ? 9 : 6)
                    .overlay { Capsule().stroke(state.targetZone == zone ? Color.white : .clear, lineWidth: 1.5) }
                    .shadow(color: state.zone == zone ? zoneColor(zone).opacity(0.8) : .clear, radius: 5)
            }
        }
        .accessibilityLabel(zoneAccessibility(state))
    }

    private func zoneColor(_ zone: Int) -> Color {
        switch zone {
        case 1: Color(red: 0.30, green: 0.72, blue: 0.95)
        case 2: Color(red: 0.28, green: 0.84, blue: 0.67)
        case 3: Color(red: 0.95, green: 0.82, blue: 0.31)
        case 4: solarOrange
        default: Color(red: 0.95, green: 0.28, blue: 0.48)
        }
    }

    private func connectionSymbol(_ quality: HeartRateActivityAttributes.ContentState.ConnectionQuality) -> String {
        switch quality { case .good: "antenna.radiowaves.left.and.right"; case .poor: "exclamationmark.triangle"; case .disconnected: "xmark.circle" }
    }

    private func pulseHeart(_ state: HeartRateActivityAttributes.ContentState) -> some View {
        ActivityPulseHeart(active: state.phase == .recording, pulse: state.pulse,
                           activeColor: solarOrange, appReduceMotion: state.reduceMotion)
    }

    private func targetDescription(_ state: HeartRateActivityAttributes.ContentState) -> String? {
        guard let target = state.targetZone else { return nil }
        guard let current = state.zone else { return "Target Z\(target) • relationship unavailable" }
        let relationship = current < target ? "below target" : current > target ? "above target" : "in target"
        return "Target Z\(target) • \(relationship)"
    }

    private func zoneAccessibility(_ state: HeartRateActivityAttributes.ContentState) -> String {
        var parts = [state.zone.map { "Heart-rate zone \($0)" } ?? "Heart-rate zone unavailable"]
        if let target = targetDescription(state) { parts.append(target) }
        parts.append(state.connectionQuality.label)
        return parts.joined(separator: ", ")
    }

    private func bpmView(_ state: HeartRateActivityAttributes.ContentState, size: CGFloat) -> some View {
        HStack(alignment: .firstTextBaseline, spacing: 3) {
            Text(state.beatsPerMinute.map(String.init) ?? "–")
                .font(.system(size: size, weight: .bold, design: .rounded).monospacedDigit())
                .contentTransition(.numericText())
            Text("bpm")
                .font(.caption2.weight(.semibold))
                .foregroundStyle(.secondary)
        }
        .accessibilityElement(children: .ignore)
        .accessibilityLabel(state.beatsPerMinute.map { "Heart rate, \($0) beats per minute" } ?? "Heart rate unavailable")
    }

    private func phaseLabel(_ phase: HeartRateActivityAttributes.ContentState.Phase) -> String {
        switch phase {
        case .recording: "Live"
        case .paused: "Paused"
        case .reconnecting: "Reconnecting"
        case .saving: "Saving"
        }
    }

    private func phaseSymbol(_ phase: HeartRateActivityAttributes.ContentState.Phase) -> String {
        switch phase {
        case .recording: "dot.radiowaves.left.and.right"
        case .paused: "pause.fill"
        case .reconnecting: "arrow.triangle.2.circlepath"
        case .saving: "checkmark.circle"
        }
    }
}

private struct ActivityPulseHeart: View {
    let active: Bool
    let pulse: Bool
    let activeColor: Color
    let appReduceMotion: Bool
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    var body: some View {
        if reduceMotion || appReduceMotion {
            image
        } else {
            image.symbolEffect(.pulse, value: pulse)
        }
    }

    private var image: some View {
        Image(systemName: active ? "heart.fill" : "heart")
            .foregroundStyle(active ? activeColor : .secondary)
            .accessibilityHidden(true)
    }
}

struct OlympiaWorkoutLiveActivityWidget: Widget {
    var body: some WidgetConfiguration {
        ActivityConfiguration(for: OlympiaWorkoutActivityAttributes.self) { context in
            OlympiaWorkoutActivityCard(state: context.state, sessionID: context.attributes.sessionID,
                                       stale: context.isStale)
                .activityBackgroundTint(Color(red: 0.095, green: 0.075, blue: 0.19))
                .activitySystemActionForegroundColor(.white)
                .widgetURL(URL(string: "olympia://workout"))
        } dynamicIsland: { context in
            DynamicIsland {
                DynamicIslandExpandedRegion(.leading) { OlympiaActivityLaurel(reduceMotion: context.state.reduceMotion, reverse: context.state.completedSets.isMultiple(of: 2)) }
                DynamicIslandExpandedRegion(.trailing) {
                    OlympiaActivityTimer(state: context.state).font(.title2.bold().monospacedDigit())
                        .foregroundStyle(Color(red: 0.48, green: 0.84, blue: 1))
                }
                DynamicIslandExpandedRegion(.bottom) {
                    // Expanded Island stays focused on the timer as requested.
                    HStack {
                        Text(context.state.timerLabel).font(.caption2.bold()).foregroundStyle(.secondary)
                        Spacer()
                        if !context.isStale, let bpm = context.state.currentHeartRate(at: .now) {
                            Label("\(bpm) bpm", systemImage: "heart.fill").font(.caption)
                        }
                    }
                }
            } compactLeading: {
                OlympiaActivityLaurel(reduceMotion: context.state.reduceMotion, reverse: context.state.completedSets.isMultiple(of: 2))
            } compactTrailing: {
                OlympiaActivityTimer(state: context.state)
                    .font(.caption.bold().monospacedDigit()).frame(maxWidth: 70)
            } minimal: {
                OlympiaActivityTimer(state: context.state).font(.system(size: 10, weight: .bold).monospacedDigit())
            }
            .keylineTint(Color(red: 0.76, green: 0.42, blue: 1))
            .widgetURL(URL(string: "olympia://workout"))
        }
    }
}

private struct OlympiaActivityLaurel: View {
    let reduceMotion: Bool
    let reverse: Bool
    var body: some View {
        Image("OlympiaMark").resizable().scaledToFit()
            .overlay {
                if !reduceMotion {
                    LinearGradient(colors: [.cyan.opacity(0.7), .purple.opacity(0.7), .pink.opacity(0.5)],
                                   startPoint: reverse ? .bottomTrailing : .topLeading,
                                   endPoint: reverse ? .topLeading : .bottomTrailing)
                        .blendMode(.color)
                }
            }
            .frame(width: 26, height: 26).clipShape(Circle())
            .accessibilityLabel("Olympia")
    }
}

private struct OlympiaActivityTimer: View {
    let state: OlympiaWorkoutActivityAttributes.ContentState
    var body: some View {
        if state.phase == "paused" {
            let seconds = state.pausedPhase == "resting" ? state.pausedRemaining : state.frozenElapsed
            Text(Self.formatted(seconds))
        } else if let deadline = state.deadline, let start = state.countdownStart, deadline > start {
            Text(timerInterval: start...deadline, countsDown: true).monospacedDigit()
        } else {
            Text(timerInterval: state.elapsedStart...Date.distantFuture, countsDown: false).monospacedDigit()
        }
    }

    static func formatted(_ seconds: Int) -> String {
        String(format: "%d:%02d", max(0, seconds) / 60, max(0, seconds) % 60)
    }
}

private struct OlympiaWorkoutActivityCard: View {
    let state: OlympiaWorkoutActivityAttributes.ContentState
    let sessionID: UUID
    let stale: Bool
    private let accent = Color(red: 0.48, green: 0.84, blue: 1)
    private var ring: LinearGradient {
        LinearGradient(colors: [accent, Color(red: 0.76, green: 0.42, blue: 1)],
                       startPoint: .topLeading, endPoint: .bottomTrailing)
    }

    var body: some View {
        VStack(spacing: 8) {
            HStack(spacing: 14) {
                VStack(spacing: 4) {
                    ZStack {
                        Circle().stroke(.white.opacity(0.13), lineWidth: 7)
                        if state.isCountdown, let start = state.countdownStart, let deadline = state.deadline, deadline > start {
                            ProgressView(timerInterval: start...deadline, countsDown: true)
                                .progressViewStyle(.circular).labelsHidden().tint(accent)
                        } else {
                            Circle().trim(from: 0, to: state.progress)
                                .stroke(ring, style: StrokeStyle(lineWidth: 7, lineCap: .round))
                                .rotationEffect(.degrees(-90))
                        }
                        VStack(spacing: 3) {
                            Text(state.timerLabel).font(.system(size: 9, weight: .semibold)).foregroundStyle(.secondary)
                            OlympiaActivityTimer(state: state).font(.system(size: 21, weight: .bold).monospacedDigit())
                                .minimumScaleFactor(0.7).lineLimit(1)
                        }.padding(9)
                    }.frame(width: 76, height: 76)
                    if !stale, let bpm = state.currentHeartRate(at: .now) {
                        Label("\(bpm) bpm", systemImage: "heart.fill")
                            .font(.system(size: 11, weight: .semibold)).foregroundStyle(accent)
                    }
                }
                Rectangle().fill(.white.opacity(0.13)).frame(width: 1)
                VStack(alignment: .leading, spacing: 4) {
                    Text(state.isCountdown ? "NEXT · \(state.workoutName)" : state.workoutName)
                        .font(.system(size: 10, weight: .semibold)).foregroundStyle(.secondary).lineLimit(1)
                    Text(state.exerciseName).font(.system(size: 17, weight: .bold)).lineLimit(1).minimumScaleFactor(0.8)
                    Text("Set \(state.setNumber) of \(state.exerciseSets)").font(.caption).foregroundStyle(.secondary)
                    Text(state.target).font(.system(size: 11, weight: .medium)).lineLimit(1).minimumScaleFactor(0.75)
                        .padding(.horizontal, 9).padding(.vertical, 4)
                        .background(.white.opacity(0.08), in: Capsule())
                    Text("Progress  \(state.completedSets) / \(state.totalSets) sets")
                        .font(.system(size: 11)).foregroundStyle(.secondary)
                }.frame(maxWidth: .infinity, alignment: .leading)
            }
            HStack(spacing: 10) {
                if state.phase != "preparing" {
                    Button(intent: OlympiaWorkoutActionIntent(sessionID: sessionID,
                                                              action: state.phase == "paused" ? "resume" : "pause")) {
                        Label(state.phase == "paused" ? "Resume" : "Pause",
                              systemImage: state.phase == "paused" ? "play.fill" : "pause.fill")
                            .frame(maxWidth: .infinity)
                    }.buttonStyle(.plain).padding(.vertical, 8)
                        .background(.white.opacity(0.12), in: Capsule())
                }
                if state.phase == "resting" {
                    Button(intent: OlympiaWorkoutActionIntent(sessionID: sessionID, action: "skipRest")) {
                        Label("Skip rest", systemImage: "forward.end.fill").frame(maxWidth: .infinity)
                    }.buttonStyle(.plain).padding(.vertical, 8)
                        .background(.white.opacity(0.12), in: Capsule())
                } else {
                    Link(destination: URL(string: "olympia://workout")!) {
                        Label("Open workout", systemImage: "arrow.up.right").frame(maxWidth: .infinity)
                    }.padding(.vertical, 8).background(.white.opacity(0.12), in: Capsule())
                }
            }.font(.system(size: 12, weight: .semibold))
        }
        .padding(10).foregroundStyle(.white)
        .background {
            RoundedRectangle(cornerRadius: 26)
                .fill(LinearGradient(colors: [.purple.opacity(0.20), .blue.opacity(0.10), .clear],
                                     startPoint: .topLeading, endPoint: .bottomTrailing))
        }
        .overlay { RoundedRectangle(cornerRadius: 26).strokeBorder(.white.opacity(0.24), lineWidth: 0.8) }
    }
}
