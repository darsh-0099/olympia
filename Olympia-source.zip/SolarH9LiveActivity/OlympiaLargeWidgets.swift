import SwiftUI
import WidgetKit

private enum WidgetPalette {
    static let background = Color(red: 0.085, green: 0.085, blue: 0.095)
    static let card = Color(red: 0.15, green: 0.15, blue: 0.17)
    static let lavender = Color(red: 0.72, green: 0.62, blue: 1)
    static let muted = Color(red: 0.72, green: 0.71, blue: 0.78)
    static let red = Color(red: 0.96, green: 0.29, blue: 0.35)
}

private extension Color {
    init(widgetHex: String?) {
        let string = (widgetHex ?? "#B89EFF").trimmingCharacters(in: CharacterSet(charactersIn: "#"))
        let value = Int(string, radix: 16) ?? 0xB89EFF
        self.init(red: Double((value >> 16) & 255) / 255,
                  green: Double((value >> 8) & 255) / 255,
                  blue: Double(value & 255) / 255)
    }
}

private struct OlympiaDataEntry: TimelineEntry {
    let date: Date
    let snapshot: OlympiaWidgetSnapshot?
}

private struct OlympiaDataProvider: TimelineProvider {
    func placeholder(in context: Context) -> OlympiaDataEntry { .init(date: .now, snapshot: nil) }
    func getSnapshot(in context: Context, completion: @escaping (OlympiaDataEntry) -> Void) {
        completion(.init(date: .now, snapshot: OlympiaWidgetSnapshot.read()))
    }
    func getTimeline(in context: Context, completion: @escaping (Timeline<OlympiaDataEntry>) -> Void) {
        let now = Date()
        let snapshot = OlympiaWidgetSnapshot.read()
        var entries = [OlympiaDataEntry(date: now, snapshot: snapshot)]
        if let sampleDate = snapshot?.active?.heartRateUpdatedAt {
            let expiry = sampleDate.addingTimeInterval(30)
            if expiry > now { entries.append(.init(date: expiry, snapshot: snapshot)) }
        }
        if let deadline = snapshot?.active?.deadline, deadline > now {
            entries.append(.init(date: deadline, snapshot: snapshot))
        }
        entries.sort { $0.date < $1.date }
        completion(Timeline(entries: entries,
                            policy: .after(now.addingTimeInterval(15 * 60))))
    }
}

private struct OlympiaWidgetHeader: View {
    let subtitle: String
    var body: some View {
        HStack(alignment: .firstTextBaseline) {
            Text("Olympia").font(.system(size: 26, weight: .bold, design: .rounded)).foregroundStyle(.white)
            Spacer()
            Text(subtitle).font(.subheadline).foregroundStyle(WidgetPalette.muted)
        }
    }
}

struct OlympiaWeekWidget: Widget {
    let kind = "OlympiaWeekWidget"
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: OlympiaDataProvider()) { entry in
            OlympiaWeekView(entry: entry)
                .containerBackground(for: .widget) { WidgetPalette.background }
                .widgetURL(URL(string: "olympia://home"))
        }
        .configurationDisplayName("Olympia Week")
        .description("Your actual training schedule and completed workouts this week.")
        .supportedFamilies([.systemLarge])
    }
}

private struct OlympiaWeekView: View {
    let entry: OlympiaDataEntry
    private var snapshot: OlympiaWidgetSnapshot? { entry.snapshot }
    private var weekDays: [OlympiaWidgetSnapshot.Day] { snapshot?.daysForWeek(containing: entry.date) ?? [] }
    private var workoutsCompleted: Int { weekDays.reduce(0) { $0 + $1.completedCount } }
    private var plannedCount: Int { weekDays.reduce(0) { $0 + $1.plannedNames.count } }

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            OlympiaWidgetHeader(subtitle: "This week")
            if weekDays.count == 7 {
                HStack(spacing: 5) {
                    ForEach(weekDays.indices, id: \.self) { index in
                        let day = weekDays[index]
                        let isToday = Calendar.current.isDate(day.date, inSameDayAs: entry.date)
                        VStack(spacing: 8) {
                            Text(day.date.formatted(.dateTime.weekday(.abbreviated)))
                                .font(.caption2).foregroundStyle(WidgetPalette.muted)
                            Text(day.date.formatted(.dateTime.day()))
                                .font(.headline.weight(.medium)).foregroundStyle(.white)
                            Circle().fill(day.completedCount > 0 ? Color.green :
                                          day.plannedNames.isEmpty ? WidgetPalette.muted.opacity(0.35) : Color(widgetHex: day.colorHex))
                                .frame(width: 10, height: 10)
                        }
                        .frame(maxWidth: .infinity).padding(.vertical, 12)
                        .background(WidgetPalette.card, in: RoundedRectangle(cornerRadius: 13))
                        .overlay(RoundedRectangle(cornerRadius: 13)
                            .stroke(isToday ? WidgetPalette.lavender : .clear, lineWidth: 1.5))
                    }
                }
                HStack(spacing: 14) {
                    Image(systemName: "calendar").font(.title2).foregroundStyle(WidgetPalette.lavender)
                    VStack(alignment: .leading, spacing: 2) {
                        Text("\(workoutsCompleted) workouts completed").font(.headline)
                        Text(plannedCount > 0 ? "\(plannedCount) scheduled this week" : "No workouts scheduled")
                            .font(.subheadline).foregroundStyle(WidgetPalette.muted)
                    }
                    Spacer()
                }
                .padding(16).background(WidgetPalette.card, in: RoundedRectangle(cornerRadius: 17))
                if let upcoming = weekDays.first(where: {
                    $0.date >= Calendar.current.startOfDay(for: entry.date) && !$0.plannedNames.isEmpty
                }) {
                    HStack {
                        Text("UP NEXT").font(.caption2.bold()).tracking(1.4).foregroundStyle(WidgetPalette.muted)
                        Spacer()
                        Text(upcoming.plannedNames.joined(separator: ", ")).lineLimit(1)
                        Text(upcoming.date.formatted(.dateTime.weekday(.abbreviated)))
                            .foregroundStyle(WidgetPalette.lavender)
                    }.font(.subheadline)
                } else { Spacer(minLength: 0) }
            } else {
                Spacer()
                Label("Open Olympia to sync your schedule", systemImage: "calendar.badge.exclamationmark")
                    .font(.headline).foregroundStyle(WidgetPalette.muted)
                Text("Training data is unavailable to this widget.").font(.caption).foregroundStyle(WidgetPalette.muted)
                Spacer()
            }
        }
        .padding(18).foregroundStyle(.white)
    }
}

struct OlympiaActiveWidget: Widget {
    let kind = "OlympiaActiveWidget"
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: OlympiaDataProvider()) { entry in
            OlympiaActiveView(entry: entry)
                .containerBackground(for: .widget) { WidgetPalette.background }
                .widgetURL(URL(string: "olympia://workout"))
        }
        .configurationDisplayName("Olympia Active Workout")
        .description("Workout progress and rest timer, with sensor data when available.")
        .supportedFamilies([.systemLarge])
    }
}

private struct OlympiaActiveView: View {
    let entry: OlympiaDataEntry
    private var active: OlympiaWidgetSnapshot.Active? { entry.snapshot?.active }

    var body: some View {
        VStack(alignment: .leading, spacing: 15) {
            OlympiaWidgetHeader(subtitle: active == nil ? "Workout" : "Workout in progress")
            if let active {
                HStack(alignment: .center, spacing: 16) {
                    VStack(alignment: .leading, spacing: 5) {
                        Text(active.phase == "resting" ? "Rest" : active.phase == "preparing" ? "Get ready" :
                             active.phase == "paused" ? "Paused" : "Current workout")
                            .font(.headline).foregroundStyle(WidgetPalette.muted)
                        if ["resting", "preparing"].contains(active.phase), let deadline = active.deadline,
                           deadline > entry.date {
                            Text(timerInterval: entry.date...deadline, countsDown: true)
                                .font(.system(size: 45, weight: .bold, design: .rounded)).monospacedDigit()
                        } else if ["resting", "preparing"].contains(active.phase), active.deadline != nil {
                            Text("Open Olympia").font(.system(size: 29, weight: .bold, design: .rounded))
                        } else if active.phase == "paused" {
                            Text("Paused").font(.system(size: 37, weight: .bold, design: .rounded))
                        } else {
                            Text(active.name).font(.system(size: 28, weight: .bold, design: .rounded)).lineLimit(2)
                        }
                    }
                    Spacer(minLength: 0)
                    ZStack {
                        Circle().stroke(WidgetPalette.card, lineWidth: 9)
                        Circle().trim(from: 0, to: active.totalSets > 0 ? min(1, Double(active.completedSets) / Double(active.totalSets)) : 0)
                            .stroke(WidgetPalette.lavender, style: StrokeStyle(lineWidth: 9, lineCap: .round))
                            .rotationEffect(.degrees(-90))
                        Text("\(active.completedSets)/\(active.totalSets)").font(.headline.monospacedDigit())
                    }.frame(width: 85, height: 85)
                }
                Divider().overlay(WidgetPalette.muted.opacity(0.3))
                VStack(alignment: .leading, spacing: 4) {
                    Text("CURRENT EXERCISE").font(.caption2.bold()).tracking(1.4).foregroundStyle(WidgetPalette.muted)
                    Text(active.exercise ?? "Get ready").font(.title3.bold()).lineLimit(1)
                    Text(active.exerciseTotalSets.map { "Set \(active.setNumber) of \($0) · \(active.name)" }
                         ?? "Set \(active.setNumber) · \(active.name)")
                        .font(.subheadline).foregroundStyle(WidgetPalette.muted).lineLimit(1)
                }
                Spacer(minLength: 0)
                if let bpm = active.currentHeartRate(at: entry.date) {
                    VStack(alignment: .leading, spacing: 7) {
                        HStack {
                            Image(systemName: "heart.fill").foregroundStyle(WidgetPalette.red)
                            Text("\(bpm) bpm").font(.headline.monospacedDigit())
                            Spacer()
                            Text(active.heartRateZone.map { "Zone \($0)" } ?? "Heart rate")
                                .font(.subheadline).foregroundStyle(WidgetPalette.muted)
                        }
                        HStack(spacing: 4) {
                            ForEach(1...5, id: \.self) { zone in
                                Capsule().fill(zoneColor(zone).opacity(active.heartRateZone == zone ? 1 : 0.45))
                            }
                        }.frame(height: 7)
                        Text("Latest sensor reading · widget refresh may lag")
                            .font(.caption2).foregroundStyle(WidgetPalette.muted)
                    }.padding(13).background(WidgetPalette.card, in: RoundedRectangle(cornerRadius: 15))
                }
            } else {
                Spacer()
                Image(systemName: "figure.strengthtraining.traditional")
                    .font(.largeTitle).foregroundStyle(WidgetPalette.lavender)
                Text(entry.snapshot == nil ? "Open Olympia to sync your workout" : "No workout in progress")
                    .font(.title3.bold())
                Text(entry.snapshot == nil ? "Training data is unavailable to this widget." : "Start a workout in Olympia to see it here.")
                    .font(.subheadline).foregroundStyle(WidgetPalette.muted)
                Spacer()
            }
        }.padding(18).foregroundStyle(.white)
    }

    private func zoneColor(_ zone: Int) -> Color {
        switch zone {
        case 1: Color(red: 0.22, green: 0.45, blue: 0.86)
        case 2: Color(red: 0.27, green: 0.87, blue: 0.58)
        case 3: Color(red: 0.92, green: 0.84, blue: 0.40)
        case 4: Color(red: 0.95, green: 0.60, blue: 0.32)
        default: WidgetPalette.red
        }
    }
}
