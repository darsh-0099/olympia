import Foundation

/// A small, privacy-conscious projection of local training data for WidgetKit.
/// Both targets must be signed into this App Group for the snapshot to be shared.
struct OlympiaWidgetSnapshot: Codable {
    static let groupID = "group.com.olympia.app"
    static let key = "olympia.widget.snapshot.v1"

    struct Day: Codable, Equatable {
        let date: Date
        let plannedNames: [String]
        let completedCount: Int
        let colorHex: String?
    }

    struct Active: Codable {
        let id: UUID
        let name: String
        let phase: String
        let exercise: String?
        let setNumber: Int
        let exerciseTotalSets: Int?
        let totalSets: Int
        let completedSets: Int
        let deadline: Date?
        let pausedRemaining: TimeInterval
        let heartRate: Int?
        let heartRateZone: Int?
        let heartRateUpdatedAt: Date?

        func currentHeartRate(at date: Date) -> Int? {
            guard let heartRate, let heartRateUpdatedAt,
                  date.timeIntervalSince(heartRateUpdatedAt) >= 0,
                  date.timeIntervalSince(heartRateUpdatedAt) < 30 else { return nil }
            return heartRate
        }
    }

    let generatedAt: Date
    let weekStart: Date
    let days: [Day]
    let active: Active?

    func daysForWeek(containing date: Date, calendar: Calendar = .current) -> [Day] {
        let startOfDay = calendar.startOfDay(for: date)
        let offset = (calendar.component(.weekday, from: startOfDay) - calendar.firstWeekday + 7) % 7
        guard let start = calendar.date(byAdding: .day, value: -offset, to: startOfDay),
              let end = calendar.date(byAdding: .day, value: 7, to: start) else { return [] }
        return days.filter { $0.date >= start && $0.date < end }
    }

    static func read() -> Self? {
        guard let defaults = UserDefaults(suiteName: groupID),
              let data = defaults.data(forKey: key) else { return nil }
        return try? JSONDecoder().decode(Self.self, from: data)
    }

    @discardableResult
    func write() -> Bool {
        guard let defaults = UserDefaults(suiteName: Self.groupID),
              let data = try? JSONEncoder().encode(self) else { return false }
        defaults.set(data, forKey: Self.key)
        return true
    }
}
